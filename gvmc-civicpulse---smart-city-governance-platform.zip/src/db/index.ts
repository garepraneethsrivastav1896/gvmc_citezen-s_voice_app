import pg from 'pg';
import dotenv from 'dotenv';
import fs from 'fs';
import { Complaint, Ward, Worker, NotificationItem } from '../types';
import { INITIAL_WARDS, INITIAL_WORKERS, INITIAL_COMPLAINTS, INITIAL_NOTIFICATIONS } from '../data/mockData';

if (fs.existsSync('.env')) {
  dotenv.config({ path: '.env' });
} else if (fs.existsSync('.env.example')) {
  dotenv.config({ path: '.env.example' });
} else {
  dotenv.config();
}

const dbUrl = process.env.DATABASE_URL;

function getPoolConfig(urlStr: string): pg.PoolConfig {
  try {
    const u = new URL(urlStr);
    return {
      connectionString: urlStr,
      ssl: u.hostname === 'localhost' || u.hostname === '127.0.0.1' ? false : { rejectUnauthorized: false },
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    };
  } catch {
    const match = urlStr.match(/^(?:postgres(?:ql)?:\/\/)?([^:]+):(.*)@([^:\/]+)(?::(\d+))?\/(.+)$/);
    if (match) {
      const [, user, password, host, portStr, dbAndParams] = match;
      const [database] = dbAndParams.split('?');
      return {
        user: decodeURIComponent(user),
        password: decodeURIComponent(password),
        host,
        port: portStr ? parseInt(portStr, 10) : 5432,
        database,
        ssl: host === 'localhost' || host === '127.0.0.1' ? false : { rejectUnauthorized: false },
        max: 10,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 10000,
      };
    }
    return {
      connectionString: urlStr,
      ssl: { rejectUnauthorized: false },
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    };
  }
}

export const pool = dbUrl ? new pg.Pool(getPoolConfig(dbUrl)) : null;

// In-memory fallback cache
let memoryComplaints: Complaint[] = [...INITIAL_COMPLAINTS];
let memoryWards: Ward[] = [...INITIAL_WARDS];
let memoryWorkers: Worker[] = [...INITIAL_WORKERS];
let memoryNotifications: NotificationItem[] = [...INITIAL_NOTIFICATIONS];

export let isDbConnected = false;

export async function initDatabase(): Promise<boolean> {
  if (!pool) {
    console.log('[Database] No DATABASE_URL provided. Running in-memory store.');
    return false;
  }

  try {
    const client = await pool.connect();
    console.log('[Database] Connected to Supabase PostgreSQL successfully!');

    // Initialize Schema
    await client.query(`
      CREATE TABLE IF NOT EXISTS wards (
        id INT PRIMARY KEY,
        number INT NOT NULL,
        name TEXT NOT NULL,
        zone TEXT NOT NULL,
        population INT NOT NULL,
        complaint_count INT NOT NULL DEFAULT 0,
        resolved_count INT NOT NULL DEFAULT 0,
        pending_count INT NOT NULL DEFAULT 0,
        avg_resolution_hours FLOAT NOT NULL DEFAULT 24.0,
        performance_index INT NOT NULL DEFAULT 85,
        ranking INT NOT NULL DEFAULT 1,
        officer_name TEXT NOT NULL,
        officer_contact TEXT NOT NULL,
        boundary JSONB NOT NULL
      );

      CREATE TABLE IF NOT EXISTS workers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        phone TEXT NOT NULL,
        ward_id INT NOT NULL,
        ward_name TEXT NOT NULL,
        lat FLOAT NOT NULL,
        lng FLOAT NOT NULL,
        active_complaints INT NOT NULL DEFAULT 0,
        status TEXT NOT NULL,
        efficiency_rating FLOAT NOT NULL DEFAULT 4.5
      );

      CREATE TABLE IF NOT EXISTS complaints (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        original_description TEXT,
        category TEXT NOT NULL,
        priority TEXT NOT NULL,
        status TEXT NOT NULL,
        ward_id INT NOT NULL,
        ward_name TEXT NOT NULL,
        zone_name TEXT NOT NULL,
        lat FLOAT NOT NULL,
        lng FLOAT NOT NULL,
        landmark TEXT NOT NULL,
        image_url TEXT,
        before_image_url TEXT,
        after_image_url TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        citizen_name TEXT NOT NULL,
        citizen_phone TEXT NOT NULL,
        assigned_worker_id TEXT,
        assigned_worker_name TEXT,
        assigned_worker_phone TEXT,
        sentiment_score TEXT NOT NULL DEFAULT 'NEUTRAL',
        is_duplicate BOOLEAN DEFAULT FALSE,
        duplicate_of_id TEXT,
        ai_summary TEXT,
        ai_category_confidence FLOAT,
        language TEXT NOT NULL DEFAULT 'EN',
        translated_version JSONB,
        sla_hours INT NOT NULL DEFAULT 24,
        hours_remaining INT NOT NULL DEFAULT 24,
        officer_notes TEXT,
        citizen_feedback JSONB
      );

      CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        type TEXT NOT NULL,
        recipient_role TEXT NOT NULL,
        complaint_id TEXT,
        is_read BOOLEAN NOT NULL DEFAULT FALSE
      );
    `);

    // Check if Wards exist, seed if empty
    const wardCheck = await client.query(`SELECT COUNT(*) FROM wards`);
    if (parseInt(wardCheck.rows[0].count, 10) === 0) {
      console.log('[Database] Seeding Wards into PostgreSQL...');
      for (const w of INITIAL_WARDS) {
        await client.query(
          `INSERT INTO wards (id, number, name, zone, population, complaint_count, resolved_count, pending_count, avg_resolution_hours, performance_index, ranking, officer_name, officer_contact, boundary)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
           ON CONFLICT (id) DO NOTHING`,
          [w.id, w.number, w.name, w.zone, w.population, w.complaintCount, w.resolvedCount, w.pendingCount, w.avgResolutionHours, w.performanceIndex, w.ranking, w.officerName, w.officerContact, JSON.stringify(w.boundary)]
        );
      }
    }

    // Check if Workers exist, seed if empty
    const workerCheck = await client.query(`SELECT COUNT(*) FROM workers`);
    if (parseInt(workerCheck.rows[0].count, 10) === 0) {
      console.log('[Database] Seeding Workers into PostgreSQL...');
      for (const wk of INITIAL_WORKERS) {
        await client.query(
          `INSERT INTO workers (id, name, category, phone, ward_id, ward_name, lat, lng, active_complaints, status, efficiency_rating)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
           ON CONFLICT (id) DO NOTHING`,
          [wk.id, wk.name, wk.category, wk.phone, wk.wardId, wk.wardName, wk.lat, wk.lng, wk.activeComplaints, wk.status, wk.efficiencyRating]
        );
      }
    }

    // Check if Complaints exist, seed if empty
    const complaintCheck = await client.query(`SELECT COUNT(*) FROM complaints`);
    if (parseInt(complaintCheck.rows[0].count, 10) === 0) {
      console.log('[Database] Seeding Initial Complaints into PostgreSQL...');
      for (const c of INITIAL_COMPLAINTS) {
        await client.query(
          `INSERT INTO complaints (id, title, description, original_description, category, priority, status, ward_id, ward_name, zone_name, lat, lng, landmark, image_url, before_image_url, after_image_url, created_at, updated_at, citizen_name, citizen_phone, assigned_worker_id, assigned_worker_name, assigned_worker_phone, sentiment_score, is_duplicate, duplicate_of_id, ai_summary, ai_category_confidence, language, translated_version, sla_hours, hours_remaining, officer_notes, citizen_feedback)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34)
           ON CONFLICT (id) DO NOTHING`,
          [
            c.id, c.title, c.description, c.originalDescription || null, c.category, c.priority, c.status,
            c.wardId, c.wardName, c.zoneName, c.lat, c.lng, c.landmark, c.imageUrl || null, c.beforeImageUrl || null,
            c.afterImageUrl || null, c.createdAt, c.updatedAt, c.citizenName, c.citizenPhone, c.assignedWorkerId || null,
            c.assignedWorkerName || null, c.assignedWorkerPhone || null, c.sentimentScore, c.isDuplicate || false,
            c.duplicateOfId || null, c.aiSummary || null, c.aiCategoryConfidence || null, c.language,
            c.translatedVersion ? JSON.stringify(c.translatedVersion) : null, c.slaHours, c.hoursRemaining,
            c.officerNotes || null, c.citizenFeedback ? JSON.stringify(c.citizenFeedback) : null
          ]
        );
      }
    }

    // Check if Notifications exist, seed if empty
    const notifCheck = await client.query(`SELECT COUNT(*) FROM notifications`);
    if (parseInt(notifCheck.rows[0].count, 10) === 0) {
      console.log('[Database] Seeding Notifications into PostgreSQL...');
      for (const n of INITIAL_NOTIFICATIONS) {
        await client.query(
          `INSERT INTO notifications (id, title, message, timestamp, type, recipient_role, complaint_id, is_read)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           ON CONFLICT (id) DO NOTHING`,
          [n.id, n.title, n.message, n.timestamp, n.type, n.recipientRole, n.complaintId || null, n.isRead]
        );
      }
    }

    client.release();
    isDbConnected = true;
    console.log('[Database] PostgreSQL Supabase database initialized and synchronized!');
    return true;
  } catch (err: any) {
    console.error('[Database] Failed to connect or initialize PostgreSQL:', err.message);
    isDbConnected = false;
    return false;
  }
}

// Map SQL row to Complaint interface
function mapRowToComplaint(row: any): Complaint {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    originalDescription: row.original_description || undefined,
    category: row.category,
    priority: row.priority,
    status: row.status,
    wardId: row.ward_id,
    wardName: row.ward_name,
    zoneName: row.zone_name,
    lat: Number(row.lat),
    lng: Number(row.lng),
    landmark: row.landmark,
    imageUrl: row.image_url || undefined,
    beforeImageUrl: row.before_image_url || undefined,
    afterImageUrl: row.after_image_url || undefined,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
    citizenName: row.citizen_name,
    citizenPhone: row.citizen_phone,
    assignedWorkerId: row.assigned_worker_id || undefined,
    assignedWorkerName: row.assigned_worker_name || undefined,
    assignedWorkerPhone: row.assigned_worker_phone || undefined,
    sentimentScore: row.sentiment_score,
    isDuplicate: Boolean(row.is_duplicate),
    duplicateOfId: row.duplicate_of_id || undefined,
    aiSummary: row.ai_summary || undefined,
    aiCategoryConfidence: row.ai_category_confidence ? Number(row.ai_category_confidence) : undefined,
    language: row.language,
    translatedVersion: row.translated_version ? (typeof row.translated_version === 'string' ? JSON.parse(row.translated_version) : row.translated_version) : undefined,
    slaHours: row.sla_hours,
    hoursRemaining: row.hours_remaining,
    officerNotes: row.officer_notes || undefined,
    citizenFeedback: row.citizen_feedback ? (typeof row.citizen_feedback === 'string' ? JSON.parse(row.citizen_feedback) : row.citizen_feedback) : undefined,
  };
}

// Map SQL row to Ward interface
function mapRowToWard(row: any): Ward {
  return {
    id: row.id,
    number: row.number,
    name: row.name,
    zone: row.zone,
    population: row.population,
    complaintCount: row.complaint_count,
    resolvedCount: row.resolved_count,
    pendingCount: row.pending_count,
    avgResolutionHours: Number(row.avg_resolution_hours),
    performanceIndex: row.performance_index,
    ranking: row.ranking,
    officerName: row.officer_name,
    officerContact: row.officer_contact,
    boundary: typeof row.boundary === 'string' ? JSON.parse(row.boundary) : row.boundary,
  };
}

// Map SQL row to Worker interface
function mapRowToWorker(row: any): Worker {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    phone: row.phone,
    wardId: row.ward_id,
    wardName: row.ward_name,
    lat: Number(row.lat),
    lng: Number(row.lng),
    activeComplaints: row.active_complaints,
    status: row.status,
    efficiencyRating: Number(row.efficiency_rating),
  };
}

// Map SQL row to NotificationItem interface
function mapRowToNotification(row: any): NotificationItem {
  return {
    id: row.id,
    title: row.title,
    message: row.message,
    timestamp: row.timestamp,
    type: row.type,
    recipientRole: row.recipient_role,
    complaintId: row.complaint_id || undefined,
    isRead: Boolean(row.is_read),
  };
}

// Fetch All Complaints with filtering
export async function dbGetComplaints(filters?: { wardId?: number; priority?: string; category?: string; status?: string; search?: string }): Promise<Complaint[]> {
  if (!pool || !isDbConnected) {
    let res = [...memoryComplaints];
    if (filters?.wardId) res = res.filter(c => c.wardId === Number(filters.wardId));
    if (filters?.priority) res = res.filter(c => c.priority === filters.priority);
    if (filters?.category) res = res.filter(c => c.category === filters.category);
    if (filters?.status) res = res.filter(c => c.status === filters.status);
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      res = res.filter(c => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.id.toLowerCase().includes(q));
    }
    return res;
  }

  try {
    let query = `SELECT * FROM complaints WHERE 1=1`;
    const params: any[] = [];

    if (filters?.wardId) {
      params.push(filters.wardId);
      query += ` AND ward_id = $${params.length}`;
    }
    if (filters?.priority) {
      params.push(filters.priority);
      query += ` AND priority = $${params.length}`;
    }
    if (filters?.category) {
      params.push(filters.category);
      query += ` AND category = $${params.length}`;
    }
    if (filters?.status) {
      params.push(filters.status);
      query += ` AND status = $${params.length}`;
    }
    if (filters?.search) {
      params.push(`%${filters.search.toLowerCase()}%`);
      query += ` AND (LOWER(title) LIKE $${params.length} OR LOWER(description) LIKE $${params.length} OR LOWER(id) LIKE $${params.length} OR LOWER(landmark) LIKE $${params.length})`;
    }

    query += ` ORDER BY created_at DESC`;

    const { rows } = await pool.query(query, params);
    return rows.map(mapRowToComplaint);
  } catch (err: any) {
    console.error('[Database] dbGetComplaints query error:', err.message);
    return memoryComplaints;
  }
}

// Fetch Single Complaint By ID
export async function dbGetComplaintById(id: string): Promise<Complaint | null> {
  if (!pool || !isDbConnected) {
    return memoryComplaints.find(c => c.id === id) || null;
  }

  try {
    const { rows } = await pool.query(`SELECT * FROM complaints WHERE id = $1`, [id]);
    if (rows.length === 0) return null;
    return mapRowToComplaint(rows[0]);
  } catch (err: any) {
    console.error('[Database] dbGetComplaintById error:', err.message);
    return memoryComplaints.find(c => c.id === id) || null;
  }
}

// Create New Complaint
export async function dbCreateComplaint(c: Complaint): Promise<Complaint> {
  memoryComplaints.unshift(c);

  if (!pool || !isDbConnected) {
    return c;
  }

  try {
    await pool.query(
      `INSERT INTO complaints (id, title, description, original_description, category, priority, status, ward_id, ward_name, zone_name, lat, lng, landmark, image_url, before_image_url, after_image_url, created_at, updated_at, citizen_name, citizen_phone, assigned_worker_id, assigned_worker_name, assigned_worker_phone, sentiment_score, is_duplicate, duplicate_of_id, ai_summary, ai_category_confidence, language, translated_version, sla_hours, hours_remaining, officer_notes, citizen_feedback)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34)`,
      [
        c.id, c.title, c.description, c.originalDescription || null, c.category, c.priority, c.status,
        c.wardId, c.wardName, c.zoneName, c.lat, c.lng, c.landmark, c.imageUrl || null, c.beforeImageUrl || null,
        c.afterImageUrl || null, c.createdAt, c.updatedAt, c.citizenName, c.citizenPhone, c.assignedWorkerId || null,
        c.assignedWorkerName || null, c.assignedWorkerPhone || null, c.sentimentScore, c.isDuplicate || false,
        c.duplicateOfId || null, c.aiSummary || null, c.aiCategoryConfidence || null, c.language,
        c.translatedVersion ? JSON.stringify(c.translatedVersion) : null, c.slaHours, c.hoursRemaining,
        c.officerNotes || null, c.citizenFeedback ? JSON.stringify(c.citizenFeedback) : null
      ]
    );

    // Update Ward counts in DB
    await pool.query(
      `UPDATE wards SET complaint_count = complaint_count + 1, pending_count = pending_count + 1 WHERE id = $1`,
      [c.wardId]
    );
  } catch (err: any) {
    console.error('[Database] dbCreateComplaint error:', err.message);
  }

  return c;
}

// Update Complaint Status / Worker / Notes
export async function dbUpdateComplaint(id: string, updates: Partial<Complaint>): Promise<Complaint | null> {
  const comp = memoryComplaints.find(c => c.id === id);
  if (comp) {
    Object.assign(comp, updates, { updatedAt: new Date().toISOString() });
  }

  if (!pool || !isDbConnected) {
    return comp || null;
  }

  try {
    const fields: string[] = [];
    const params: any[] = [id];

    if (updates.status !== undefined) {
      params.push(updates.status);
      fields.push(`status = $${params.length}`);
    }
    if (updates.assignedWorkerId !== undefined) {
      params.push(updates.assignedWorkerId);
      fields.push(`assigned_worker_id = $${params.length}`);
    }
    if (updates.assignedWorkerName !== undefined) {
      params.push(updates.assignedWorkerName);
      fields.push(`assigned_worker_name = $${params.length}`);
    }
    if (updates.assignedWorkerPhone !== undefined) {
      params.push(updates.assignedWorkerPhone);
      fields.push(`assigned_worker_phone = $${params.length}`);
    }
    if (updates.officerNotes !== undefined) {
      params.push(updates.officerNotes);
      fields.push(`officer_notes = $${params.length}`);
    }
    if (updates.afterImageUrl !== undefined) {
      params.push(updates.afterImageUrl);
      fields.push(`after_image_url = $${params.length}`);
    }
    if (updates.citizenFeedback !== undefined) {
      params.push(JSON.stringify(updates.citizenFeedback));
      fields.push(`citizen_feedback = $${params.length}`);
    }

    params.push(new Date().toISOString());
    fields.push(`updated_at = $${params.length}`);

    if (fields.length > 0) {
      const { rows } = await pool.query(
        `UPDATE complaints SET ${fields.join(', ')} WHERE id = $1 RETURNING *`,
        params
      );
      if (rows.length > 0) {
        return mapRowToComplaint(rows[0]);
      }
    }
  } catch (err: any) {
    console.error('[Database] dbUpdateComplaint error:', err.message);
  }

  return comp || null;
}

// Get All Wards
export async function dbGetWards(): Promise<Ward[]> {
  if (!pool || !isDbConnected) {
    return memoryWards;
  }

  try {
    const { rows } = await pool.query(`SELECT * FROM wards ORDER BY number ASC`);
    return rows.map(mapRowToWard);
  } catch (err: any) {
    console.error('[Database] dbGetWards error:', err.message);
    return memoryWards;
  }
}

// Get All Workers
export async function dbGetWorkers(): Promise<Worker[]> {
  if (!pool || !isDbConnected) {
    return memoryWorkers;
  }

  try {
    const { rows } = await pool.query(`SELECT * FROM workers ORDER BY name ASC`);
    return rows.map(mapRowToWorker);
  } catch (err: any) {
    console.error('[Database] dbGetWorkers error:', err.message);
    return memoryWorkers;
  }
}

// Update Worker
export async function dbUpdateWorkerStatus(workerId: string, status: string, activeComplaintsInc: number) {
  const worker = memoryWorkers.find(w => w.id === workerId);
  if (worker) {
    worker.status = status as any;
    worker.activeComplaints = Math.max(0, worker.activeComplaints + activeComplaintsInc);
  }

  if (!pool || !isDbConnected) return;

  try {
    await pool.query(
      `UPDATE workers SET status = $1, active_complaints = GREATEST(0, active_complaints + $2) WHERE id = $3`,
      [status, activeComplaintsInc, workerId]
    );
  } catch (err: any) {
    console.error('[Database] dbUpdateWorkerStatus error:', err.message);
  }
}

// Get All Notifications
export async function dbGetNotifications(): Promise<NotificationItem[]> {
  if (!pool || !isDbConnected) {
    return memoryNotifications;
  }

  try {
    const { rows } = await pool.query(`SELECT * FROM notifications ORDER BY id DESC LIMIT 50`);
    return rows.map(mapRowToNotification);
  } catch (err: any) {
    console.error('[Database] dbGetNotifications error:', err.message);
    return memoryNotifications;
  }
}

// Create Notification
export async function dbCreateNotification(notif: NotificationItem) {
  memoryNotifications.unshift(notif);

  if (!pool || !isDbConnected) return;

  try {
    await pool.query(
      `INSERT INTO notifications (id, title, message, timestamp, type, recipient_role, complaint_id, is_read)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [notif.id, notif.title, notif.message, notif.timestamp, notif.type, notif.recipientRole, notif.complaintId || null, notif.isRead]
    );
  } catch (err: any) {
    console.error('[Database] dbCreateNotification error:', err.message);
  }
}
