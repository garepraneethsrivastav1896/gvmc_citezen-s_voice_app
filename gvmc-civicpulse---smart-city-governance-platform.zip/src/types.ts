export type PriorityLevel = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MEDIUM' | 'P4_LOW';

export type ComplaintStatus = 
  | 'RAISED'
  | 'ASSIGNED'
  | 'IN_PROGRESS'
  | 'WORKER_COMPLETED'
  | 'CITIZEN_VERIFIED'
  | 'COMMISSIONER_APPROVED'
  | 'REJECTED';

export type UserRole = 'CITIZEN' | 'WARD_OFFICER' | 'COMMISSIONER' | 'FIELD_WORKER';

export type LanguageCode = 'EN' | 'TE' | 'HI';

export type CategoryType = 
  | 'Potholes & Roads'
  | 'Water Leakage & Supply'
  | 'Garbage & Sanitation'
  | 'Street Light & Power'
  | 'Drainage Overflow'
  | 'Encroachment & Building'
  | 'Public Parks & Greens';

export interface Complaint {
  id: string;
  title: string;
  description: string;
  originalDescription?: string;
  category: CategoryType;
  priority: PriorityLevel;
  status: ComplaintStatus;
  wardId: number;
  wardName: string;
  zoneName: string;
  lat: number;
  lng: number;
  landmark: string;
  imageUrl?: string;
  beforeImageUrl?: string;
  afterImageUrl?: string;
  createdAt: string;
  updatedAt: string;
  citizenName: string;
  citizenPhone: string;
  assignedWorkerId?: string;
  assignedWorkerName?: string;
  assignedWorkerPhone?: string;
  sentimentScore: 'POSITIVE' | 'NEUTRAL' | 'HIGH_DISTRESS' | 'URGENT';
  isDuplicate?: boolean;
  duplicateOfId?: string;
  aiSummary?: string;
  aiCategoryConfidence?: number;
  language: LanguageCode;
  translatedVersion?: {
    EN?: string;
    TE?: string;
    HI?: string;
  };
  slaHours: number;
  hoursRemaining: number;
  officerNotes?: string;
  citizenFeedback?: {
    rating: number;
    comment: string;
    isSatisfied: boolean;
  };
}

export interface Ward {
  id: number;
  number: number;
  name: string;
  zone: string;
  population: number;
  complaintCount: number;
  resolvedCount: number;
  pendingCount: number;
  avgResolutionHours: number;
  performanceIndex: number; // 0 - 100
  ranking: number;
  officerName: string;
  officerContact: string;
  boundary: Array<[number, number]>; // [lat, lng] array
}

export interface Worker {
  id: string;
  name: string;
  category: CategoryType;
  phone: string;
  wardId: number;
  wardName: string;
  lat: number;
  lng: number;
  activeComplaints: number;
  status: 'AVAILABLE' | 'ON_JOB' | 'OFFLINE';
  efficiencyRating: number; // e.g. 4.8 / 5.0
  distanceKm?: number; // Calculated dynamically via spatial distance
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS';
  recipientRole: UserRole | 'ALL';
  complaintId?: string;
  isRead: boolean;
}

export interface AnalyticsSummary {
  totalComplaints: number;
  resolvedCount: number;
  pendingCount: number;
  resolutionRate: number;
  avgSlaHours: number;
  topPerformingWard: string;
  p1CriticalCount: number;
  activeWorkersCount: number;
  categoryBreakdown: Array<{ name: string; value: number; color: string }>;
  weeklyTrends: Array<{ day: string; raised: number; resolved: number }>;
  zonePerformance: Array<{ zone: string; performanceIndex: number; complaints: number }>;
  sentimentBreakdown: Array<{ name: string; count: number }>;
}
