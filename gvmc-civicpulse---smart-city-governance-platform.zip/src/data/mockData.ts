import { Complaint, Ward, Worker, NotificationItem } from '../types';

const ALL_WARD_NAMES: string[] = [
  'Bheemili Beach & Tagarapuvalasa',
  'Sangivalasa & INS Kalinga Corridor',
  'Chittivalasa & Insaniwala',
  'Anandapuram Junction & Market',
  'Padmanabham Road & Sontyam',
  'Boyapalem & Gambheeram IT Park',
  'Kapuluppada Beach & Smart Village',
  'Rushikonda IT Hill & Beach Corridor',
  'Yendada & Gitam University Campus',
  'Kommadi Junction & IT Layout',
  'PM Palem (Pothinamallayya Palem)',
  'MVP Colony (Sectors 1-12)',
  'Lawson\'s Bay Colony & Beach Road',
  'Waltair Uplands & RK Beach',
  'Siripuram & Pandurangapuram',
  'Pithapuram Colony & Chinna Waltair',
  'Visalakshi Nagar & Kailasagiri',
  'Maddilapalem & AU Campus',
  'Venkojipalem & Isukathota',
  'HB Colony & Seethammadhara North',
  'Seethammadhara Main & NE Layout',
  'TPT Colony & Balayya Sastri Layout',
  'Resapuvanipalem & Cricket Stadium',
  'Akkayyapalem & Port Hospital Road',
  'Dwaraka Nagar & Complex Area',
  'Diamond Park & RTC Complex',
  'Ram Nagar & VIP Road',
  'Siripuram Circle & Visakha Museum',
  'Kirlampudi Layout & Beach Front',
  'Pedda Waltair & Jalari Yendada',
  'Asilmetta Junction & Sampath Vinayaka',
  'Dabagardens & Nehru Bazar',
  'Suryabagh & Cinema Hall Area',
  'Poorna Market & Town Hall',
  'Allipuram & Railway Station East',
  'Railway Colony & Thatichetlapalem',
  'Kancharapalem Main Road',
  'Gnanapuram & Convent Junction',
  'Industrial Estate & Industrial Park',
  'Urvasi Junction & Murali Nagar',
  'Jagadamba Center & Super Bazar',
  'Town Hall & Velampeta',
  'One Town & Ross Hill',
  'Burujupeta & Port Wall Road',
  'Salipeta & Fishing Harbour',
  'Kota Veedhi & Sri Kanya',
  'Kobbarithota & Jaganadhapuram',
  'Collectorate & Beach Road West',
  'Maharanipeta & KGH Hospital',
  'Zilla Parishad & Prakashraopeta',
  'Gopalapatnam Junction & Bus Stand',
  'Simhachalam Foothills & Devasthanam',
  'Prahaladapuram & Srinivasa Nagar',
  'Naiduthota & Vepagunta Cross',
  'Sujatha Nagar & Chinnamushidiwada',
  'Kothavalasa Road & Pendurthi North',
  'Laxmipuram & BRTS Corridor',
  'Marripalem & VUDA Colony',
  'NAD Junction & Airport Road',
  'Kakani Nagar & Sheela Nagar North',
  'Gajuwaka Main Road & High School Rd',
  'Old Gajuwaka & Mohinidevi Peta',
  'New Gajuwaka & BC Road',
  'Zinc Colony & Mindi Industrial Area',
  'Tunglam & Autonagar Phase 1',
  'Nathayyapalem & BHPV Colony',
  'BHPV Township & Port Connectivity Rd',
  'Yarada Hills & Dolphin\'s Nose',
  'Scindia & Naval Dockyard Base',
  'Malkapuram & Coromandel Gate',
  'Kurmannapalem Junction & NH16',
  'Steel Plant Sector 1 & Sector 2',
  'Steel Plant Sector 3 & Ukkunagaram',
  'Steel Plant Sector 4 & Sector 5',
  'Vadlapudi Railway Colony',
  'Duvvada Station & VSEZ Layout',
  'Aganampudi & Toll Plaza Road',
  'Kanithi Balancing Reservoir',
  'Desapatrunipalem & Rajiv Nagar',
  'Lankelapalem Junction & Pharma City',
  'Vadlapudi Main Road & Market',
  'Gangavaram Port Area & Beach',
  'Dibbapalem & Fishermen Colony',
  'Pedagantyada Main Road',
  'Appikonda & Balacheruvu',
  'Parawada & JN Pharma City North',
  'Tadi & Coast Guard Base Area',
  'Pudimadaka Road & Coastal Belt',
  'Atchutapuram Corridor North',
  'Atchutapuram Industrial Park',
  'Pendurthi Main Market & Panchayat',
  'Rampuram & Gorapalli',
  'Sabbavaram Road & Law University',
  'Pinagadi & Water Works Lake',
  'Vepagunta South & SC Colony',
  'Narava & Engineering College Rd',
  'Desapatrunipalem West',
  'Anandapuram South & Suburb Belt'
];

export function getZoneName(wardNum: number): string {
  if (wardNum <= 10) return 'Zone 1 (Bheemunipatnam Corridor)';
  if (wardNum <= 20) return 'Zone 2 (Madhurawada & Rushikonda)';
  if (wardNum <= 30) return 'Zone 3 (MVP Colony & Seethammadhara)';
  if (wardNum <= 40) return 'Zone 4 (Asilmetta & Central Area)';
  if (wardNum <= 50) return 'Zone 5 (Jagadamba & Old City Center)';
  if (wardNum <= 60) return 'Zone 6 (Gopalapatnam & Simhachalam)';
  if (wardNum <= 70) return 'Zone 7 (Gajuwaka Industrial South)';
  if (wardNum <= 80) return 'Zone 8 (Steel Plant & Kurmannapalem)';
  if (wardNum <= 90) return 'Zone 9 (Vadlapudi & Duvvada)';
  return 'Zone 10 (Pendurthi & Suburbs)';
}

const OFFICER_NAMES = [
  'Sri K. Venkat Rao', 'Smt. P. Lakshmi Devi', 'Sri M. Suresh Kumar', 'Sri B. Appala Naidu',
  'Sri G. Ramana Murthy', 'Sri T. Satyanarayana', 'Smt. D. Sunitha', 'Sri R. Srinivas',
  'Smt. K. Anitha', 'Sri V. Prasad', 'Sri N. Ramesh', 'Smt. M. Saraswathi',
  'Sri Ch. Nageswara Rao', 'Smt. G. Bhavani', 'Sri P. Srimannarayana', 'Sri A. Subba Rao',
  'Smt. T. Rajeswari', 'Sri B. Mohan Rao', 'Sri D. Krishna Murthy', 'Smt. S. Padma',
  'Sri Y. Venkatesh', 'Smt. N. Lalitha', 'Sri K. Prabhakar', 'Sri S. Hanumantha Rao',
  'Smt. V. Dhanalakshmi', 'Sri M. Somasekhar', 'Sri G. Tirupathi Rao', 'Smt. B. Parvathi',
  'Sri K. Srinivasa Rao', 'Sri P. Jagannadham'
];

// Helper to construct all 98 wards dynamically with complete precision
function create98Wards(): Ward[] {
  const rawWards: Ward[] = [];

  const zoneCenterCoords: Record<number, [number, number]> = {
    1: [17.80, 83.38],
    2: [17.76, 83.34],
    3: [17.74, 83.32],
    4: [17.72, 83.30],
    5: [17.70, 83.29],
    6: [17.74, 83.24],
    7: [17.68, 83.21],
    8: [17.65, 83.19],
    9: [17.63, 83.21],
    10: [17.75, 83.18]
  };

  for (let num = 1; num <= 98; num++) {
    const zoneNum = Math.ceil(num <= 90 ? num / 10 : 10);
    const [centerLat, centerLng] = zoneCenterCoords[zoneNum] || [17.71, 83.31];

    const offsetLat = ((num % 10) - 5) * 0.004;
    const offsetLng = (Math.floor((num - 1) / 10) - 4) * 0.003;

    const baseLat = Math.round((centerLat + offsetLat) * 1000) / 1000;
    const baseLng = Math.round((centerLng + offsetLng) * 1000) / 1000;

    // Specific custom scores for highlighted wards
    let perfScore = 75.0;
    if (num === 14) perfScore = 98.5;
    else if (num === 12) perfScore = 96.8;
    else if (num === 8) perfScore = 95.2;
    else if (num === 1) perfScore = 94.1;
    else if (num === 18) perfScore = 92.5;
    else if (num === 45) perfScore = 87.2;
    else if (num === 24) perfScore = 81.4;
    else if (num === 32) perfScore = 78.0;
    else {
      // Deterministic spread between 54.0 and 93.5
      const pseudo = (num * 37 + (num % 7) * 13) % 40;
      perfScore = Math.round((93.5 - pseudo * 0.95) * 10) / 10;
    }

    const complaintCount = Math.floor(18 + ((num * 17) % 75));
    const resolutionRate = Math.min(0.98, Math.max(0.60, perfScore / 100));
    const resolvedCount = Math.floor(complaintCount * resolutionRate);
    const pendingCount = Math.max(1, complaintCount - resolvedCount);
    const avgResolutionHours = Math.round((38.0 - (perfScore * 0.28)) * 10) / 10;

    rawWards.push({
      id: num,
      number: num,
      name: ALL_WARD_NAMES[num - 1] || `Ward ${num} Locality`,
      zone: getZoneName(num),
      population: 28000 + ((num * 1234) % 55000),
      complaintCount,
      resolvedCount,
      pendingCount,
      avgResolutionHours: Math.max(6.5, avgResolutionHours),
      performanceIndex: perfScore,
      ranking: 0, // Will be computed below
      officerName: OFFICER_NAMES[(num - 1) % OFFICER_NAMES.length],
      officerContact: `+91 94401 ${23400 + num}`,
      boundary: [
        [baseLat - 0.005, baseLng - 0.005],
        [baseLat + 0.005, baseLng - 0.004],
        [baseLat + 0.004, baseLng + 0.005],
        [baseLat - 0.004, baseLng + 0.004],
        [baseLat - 0.005, baseLng - 0.005]
      ]
    });
  }

  // Calculate unique strict ranking #1 to #98 sorted by performance index
  const sortedByPerf = [...rawWards].sort((a, b) => b.performanceIndex - a.performanceIndex);
  sortedByPerf.forEach((w, rankIdx) => {
    const found = rawWards.find(r => r.id === w.id);
    if (found) {
      found.ranking = rankIdx + 1;
    }
  });

  // Return in numerical ward order (1, 2, 3, ..., 98)
  return rawWards.sort((a, b) => a.number - b.number);
}

export const INITIAL_WARDS: Ward[] = create98Wards();

export const INITIAL_WORKERS: Worker[] = [
  {
    id: 'WRK-101',
    name: 'Ramu Kurakula',
    category: 'Water Leakage & Supply',
    phone: '+91 98480 11221',
    wardId: 14,
    wardName: 'Waltair Uplands & RK Beach',
    lat: 17.7115,
    lng: 83.3220,
    activeComplaints: 1,
    status: 'AVAILABLE',
    efficiencyRating: 4.9
  },
  {
    id: 'WRK-102',
    name: 'Chiranjeevi Y.',
    category: 'Potholes & Roads',
    phone: '+91 98480 11222',
    wardId: 14,
    wardName: 'Waltair Uplands & RK Beach',
    lat: 17.7080,
    lng: 83.3250,
    activeComplaints: 2,
    status: 'ON_JOB',
    efficiencyRating: 4.7
  },
  {
    id: 'WRK-103',
    name: 'Govinda Rao M.',
    category: 'Garbage & Sanitation',
    phone: '+91 98480 11223',
    wardId: 12,
    wardName: 'MVP Colony (Sectors 1-12)',
    lat: 17.7380,
    lng: 83.3280,
    activeComplaints: 0,
    status: 'AVAILABLE',
    efficiencyRating: 4.8
  },
  {
    id: 'WRK-104',
    name: 'Srinivasulu P.',
    category: 'Street Light & Power',
    phone: '+91 98480 11224',
    wardId: 18,
    wardName: 'Maddilapalem & AU Campus',
    lat: 17.7240,
    lng: 83.3150,
    activeComplaints: 3,
    status: 'ON_JOB',
    efficiencyRating: 4.5
  },
  {
    id: 'WRK-105',
    name: 'Nageswara Rao T.',
    category: 'Drainage Overflow',
    phone: '+91 98480 11225',
    wardId: 24,
    wardName: 'Gajuwaka Main Road',
    lat: 17.6880,
    lng: 83.2110,
    activeComplaints: 1,
    status: 'AVAILABLE',
    efficiencyRating: 4.6
  }
];

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'GVMC-2026-8812',
    title: 'Severe Water Pipe Burst near Submarine Museum',
    description: 'High pressure drinking water main line ruptured spilling thousands of liters onto Beach Road near Submarine Museum. Road traffic impeded and water pressure dropped in Ward 14.',
    originalDescription: 'Submarine Museum daggara drinking water pipeline burst ayyindi. Chala neellu waste avtunnai, road paina water overflow avtundi.',
    category: 'Water Leakage & Supply',
    priority: 'P1_CRITICAL',
    status: 'IN_PROGRESS',
    wardId: 14,
    wardName: 'Waltair Uplands & RK Beach',
    zoneName: 'Zone 2 (Central)',
    lat: 17.7125,
    lng: 83.3284,
    landmark: 'Opposite Kursura Submarine Museum, RK Beach Road',
    imageUrl: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
    createdAt: '2026-07-31T04:15:00Z',
    updatedAt: '2026-07-31T05:20:00Z',
    citizenName: 'Ravi Teja Varma',
    citizenPhone: '+91 99890 12345',
    assignedWorkerId: 'WRK-101',
    assignedWorkerName: 'Ramu Kurakula',
    assignedWorkerPhone: '+91 98480 11221',
    sentimentScore: 'HIGH_DISTRESS',
    language: 'TE',
    translatedVersion: {
      EN: 'High pressure drinking water main line ruptured spilling thousands of liters onto Beach Road near Submarine Museum. Road traffic impeded.',
      TE: 'Submarine Museum daggara drinking water pipeline burst ayyindi. Chala neellu waste avtunnai, road paina water overflow avtundi.',
      HI: 'सबमरीन म्यूजियम के पास पेयजल की मुख्य पाइपलाइन फट गई है। सड़कों पर भारी जलभराव हो रहा है।'
    },
    slaHours: 12,
    hoursRemaining: 4.5,
    officerNotes: 'Emergency valve closure dispatched. Worker Ramu on site repairing pipeline joint.',
    aiSummary: 'Critical P1 water pipe burst affecting Ward 14. High volume spillage requires immediate hydraulic isolation.'
  },
  {
    id: 'GVMC-2026-8810',
    title: 'Deep Dangerous Pothole near Siripuram Circle',
    description: 'Large 2-foot deep pothole formed post rain near Siripuram Junction causing heavy two-wheeler skidding risk during evening peak hours.',
    category: 'Potholes & Roads',
    priority: 'P2_HIGH',
    status: 'ASSIGNED',
    wardId: 14,
    wardName: 'Waltair Uplands & RK Beach',
    zoneName: 'Zone 2 (Central)',
    lat: 17.7180,
    lng: 83.3190,
    landmark: 'Near Dutt Island Signal, Siripuram Circle',
    imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80',
    createdAt: '2026-07-31T02:30:00Z',
    updatedAt: '2026-07-31T03:10:00Z',
    citizenName: 'K. Sridevi',
    citizenPhone: '+91 98765 43210',
    assignedWorkerId: 'WRK-102',
    assignedWorkerName: 'Chiranjeevi Y.',
    assignedWorkerPhone: '+91 98480 11222',
    sentimentScore: 'URGENT',
    language: 'EN',
    slaHours: 24,
    hoursRemaining: 18.2,
    officerNotes: 'Hot mix asphalt patching crew assigned for midnight repair.',
    aiSummary: 'Road hazard on high density arterial corridor. High risk for commuter safety.'
  },
  {
    id: 'GVMC-2026-8805',
    title: 'Uncollected Commercial Garbage Heap in MVP Sector 4',
    description: 'Commercial vegetable waste accumulated outside Sector 4 vegetable market for 3 days attracting stray animals and blocking sidewalk.',
    category: 'Garbage & Sanitation',
    priority: 'P3_MEDIUM',
    status: 'WORKER_COMPLETED',
    wardId: 12,
    wardName: 'MVP Colony (Sectors 1-12)',
    zoneName: 'Zone 2 (Central)',
    lat: 17.7390,
    lng: 83.3310,
    landmark: 'Behind Sector 4 Rythu Bazar, MVP Colony',
    imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80',
    afterImageUrl: 'https://images.unsplash.com/photo-1618477247222-acfea0716b08?auto=format&fit=crop&w=800&q=80',
    createdAt: '2026-07-30T16:00:00Z',
    updatedAt: '2026-07-31T05:00:00Z',
    citizenName: 'M. Anand Rao',
    citizenPhone: '+91 91234 56789',
    assignedWorkerId: 'WRK-103',
    assignedWorkerName: 'Govinda Rao M.',
    assignedWorkerPhone: '+91 98480 11223',
    sentimentScore: 'NEUTRAL',
    language: 'EN',
    slaHours: 24,
    hoursRemaining: 0,
    officerNotes: 'Sanitation Compactor Truck cleared 1.8 tons of waste. Awaiting Citizen Verification.',
    aiSummary: 'Sanitation cleared by GVMC field team. Requires citizen sign-off.'
  },
  {
    id: 'GVMC-2026-8798',
    title: 'Non-Functional High-Mast LED Lights at Gajuwaka Flyover',
    description: '6 high-mast LED street lights extinguished on Gajuwaka flyover ramp causing pitch dark conditions at night on NH16 industrial traffic zone.',
    category: 'Street Light & Power',
    priority: 'P2_HIGH',
    status: 'COMMISSIONER_APPROVED',
    wardId: 24,
    wardName: 'Gajuwaka Main Road & Industrial Zone',
    zoneName: 'Zone 5 (Industrial South)',
    lat: 17.6890,
    lng: 83.2120,
    landmark: 'Gajuwaka Junction Flyover South Ramp',
    imageUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80',
    createdAt: '2026-07-29T20:15:00Z',
    updatedAt: '2026-07-31T01:00:00Z',
    citizenName: 'P. Nagesh',
    citizenPhone: '+91 94411 99887',
    assignedWorkerId: 'WRK-105',
    assignedWorkerName: 'Nageswara Rao T.',
    sentimentScore: 'URGENT',
    language: 'EN',
    slaHours: 36,
    hoursRemaining: 0,
    officerNotes: 'Electrical transformer driver board replaced. Verified and approved by Additional Commissioner.',
    aiSummary: 'Critical street lighting restored on NH16 flyover junction.'
  },
  {
    id: 'GVMC-2026-8820',
    title: 'Open Underground Stormwater Drain overflowing near AU Gate',
    description: 'Clogged storm drain choking with plastic debris causing black sewage water overflow onto Maddilapalem main road.',
    category: 'Drainage Overflow',
    priority: 'P1_CRITICAL',
    status: 'RAISED',
    wardId: 18,
    wardName: 'Maddilapalem & AU Campus',
    zoneName: 'Zone 4 (East)',
    lat: 17.7260,
    lng: 83.3180,
    landmark: 'Near AU Engineering College North Gate, Maddilapalem',
    imageUrl: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b2?auto=format&fit=crop&w=800&q=80',
    createdAt: '2026-07-31T05:10:00Z',
    updatedAt: '2026-07-31T05:10:00Z',
    citizenName: 'Dr. V. Prasad',
    citizenPhone: '+91 98499 88776',
    sentimentScore: 'HIGH_DISTRESS',
    language: 'HI',
    translatedVersion: {
      EN: 'Open underground stormwater drain choked with plastic overflow onto Maddilapalem road near AU Gate.',
      TE: 'Maddilapalem AU Gate daggara drainage kaluva overflow ayyindi. Plastic waste undadam valla sewage water road painaki vastundi.',
      HI: 'एयू गेट के पास नाला जाम होने के कारण गंदा पानी सड़क पर बह रहा है।'
    },
    slaHours: 12,
    hoursRemaining: 11.5,
    aiSummary: 'P1 Urgent Drainage obstruction. Desilting machine required immediately.'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'NOTIF-1',
    title: 'P1 Emergency Escalation',
    message: 'Water Main Burst near Submarine Museum reported in Ward 14 (SLA: 12 hrs). Worker Ramu dispatched.',
    timestamp: '10 mins ago',
    type: 'ALERT',
    recipientRole: 'WARD_OFFICER',
    complaintId: 'GVMC-2026-8812',
    isRead: false
  },
  {
    id: 'NOTIF-2',
    title: 'Citizen Verification Pending',
    message: 'Garbage heap cleared in MVP Colony Sector 4. Awaiting citizen rating.',
    timestamp: '45 mins ago',
    type: 'INFO',
    recipientRole: 'CITIZEN',
    complaintId: 'GVMC-2026-8805',
    isRead: false
  },
  {
    id: 'NOTIF-3',
    title: 'Commissioner SLA Approval',
    message: 'Special fund sanctioned for Gajuwaka Flyover High-Mast LED Replacement.',
    timestamp: '2 hours ago',
    type: 'SUCCESS',
    recipientRole: 'COMMISSIONER',
    complaintId: 'GVMC-2026-8798',
    isRead: true
  }
];
