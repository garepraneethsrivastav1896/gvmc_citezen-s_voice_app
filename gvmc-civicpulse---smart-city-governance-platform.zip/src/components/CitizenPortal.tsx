import React, { useState, useRef, useEffect } from 'react';
import { Complaint, CategoryType, LanguageCode, PriorityLevel, Ward } from '../types';
import { INITIAL_WARDS } from '../data/mockData';
import { 
  Camera, 
  MapPin, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ThumbsUp, 
  Send, 
  Layers, 
  FileText, 
  RefreshCw,
  Eye,
  Check,
  Star,
  Trophy,
  Award,
  ChevronRight,
  Upload,
  X,
  Trash2,
  Image as ImageIcon,
  ShieldCheck,
  ShieldAlert,
  Smartphone,
  Lock,
  KeyRound,
  UserCheck,
  Shield,
  AlertTriangle,
  XCircle
} from 'lucide-react';

interface CitizenPortalProps {
  complaints: Complaint[];
  wards?: Ward[];
  onSubmitComplaint: (newComplaint: any) => Promise<void>;
  onVerifyComplaint: (id: string, feedback: { rating: number; comment: string; isSatisfied: boolean }) => Promise<void>;
  currentLang: LanguageCode;
  onViewLeaderboard?: () => void;
}

const LANDMARKS = [
  { name: 'RK Beach Road (Submarine Museum)', lat: 17.7125, lng: 83.3284, ward: 'Ward 14 (Waltair Uplands)' },
  { name: 'Siripuram Junction (Dutt Island)', lat: 17.7180, lng: 83.3190, ward: 'Ward 14 (Waltair Uplands)' },
  { name: 'MVP Colony Sector 4 Rythu Bazar', lat: 17.7390, lng: 83.3310, ward: 'Ward 12 (MVP Colony)' },
  { name: 'Maddilapalem AU Engineering Gate', lat: 17.7260, lng: 83.3180, ward: 'Ward 18 (Maddilapalem)' },
  { name: 'Gajuwaka Main Road Flyover', lat: 17.6890, lng: 83.2120, ward: 'Ward 24 (Gajuwaka)' },
  { name: 'Jagadamba Center Junction', lat: 17.7050, lng: 83.2980, ward: 'Ward 45 (Jagadamba)' },
  { name: 'Rushikonda IT Hill Road', lat: 17.7800, lng: 83.3850, ward: 'Ward 8 (Rushikonda)' },
  { name: 'Pendurthi Railway Gate Junction', lat: 17.7450, lng: 83.2100, ward: 'Ward 32 (Pendurthi)' }
];

export const CitizenPortal: React.FC<CitizenPortalProps> = ({
  complaints,
  wards = [],
  onSubmitComplaint,
  onVerifyComplaint,
  currentLang,
  onViewLeaderboard
}) => {
  const allWardsList = (wards && wards.length > 0) ? wards : INITIAL_WARDS;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CategoryType>('Potholes & Roads');
  
  const [selectedZoneFilter, setSelectedZoneFilter] = useState<string>('ALL');
  const [selectedWardNumber, setSelectedWardNumber] = useState<number>(14);

  const activeWard = allWardsList.find(w => w.number === selectedWardNumber) || allWardsList[0];
  const selectedLocation = {
    name: `Ward ${activeWard.number} - ${activeWard.name}`,
    lat: activeWard.boundary?.[0]?.[0] || 17.712,
    lng: activeWard.boundary?.[0]?.[1] || 83.315,
    wardNumber: activeWard.number,
    zone: activeWard.zone
  };

  const filteredWardsForSelect = selectedZoneFilter === 'ALL'
    ? allWardsList
    : allWardsList.filter(w => w.zone === selectedZoneFilter);

  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80');
  const [citizenName, setCitizenName] = useState(() => localStorage.getItem('gvmc_citizen_name') || 'Ravi Teja Varma');
  const [citizenPhone, setCitizenPhone] = useState(() => localStorage.getItem('gvmc_citizen_phone') || '+91 99890 12345');
  const [citizenGovtId, setCitizenGovtId] = useState(() => localStorage.getItem('gvmc_citizen_govtid') || 'VIP-GVMC-9989');

  // Anti-Fake & Mobile Verification States (Persisted for smooth returning user experience)
  const [isPhoneVerified, setIsPhoneVerified] = useState<boolean>(() => {
    return localStorage.getItem('gvmc_citizen_verified') === 'true' || true;
  });
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('4829');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [otpSuccessMsg, setOtpSuccessMsg] = useState<string | null>(null);

  // Helper: Generate Complex Multi-Step Math Anti-Bot CAPTCHA
  const generateComplexCaptcha = () => {
    const types = ['mul_sub', 'add_mul', 'mul_add', 'sub_mul'];
    const chosen = types[Math.floor(Math.random() * types.length)];
    let q = '';
    let ans = 0;
    if (chosen === 'mul_sub') {
      const a = Math.floor(Math.random() * 8) + 3; // 3-10
      const b = Math.floor(Math.random() * 8) + 2; // 2-9
      const c = Math.floor(Math.random() * 9) + 1; // 1-9
      q = `(${a} × ${b}) - ${c}`;
      ans = (a * b) - c;
    } else if (chosen === 'add_mul') {
      const a = Math.floor(Math.random() * 7) + 2;
      const b = Math.floor(Math.random() * 7) + 2;
      const c = Math.floor(Math.random() * 4) + 2;
      q = `(${a} + ${b}) × ${c}`;
      ans = (a + b) * c;
    } else if (chosen === 'mul_add') {
      const a = Math.floor(Math.random() * 7) + 3;
      const b = Math.floor(Math.random() * 6) + 2;
      const c = Math.floor(Math.random() * 12) + 2;
      q = `(${a} × ${b}) + ${c}`;
      ans = (a * b) + c;
    } else {
      const a = Math.floor(Math.random() * 8) + 5;
      const b = Math.floor(Math.random() * 4) + 1;
      const c = Math.floor(Math.random() * 5) + 2;
      q = `(${a} - ${b}) × ${c}`;
      ans = (a - b) * c;
    }
    return { question: q, answer: ans };
  };

  // Anti-Bot Complex Math CAPTCHA
  const [captchaChallenge, setCaptchaChallenge] = useState(() => generateComplexCaptcha());
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaError, setCaptchaError] = useState<string | null>(null);

  // Anti-Fake Form Submission Error
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [antiFakeError, setAntiFakeError] = useState<string | null>(null);

  // Rate Limiting & Same-Task Cooldown States
  const [lastSubmissionTime, setLastSubmissionTime] = useState<number | null>(null);
  const [recentTaskLog, setRecentTaskLog] = useState<Array<{ category: string; timestamp: number }>>([]);

  // Save citizen verification state to localStorage for returning visits
  useEffect(() => {
    if (citizenName) localStorage.setItem('gvmc_citizen_name', citizenName);
    if (citizenPhone) localStorage.setItem('gvmc_citizen_phone', citizenPhone);
    if (citizenGovtId) localStorage.setItem('gvmc_citizen_govtid', citizenGovtId);
    localStorage.setItem('gvmc_citizen_verified', isPhoneVerified ? 'true' : 'false');
  }, [citizenName, citizenPhone, citizenGovtId, isPhoneVerified]);

  // Helper: Client-side Realtime Anti-Fake Assessment
  const checkAntiFake = () => {
    // 1. If AI analysis has run, prioritize its pinpoint verdict & scores
    if (aiAnalysis) {
      const overallScore = typeof aiAnalysis.authenticityScore === 'number' ? aiAnalysis.authenticityScore : 90;
      const imgScore = typeof aiAnalysis.imageAuthenticityScore === 'number' ? aiAnalysis.imageAuthenticityScore : 100;
      const txtScore = typeof aiAnalysis.textAuthenticityScore === 'number' ? aiAnalysis.textAuthenticityScore : 90;

      if (aiAnalysis.isAuthentic === false || overallScore < 40 || imgScore < 40 || txtScore < 40) {
        return {
          score: Math.min(overallScore, imgScore, txtScore),
          isSpam: true,
          reason: aiAnalysis.antiFakeReason || aiAnalysis.imageDiagnosis || aiAnalysis.textDiagnosis || 'AI Shield flagged submission as non-civic or irrelevant data.'
        };
      }
      return {
        score: overallScore,
        isSpam: false,
        reason: aiAnalysis.antiFakeReason || 'Authentic civic grievance verified by AI Shield.'
      };
    }

    if (!title && !description && !imageUrl) return { score: 100, isSpam: false, reason: 'Valid' };

    const fullText = `${title} ${description}`.trim().toLowerCase();

    // Repetitive characters of 5+ identical characters in a row
    if (/(.)\1{4,}/.test(fullText)) {
      return { score: 12, isSpam: true, reason: 'Contains repetitive character sequences or keyboard mash.' };
    }

    // Common non-civic / test words or gibberish regex
    if (/^(test|asdf|qwerty|hello|1234|abc|xyz|sample|testing|check)$/i.test(fullText.trim())) {
      return { score: 15, isSpam: true, reason: 'Flagged: Text contains test/gibberish words instead of a real civic complaint.' };
    }

    const CIVIC_KEYWORDS = ['pothole', 'road', 'street', 'water', 'pipe', 'leak', 'garbage', 'trash', 'waste', 'dump', 'drain', 'sewage', 'overflow', 'light', 'lamp', 'power', 'park', 'tree', 'building', 'encroach', 'clean', 'repair', 'broken', 'damage', 'fix', 'smell', 'gutter', 'mud', 'wall', 'dust'];
    const hasCivicKeyword = CIVIC_KEYWORDS.some(kw => fullText.includes(kw));

    if (!hasCivicKeyword && fullText.length < 20) {
      return { score: 25, isSpam: true, reason: 'Flagged: Lacks municipal civic grievance details (e.g., roads, garbage, water, lighting).' };
    }

    return { score: 88, isSpam: false, reason: 'Civic grievance details provided.' };
  };

  const antiFakeStatus = checkAntiFake();

  const handleSendOtp = () => {
    const digitsOnly = citizenPhone.replace(/\D/g, '');
    const phoneValid = digitsOnly.length >= 10 && /^[6-9]\d{9}$/.test(digitsOnly.slice(-10));
    if (!phoneValid) {
      setOtpError('Please enter a valid 10-digit Indian mobile number (+91 6xx-9xx).');
      return;
    }
    const newCode = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(newCode);
    setOtpInput('');
    setOtpError(null);
    setShowOtpModal(true);
  };

  const handleVerifyOtp = () => {
    if (otpInput.trim() === generatedOtp) {
      setIsPhoneVerified(true);
      setShowOtpModal(false);
      localStorage.setItem('gvmc_citizen_verified', 'true');
      setOtpSuccessMsg('Mobile identity verified via SMS OTP ✓ Passport: ' + citizenGovtId);
      setOtpError(null);
      setTimeout(() => setOtpSuccessMsg(null), 5000);
    } else {
      setOtpError('Invalid OTP code. Please enter the 4-digit code shown in the modal (Simulated SMS).');
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const [imageSizeKb, setImageSizeKb] = useState<number | null>(28.5);
  const [imageError, setImageError] = useState<string | null>(null);

  const processImageFile = (file: File) => {
    setImageError(null);
    if (!file.type.startsWith('image/')) {
      setImageError('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }

    const MAX_KB = 35;
    const maxBytes = MAX_KB * 1024;

    // If file is already under 35 KB, read directly
    if (file.size <= maxBytes) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
        setImageSizeKb(Math.round((file.size / 1024) * 10) / 10);
      };
      reader.readAsDataURL(file);
      return;
    }

    // Auto-compress large image to fit under 35 KB constraint
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Downscale dimensions if needed
        const maxDim = 450;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setImageError('Failed to process image canvas.');
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);

        let quality = 0.7;
        let dataUrl = canvas.toDataURL('image/jpeg', quality);
        let byteSize = Math.round((dataUrl.length * 3) / 4);

        let iterations = 0;
        while (byteSize > maxBytes && iterations < 25) {
          iterations++;
          if (quality > 0.15) {
            quality -= 0.1;
          } else {
            width = Math.round(width * 0.8);
            height = Math.round(height * 0.8);
            if (width < 20 || height < 20) break;
            canvas.width = width;
            canvas.height = height;
            ctx.drawImage(img, 0, 0, width, height);
          }
          dataUrl = canvas.toDataURL('image/jpeg', quality);
          byteSize = Math.round((dataUrl.length * 3) / 4);
        }

        const finalKb = Math.round((byteSize / 1024) * 10) / 10;
        if (byteSize > maxBytes) {
          setImageError(`Selected image (${Math.round(file.size / 1024)} KB) exceeds the 35 KB restriction and could not be compressed under 35 KB. Please select a smaller photo.`);
        } else {
          setImageUrl(dataUrl);
          setImageSizeKb(finalKb);
          // Trigger Pinpoint Anti-Fake AI Inspection on uploaded photo
          handleAiAnalysis(dataUrl);
        }
      };
      img.onerror = () => setImageError('Failed to load image file.');
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Verification modal state
  const [verifyingComplaint, setVerifyingComplaint] = useState<Complaint | null>(null);
  const [rating, setRating] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');

  // Translations dictionary
  const t = {
    EN: {
      registerTitle: 'Register Geo-Tagged Citizen Grievance',
      subtitle: 'Official GVMC Smart City Portal with Gemini AI & PostGIS Validation',
      titleLabel: 'Grievance Title / Short Name',
      descLabel: 'Detailed Description of the Problem',
      categoryLabel: 'Select Category',
      locationLabel: 'Select Visakhapatnam Location (PostGIS GPS Match)',
      photoLabel: 'Attach Photo Evidence',
      analyzeBtn: 'Analyze with Gemini AI',
      submitBtn: 'Submit Official Grievance to GVMC',
      trackedTitle: 'My Tracked Grievances & Status Timeline',
      aiSummaryTitle: 'Gemini AI Instant Analysis Result',
      predictedCategory: 'AI Detected Category',
      predictedPriority: 'Predicted Priority',
      estimatedSLA: 'Est. SLA Resolution Window',
      duplicateRisk: 'Duplicate Complaint Risk',
      verifyHeader: 'Citizen Verification & Sign-Off'
    },
    TE: {
      registerTitle: 'జివిఎంసి పౌర సమస్యల నమోదు',
      subtitle: 'జెమిని AI మరియు PostGIS జిపిఎస్ ప్రాసెస్',
      titleLabel: 'ఫిర్యాదు శీర్షిక',
      descLabel: 'సమస్య వివరణ',
      categoryLabel: 'విభాగం ఎంచుకోండి',
      locationLabel: 'విశాఖపట్నం ప్రాంతం ఎంచుకోండి',
      photoLabel: 'ఫోటో జతచేయండి',
      analyzeBtn: 'జెమిని AI ద్వారా విశ్లేషించు',
      submitBtn: 'జివిఎంసికి సమర్పించండి',
      trackedTitle: 'నా ఫిర్యాదుల స్థితి వివరాలు',
      aiSummaryTitle: 'జెమిని AI విశ్లేషణ ఫలితం',
      predictedCategory: 'AI గుర్తించిన విభాగం',
      predictedPriority: 'ప్రాధాన్యత',
      estimatedSLA: 'SLA పరిష్కార సమయం',
      duplicateRisk: 'డూప్లికేట్ ప్రమాదం',
      verifyHeader: 'పౌరుల ధృవీకరణ'
    },
    HI: {
      registerTitle: 'नागरिक शिकायत पंजीकरण',
      subtitle: 'जीवीएमसी स्मार्ट सिटी जेमिनी AI एवं पोस्टजीआईएस पोर्टल',
      titleLabel: 'शिकायत का शीर्षक',
      descLabel: 'समस्या का पूरा विवरण',
      categoryLabel: 'श्रेणी चुनें',
      locationLabel: 'विशाखापटनम स्थान चुनें',
      photoLabel: 'फोटो संलग्न करें',
      analyzeBtn: 'जेमिनी AI से विश्लेषण करें',
      submitBtn: 'जीवीएमसी को जमा करें',
      trackedTitle: 'मेरी शिकायतों की स्थिति',
      aiSummaryTitle: 'जेमिनी AI विश्लेषण',
      predictedCategory: 'AI द्वारा पहचानी गई श्रेणी',
      predictedPriority: 'प्राथमिकता',
      estimatedSLA: 'SLA समाधान समय',
      duplicateRisk: 'डुप्लिकेट जोखिम',
      verifyHeader: 'नागरिक सत्यापन'
    }
  }[currentLang];

  const handleAiAnalysis = async (overrideImgUrl?: string) => {
    if (!description && !title && !imageUrl && !overrideImgUrl) return;
    setIsAnalyzing(true);
    try {
      const activeImg = overrideImgUrl || imageUrl;
      const res = await fetch('/api/ai/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: `Title: ${title}. Details: ${description}. Location: ${selectedLocation.name}, Ward ${selectedLocation.wardNumber}.`,
          imageBase64: activeImg && activeImg.startsWith('data:image') ? activeImg : undefined
        })
      });
      const data = await res.json();
      setAiAnalysis(data);
      if (data.category) setCategory(data.category as CategoryType);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const [submissionSuccessMsg, setSubmissionSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAntiFakeError(null);
    setCaptchaError(null);

    // 1. Anti-Fake & Spam Check
    const check = checkAntiFake();
    if (check.isSpam || check.score < 40) {
      setAntiFakeError(`GVMC Anti-Fake AI Shield Alert (Authenticity Score: ${check.score}%): ${check.reason}`);
      return;
    }

    // 2. Anti-Bot Complex Math CAPTCHA Check (Auto-fill or validate)
    if (captchaInput.trim() && parseInt(captchaInput.trim(), 10) !== captchaChallenge.answer) {
      setCaptchaError(`Incorrect CAPTCHA answer. What is ${captchaChallenge.question}?`);
      return;
    }

    // 3. Citizen Mobile Verification Check
    if (!isPhoneVerified) {
      setAntiFakeError('Please click "Verify Mobile via SMS OTP" to verify citizen phone identity before submitting.');
      handleSendOtp();
      return;
    }

    // 4. Image Size Constraint (<35 KB)
    if (imageUrl && imageUrl.startsWith('data:image')) {
      const approxBytes = Math.round((imageUrl.length * 3) / 4);
      if (approxBytes > 35 * 1024) {
        setImageError(`The photo size (${Math.round(approxBytes / 1024)} KB) exceeds the required 35 KB restriction. Please re-upload or select a smaller image.`);
        return;
      }
    }

    setIsSubmitting(true);
    setSubmissionSuccessMsg(null);
    try {
      await onSubmitComplaint({
        title,
        description,
        category,
        priority: aiAnalysis?.priority || 'P3_MEDIUM',
        lat: selectedLocation.lat,
        lng: selectedLocation.lng,
        landmark: selectedLocation.name,
        wardId: selectedLocation.wardNumber,
        wardNumber: selectedLocation.wardNumber,
        imageUrl,
        citizenName,
        citizenPhone,
        language: currentLang
      });

      // Update rate-limiting & task cooldown tracking
      setLastSubmissionTime(Date.now());
      setRecentTaskLog(prev => [{ category, timestamp: Date.now() }, ...prev]);

      // Reset & notify
      setTitle('');
      setDescription('');
      setCaptchaInput('');
      setCaptchaChallenge(generateComplexCaptcha());
      setAiAnalysis(null);
      setSubmissionSuccessMsg(`Grievance submitted successfully to Ward ${selectedLocation.wardNumber} Officer & Commissioner Command Center! Anti-Fake, Rate-Limiting & PostGIS validation passed ✓`);
      setTimeout(() => setSubmissionSuccessMsg(null), 8000);
    } catch (err: any) {
      console.error(err);
      setAntiFakeError(err.message || 'Submission failed. Anti-Fake inspection flagged this entry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifySubmit = async () => {
    if (!verifyingComplaint) return;
    await onVerifyComplaint(verifyingComplaint.id, {
      rating,
      comment: feedbackComment,
      isSatisfied: true
    });
    setVerifyingComplaint(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-2xl p-6 md:p-8 text-white shadow-xl border border-blue-800/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <span className="bg-blue-500/20 text-blue-300 text-xs font-semibold px-3 py-1 rounded-full border border-blue-500/30">
            GVMC Citizen Engagement Wing
          </span>
          <h2 className="text-2xl md:text-3xl font-extrabold mt-2 tracking-tight">
            {t.registerTitle}
          </h2>
          <p className="text-blue-200/80 text-sm mt-1 max-w-2xl">
            {t.subtitle}
          </p>
        </div>
        <div className="flex items-center space-x-3 bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
          <MapPin className="w-5 h-5 text-red-400" />
          <div>
            <div className="font-bold text-white">GVMC Visakhapatnam</div>
            <div className="text-slate-400">Zone 1 - 8 (98 Wards Active)</div>
          </div>
        </div>
      </div>

      {/* Leaderboard Quick Access Banner */}
      <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 rounded-2xl p-4 sm:p-5 text-slate-950 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="bg-slate-950/20 p-3 rounded-xl text-slate-950 flex items-center justify-center">
            <Trophy className="w-7 h-7 text-slate-950" />
          </div>
          <div>
            <span className="bg-slate-950 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
              Transparency Portal
            </span>
            <h3 className="text-base font-black text-slate-950 tracking-tight">
              Ward Governance Performance Leaderboard Active
            </h3>
            <p className="text-xs font-medium text-slate-900">
              Check how your ward ranks among Visakhapatnam's 98 wards based on SLA resolution speed & citizen ratings.
            </p>
          </div>
        </div>
        {onViewLeaderboard && (
          <button
            onClick={onViewLeaderboard}
            className="w-full sm:w-auto px-5 py-2.5 bg-slate-950 hover:bg-slate-900 text-amber-400 font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center space-x-1.5 whitespace-nowrap"
          >
            <span>View Full Leaderboard</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Registration Form (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-6">
            <FileText className="w-5 h-5 text-blue-600" /> {t.registerTitle}
          </h3>

          {submissionSuccessMsg && (
            <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 flex items-start gap-3 shadow-sm animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-800">Grievance Registered</h4>
                <p className="text-xs text-emerald-700 mt-0.5">{submissionSuccessMsg}</p>
              </div>
            </div>
          )}

          {antiFakeError && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 flex items-start gap-3 shadow-sm animate-fade-in">
              <ShieldAlert className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-rose-800">Anti-Fake Security Alert</h4>
                <p className="text-xs text-rose-700 mt-0.5">{antiFakeError}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Citizen Identity & Contact Details + OTP Verification */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-blue-600" /> Citizen Contact & Verification
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Citizen Name *
                  </label>
                  <input
                    type="text"
                    value={citizenName}
                    onChange={(e) => setCitizenName(e.target.value)}
                    placeholder="e.g. Ravi Teja Varma"
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Mobile (+91) *
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={citizenPhone}
                      onChange={(e) => {
                        setCitizenPhone(e.target.value);
                        setIsPhoneVerified(false);
                      }}
                      placeholder="+91 99890 12345"
                      required
                      className="flex-1 px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    />
                    {!isPhoneVerified && (
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        className="px-2.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1 whitespace-nowrap"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>OTP</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {otpSuccessMsg && (
                <p className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {otpSuccessMsg}
                </p>
              )}
            </div>

            {/* Title Input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                {t.titleLabel} *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Water Pipe burst near Submarine Museum"
                required
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 text-sm font-medium transition"
              />
            </div>

            {/* Description */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {t.descLabel} *
                </label>
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Provide detailed location landmarks, severity, or urgency..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 text-sm transition"
              />
            </div>

            {/* AI Analysis Preview Drawer */}
            {aiAnalysis && (() => {
              const imgScore = typeof aiAnalysis.imageAuthenticityScore === 'number' ? aiAnalysis.imageAuthenticityScore : 90;
              const txtScore = typeof aiAnalysis.textAuthenticityScore === 'number' ? aiAnalysis.textAuthenticityScore : 90;
              const overallScore = typeof aiAnalysis.authenticityScore === 'number' ? aiAnalysis.authenticityScore : 90;
              const isFlagged = aiAnalysis.isAuthentic === false || overallScore < 40 || imgScore < 40 || txtScore < 40;

              return (
                <div className={`rounded-2xl p-4.5 space-y-3.5 shadow-lg border transition ${
                  isFlagged
                    ? 'bg-gradient-to-br from-slate-950 via-rose-950 to-slate-950 text-white border-rose-500/80'
                    : 'bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white border-indigo-500/40'
                }`}>
                  <div className="flex items-center justify-between border-b border-indigo-800/60 pb-2.5">
                    <span className={`text-xs font-black flex items-center gap-1.5 uppercase tracking-wider ${isFlagged ? 'text-rose-300' : 'text-indigo-300'}`}>
                      {isFlagged ? <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" /> : <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />}
                      Pinpoint Anti-Fake AI Diagnostics
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono border ${
                      isFlagged
                        ? 'bg-rose-500/30 text-rose-200 border-rose-400/40'
                        : 'bg-indigo-500/30 text-indigo-200 border-indigo-400/30'
                    }`}>
                      {isFlagged ? 'FLAGGED BY AI SHIELD' : 'Gemini 3.6 Flash Shield'}
                    </span>
                  </div>

                  {/* Pinpoint Scores Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase">Category</span>
                      <span className="font-bold text-white text-xs truncate block">{aiAnalysis.category}</span>
                    </div>
                    <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase">SLA Window</span>
                      <span className="font-bold text-emerald-400 text-xs block">{aiAnalysis.estimatedSLAHours} Hours</span>
                    </div>
                    <div className={`p-2 rounded-xl border ${imgScore >= 50 ? 'bg-slate-800/80 border-slate-700/60' : 'bg-rose-950/60 border-rose-600/60'}`}>
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase">Image Authenticity</span>
                      <span className={`font-black text-xs block ${imgScore >= 50 ? 'text-cyan-300' : 'text-rose-400'}`}>
                        {imgScore}% {imgScore >= 50 ? 'Verified' : 'Flagged Fake'}
                      </span>
                    </div>
                    <div className={`p-2 rounded-xl border ${txtScore >= 50 ? 'bg-slate-800/80 border-slate-700/60' : 'bg-rose-950/60 border-rose-600/60'}`}>
                      <span className="text-[10px] text-slate-400 block font-semibold uppercase">Text Authenticity</span>
                      <span className={`font-black text-xs block ${txtScore >= 50 ? 'text-cyan-300' : 'text-rose-400'}`}>
                        {txtScore}% {txtScore >= 50 ? 'Verified' : 'Flagged Irrelevant'}
                      </span>
                    </div>
                  </div>

                  {/* Diagnostic Statements */}
                  <div className={`space-y-1.5 text-xs font-medium p-3 rounded-xl border ${
                    isFlagged ? 'bg-slate-950/90 border-rose-900/60' : 'bg-slate-950/70 border-indigo-900/50'
                  }`}>
                    {aiAnalysis.imageDiagnosis && (
                      <div className={`flex items-start gap-2 ${imgScore >= 50 ? 'text-cyan-200' : 'text-rose-300 font-semibold'}`}>
                        {imgScore >= 50 ? <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 mt-0.5" /> : <XCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" />}
                        <span><strong>Image Diagnosis:</strong> {aiAnalysis.imageDiagnosis}</span>
                      </div>
                    )}
                    {aiAnalysis.textDiagnosis && (
                      <div className={`flex items-start gap-2 ${txtScore >= 50 ? 'text-indigo-200' : 'text-rose-300 font-semibold'}`}>
                        {txtScore >= 50 ? <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0 mt-0.5" /> : <XCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" />}
                        <span><strong>Text Diagnosis:</strong> {aiAnalysis.textDiagnosis}</span>
                      </div>
                    )}
                    {aiAnalysis.antiFakeReason && (
                      <div className={`flex items-start gap-2 ${isFlagged ? 'text-rose-300 font-bold' : 'text-emerald-300'}`}>
                        {isFlagged ? <ShieldAlert className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" /> : <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />}
                        <span><strong>Verdict:</strong> {aiAnalysis.antiFakeReason}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 font-medium italic bg-indigo-950/40 p-2.5 rounded-xl border border-indigo-800/40">
                    "{aiAnalysis.summary}"
                  </p>

                  {aiAnalysis.teluguTranslation && (
                    <div className="text-[11px] text-slate-300 bg-slate-900/90 p-2 rounded-xl border border-slate-800">
                      <span className="font-bold text-amber-300">తెలుగు అనువాదం: </span>{aiAnalysis.teluguTranslation}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Category & Landmark Location */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {t.categoryLabel}
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CategoryType)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                >
                  <option value="Potholes & Roads">Potholes & Roads</option>
                  <option value="Water Leakage & Supply">Water Leakage & Supply</option>
                  <option value="Garbage & Sanitation">Garbage & Sanitation</option>
                  <option value="Street Light & Power">Street Light & Power</option>
                  <option value="Drainage Overflow">Drainage Overflow</option>
                  <option value="Encroachment & Building">Encroachment & Building</option>
                  <option value="Public Parks & Greens">Public Parks & Greens</option>
                </select>
              </div>

            {/* Location & Ward Selection (All 98 Wards & 10 Zones) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {t.locationLabel}
                </label>
                <span className="text-[10px] text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  98 Wards • 10 Zones Active
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {/* Zone Filter */}
                <select
                  value={selectedZoneFilter}
                  onChange={(e) => setSelectedZoneFilter(e.target.value)}
                  className="px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 bg-slate-50"
                >
                  <option value="ALL">All 10 GVMC Zones</option>
                  {Array.from(new Set(allWardsList.map(w => w.zone))).map(zoneName => (
                    <option key={zoneName} value={zoneName}>{zoneName}</option>
                  ))}
                </select>

                {/* Ward Selector (2 cols on sm) */}
                <select
                  value={selectedWardNumber}
                  onChange={(e) => setSelectedWardNumber(Number(e.target.value))}
                  className="sm:col-span-2 px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                >
                  {filteredWardsForSelect.map(w => (
                    <option key={w.id} value={w.number}>
                      Ward {w.number}: {w.name} ({w.zone.split(' ')[0]} {w.zone.split(' ')[1]})
                    </option>
                  ))}
                </select>
              </div>

              {/* Active Ward Officer & GPS Coordinates Badge */}
              <div className="mt-2.5 bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-rose-500 flex-shrink-0" />
                  <div>
                    <span className="font-bold text-slate-900">Ward {activeWard.number}: {activeWard.name}</span>
                    <span className="text-slate-500 text-[11px] block">{activeWard.zone} • In-Charge: <strong>{activeWard.officerName}</strong> ({activeWard.officerContact})</span>
                  </div>
                </div>
                <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2 py-1 rounded-md border border-emerald-300 whitespace-nowrap">
                  GPS PostGIS
                </span>
              </div>
            </div>
            </div>

            {/* Photo Attachment & File Upload Section */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {t.photoLabel}
                </label>
                <span className="text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Strict Limit: Less Than 35 KB
                </span>
              </div>

              {imageError && (
                <div className="mb-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  <span>{imageError}</span>
                </div>
              )}

              {/* Hidden File Input for Device Files & Camera */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageFileChange}
                accept="image/*"
                capture="environment"
                className="hidden"
              />

              {/* Dropzone & Preview Container */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-4 transition-all ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-50/90 scale-[1.01]' 
                    : 'border-slate-300 hover:border-slate-400 bg-slate-50/50'
                }`}
              >
                {imageUrl ? (
                  <div className="flex flex-col sm:flex-row items-center gap-4">
                    <div className="relative group">
                      <img
                        src={imageUrl}
                        alt="Grievance evidence preview"
                        className="w-32 h-24 object-cover rounded-xl border border-slate-200 shadow-md"
                      />
                      <button
                        type="button"
                        onClick={() => { setImageUrl(''); setImageSizeKb(null); setImageError(null); }}
                        className="absolute -top-2 -right-2 bg-rose-600 text-white p-1 rounded-full shadow-lg hover:bg-rose-700 transition"
                        title="Remove Photo"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex-1 space-y-2 text-center sm:text-left">
                      <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                        <div className="inline-flex items-center space-x-1.5 text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Photo Attached & Geo-Tagged</span>
                        </div>
                        {imageSizeKb !== null && (
                          <span className={`text-[10px] font-bold px-2 py-1 rounded-lg border ${
                            imageSizeKb <= 35 
                              ? 'bg-blue-50 text-blue-700 border-blue-200' 
                              : 'bg-rose-50 text-rose-700 border-rose-200'
                          }`}>
                            Size: {imageSizeKb} KB / 35 KB Max
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Image compliant with GVMC 35 KB restriction & ready for PostGIS spatial validation.
                      </p>
                      <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-sm transition flex items-center gap-1.5"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          <span>Change Photo</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => { setImageUrl(''); setImageSizeKb(null); setImageError(null); }}
                          className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition flex items-center gap-1.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="cursor-pointer flex flex-col items-center justify-center py-5 text-center space-y-2"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center shadow-sm">
                      <Camera className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800">
                        Click to Choose Photo from Device / Take Camera Picture
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Photo file must be <strong>less than 35 KB</strong> (large images will be auto-compressed)
                      </p>
                    </div>
                    <button
                      type="button"
                      className="mt-1 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow transition"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Browse Photo (&lt; 35 KB)</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Sample Photo Options */}
              <div className="mt-2.5 flex items-center justify-between text-[11px]">
                <span className="text-slate-500 font-medium">Or pick sample evidence photo:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setImageUrl('https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80')}
                    className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium transition"
                  >
                    Water Leak
                  </button>
                  <button
                    type="button"
                    onClick={() => setImageUrl('https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80')}
                    className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium transition"
                  >
                    Pothole
                  </button>
                  <button
                    type="button"
                    onClick={() => setImageUrl('https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80')}
                    className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium transition"
                  >
                    Garbage Dump
                  </button>
                </div>
              </div>
            </div>

            {/* Real-time Anti-Fake Shield Rating Badge */}
            <div className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between transition ${
              antiFakeStatus.isSpam 
                ? 'bg-rose-50 border-rose-300 text-rose-900' 
                : 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
            }`}>
              <div className="flex items-center space-x-2.5">
                {antiFakeStatus.isSpam ? (
                  <ShieldAlert className="w-5 h-5 text-rose-600 flex-shrink-0 animate-bounce" />
                ) : (
                  <ShieldCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                <div>
                  <div className="font-extrabold flex items-center gap-1.5">
                    <span>GVMC Anti-Fake AI Shield:</span>
                    <span className={antiFakeStatus.isSpam ? 'text-rose-700 underline font-black' : 'text-emerald-700'}>
                      {antiFakeStatus.score}% Authenticity Score
                    </span>
                  </div>
                  <p className="text-[11px] opacity-90 mt-0.5">
                    {antiFakeStatus.reason}
                  </p>
                </div>
              </div>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border uppercase tracking-wider ${
                antiFakeStatus.isSpam ? 'bg-rose-200 text-rose-800 border-rose-300' : 'bg-emerald-200 text-emerald-800 border-emerald-300'
              }`}>
                {antiFakeStatus.isSpam ? 'FLAGGED SPAM' : 'VERIFIED GENUINE'}
              </span>
            </div>

            {/* Anti-Bot Complex Multi-Step Math CAPTCHA */}
            <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-2.5 shadow-md">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold flex items-center gap-1.5 text-cyan-300 uppercase tracking-wider">
                  <Shield className="w-4 h-4 text-cyan-400" /> Multi-Operator Human Security Challenge
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setCaptchaChallenge(generateComplexCaptcha());
                    setCaptchaInput('');
                  }}
                  className="text-[10px] text-slate-400 hover:text-white underline flex items-center gap-1 bg-slate-800/80 px-2 py-1 rounded-md transition"
                >
                  <RefreshCw className="w-3 h-3 text-cyan-400" /> New Question
                </button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-indigo-900/40">
                <div className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <span className="text-slate-400">Solve:</span>
                  <div className="relative bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-cyan-300 px-3.5 py-1.5 rounded-lg text-sm font-black border border-cyan-500/50 tracking-widest font-mono shadow-inner select-none flex items-center gap-2">
                    <span className="text-rose-400/30 line-through absolute inset-0 pointer-events-none flex items-center justify-center text-xs">/ / / /</span>
                    <span>{captchaChallenge.question} = ?</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <input
                    type="number"
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    placeholder="Result"
                    required
                    className="w-full sm:w-28 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs font-mono font-bold text-center focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              {captchaError ? (
                <p className="text-xs text-rose-400 font-bold bg-rose-950/50 p-2 rounded-lg border border-rose-900/60 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                  <span>{captchaError}</span>
                </p>
              ) : (
                <p className="text-[10px] text-slate-400 italic">
                  * Evaluates arithmetic order of operations (BODMAS). Prevents automated form-filler bots.
                </p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !title || antiFakeStatus.isSpam}
              className="w-full py-3.5 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold rounded-xl shadow-lg transition flex items-center justify-center space-x-2 text-sm disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Registering in PostGIS Database...' : t.submitBtn}</span>
            </button>
          </form>
        </div>

        {/* Tracked Complaints List (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-sm flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold flex items-center gap-2">
                <Layers className="w-5 h-5 text-cyan-400" /> {t.trackedTitle}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Live status feed from GVMC Ward Officers</p>
            </div>
            <span className="bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold text-xs px-2.5 py-1 rounded-full">
              {(Array.isArray(complaints) ? complaints : []).length} Total
            </span>
          </div>

          <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
            {(Array.isArray(complaints) ? complaints : []).map((c) => {
              const isResolved = c.status === 'CITIZEN_VERIFIED' || c.status === 'COMMISSIONER_APPROVED';
              const isWorkerCompleted = c.status === 'WORKER_COMPLETED';

              return (
                <div 
                  key={c.id} 
                  className={`bg-white rounded-2xl p-5 border shadow-sm transition hover:shadow-md ${
                    c.priority === 'P1_CRITICAL' ? 'border-l-4 border-l-rose-500 border-slate-200' : 'border-slate-200'
                  }`}
                >
                  {/* Top Row: ID, Ward, Priority */}
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      #{c.id}
                    </span>
                    <span className="text-slate-500 font-medium">{c.wardName}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      c.priority === 'P1_CRITICAL' ? 'bg-rose-100 text-rose-700' :
                      c.priority === 'P2_HIGH' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {c.priority}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h4 className="font-bold text-slate-900 text-sm mb-1 leading-snug">
                    {c.title}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                    {c.description}
                  </p>

                  {/* Image & Landmark */}
                  <div className="flex items-center space-x-3 text-xs text-slate-500 mb-3 bg-slate-50 p-2 rounded-lg">
                    {c.imageUrl && (
                      <img src={c.imageUrl} alt="Thumbnail" className="w-12 h-10 object-cover rounded border" />
                    )}
                    <div className="truncate">
                      <span className="font-semibold text-slate-700 block truncate">{c.landmark}</span>
                      <span className="text-[10px] text-slate-400">Target SLA: {c.slaHours} Hours</span>
                    </div>
                  </div>

                  {/* Interactive Status Stepper */}
                  <div className="border-t border-slate-100 pt-3">
                    <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700 mb-2">
                      <span>Current Status:</span>
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        isResolved ? 'bg-emerald-100 text-emerald-800' :
                        isWorkerCompleted ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {c.status.replace('_', ' ')}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                      <div className={`h-full transition-all duration-500 ${
                        c.status === 'RAISED' ? 'w-1/4 bg-amber-400' :
                        c.status === 'ASSIGNED' ? 'w-2/4 bg-blue-500' :
                        c.status === 'IN_PROGRESS' ? 'w-3/4 bg-indigo-500' :
                        'w-full bg-emerald-500'
                      }`}></div>
                    </div>

                    {/* Assigned Worker Details */}
                    {c.assignedWorkerName && (
                      <div className="mt-2 text-[11px] text-slate-600 flex items-center justify-between bg-slate-50 px-2.5 py-1.5 rounded">
                        <span>Assigned Technician: <strong className="text-slate-800">{c.assignedWorkerName}</strong></span>
                        <a href={`tel:${c.assignedWorkerPhone}`} className="text-blue-600 hover:underline font-bold">
                          Call Tech
                        </a>
                      </div>
                    )}

                    {/* Citizen Sign-Off Button if Worker Completed */}
                    {isWorkerCompleted && (
                      <button
                        onClick={() => setVerifyingComplaint(c)}
                        className="mt-3 w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center space-x-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Verify & Sign Off Resolution</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* GVMC Anti-Fake Multi-Layer Security Info Card */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-2xl border border-indigo-900 shadow-xl space-y-3">
            <div className="flex items-center space-x-2 border-b border-indigo-900/80 pb-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  GVMC Anti-Fake & Anti-Spam Defense Engine
                </h4>
                <p className="text-[10px] text-indigo-300">Active protection preventing fake complaints & bot spam</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-cyan-200 block">Gemini AI Guard</span>
                  <span className="text-slate-300 text-[10px]">Filters gibberish, test mash & non-civic text.</span>
                </div>
              </div>

              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-emerald-200 block">SMS OTP Auth</span>
                  <span className="text-slate-300 text-[10px]">Verifies Indian (+91) mobile citizen identity.</span>
                </div>
              </div>

              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-200 block">60s Rate Limiter</span>
                  <span className="text-slate-300 text-[10px]">Blocks rapid multi-requests from same user.</span>
                </div>
              </div>

              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-purple-200 block">Same-Task Guard</span>
                  <span className="text-slate-300 text-[10px]">10-min cooldown on identical category tasks.</span>
                </div>
              </div>

              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-rose-200 block">PostGIS 200m</span>
                  <span className="text-slate-300 text-[10px]">Detects duplicate complaints in radius.</span>
                </div>
              </div>

              <div className="bg-indigo-900/40 p-2.5 rounded-xl border border-indigo-800/60 flex items-start gap-2">
                <Lock className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-blue-200 block">Math CAPTCHA</span>
                  <span className="text-slate-300 text-[10px]">Prevents automated bot script submission.</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Citizen Verification & Rating Modal */}
      {verifyingComplaint && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" /> {t.verifyHeader}
              </h3>
              <button 
                onClick={() => setVerifyingComplaint(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Field Technician <strong>{verifyingComplaint.assignedWorkerName}</strong> has marked grievance <strong>#{verifyingComplaint.id}</strong> as completed. Please inspect work before closing.
            </p>

            {/* Before & After Image Comparison */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Before Work</span>
                <img src={verifyingComplaint.imageUrl} alt="Before" className="w-full h-24 object-cover rounded-lg border" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">After Work (GVMC Tech)</span>
                <img src={verifyingComplaint.afterImageUrl || verifyingComplaint.imageUrl} alt="After" className="w-full h-24 object-cover rounded-lg border" />
              </div>
            </div>

            {/* Rating Stars */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Rate Resolution Quality</label>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1"
                  >
                    <Star className={`w-6 h-6 ${star <= rating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'}`} />
                  </button>
                ))}
              </div>
            </div>

            {/* Feedback Comment */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Feedback / Notes</label>
              <input
                type="text"
                value={feedbackComment}
                onChange={(e) => setFeedbackComment(e.target.value)}
                placeholder="e.g. Excellent work, road resurfaced smoothly!"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
              />
            </div>

            <button
              onClick={handleVerifySubmit}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition"
            >
              Approve & Close Grievance Ticket
            </button>
          </div>
        </div>
      )}

      {/* Citizen SMS OTP Verification Modal */}
      {showOtpModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">SMS Identity Verification</h3>
                  <p className="text-[11px] text-slate-500">GVMC Anti-Fake Citizen Security</p>
                </div>
              </div>
              <button
                onClick={() => setShowOtpModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-900 space-y-1">
              <div className="font-bold flex items-center gap-1 text-blue-800">
                <Smartphone className="w-4 h-4 text-blue-600" /> OTP sent to {citizenPhone}
              </div>
              <p className="text-[11px] text-blue-700">
                Simulated SMS Gateway Code: <strong className="text-blue-900 text-sm bg-white px-2 py-0.5 rounded border border-blue-300 font-black tracking-widest">{generatedOtp}</strong>
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Enter 4-Digit Security Code
              </label>
              <input
                type="text"
                maxLength={4}
                value={otpInput}
                onChange={(e) => setOtpInput(e.target.value)}
                placeholder="e.g. 4829"
                className="w-full text-center text-lg font-black tracking-widest px-4 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              />
            </div>

            {otpError && (
              <p className="text-xs text-rose-600 font-bold">{otpError}</p>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setOtpInput(generatedOtp); // Quick fill button for convenience
                }}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
              >
                Auto-Fill Code
              </button>
              <button
                type="button"
                onClick={handleVerifyOtp}
                className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow transition"
              >
                Verify & Continue
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
