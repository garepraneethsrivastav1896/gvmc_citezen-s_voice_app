import React, { useState } from 'react';
import { Ward, LanguageCode } from '../types';
import { 
  Trophy, 
  Award, 
  Medal, 
  Search, 
  Filter, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  Building2, 
  ShieldCheck,
  Zap,
  Star
} from 'lucide-react';

interface LeaderboardViewProps {
  wards: Ward[];
  currentLang?: LanguageCode;
  onSelectWard?: (wardId: number) => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  wards,
  currentLang = 'EN',
  onSelectWard
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedZone, setSelectedZone] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'rank' | 'performance' | 'sla' | 'complaints'>('rank');

  // Multi-lingual titles
  const translations = {
    EN: {
      title: 'GVMC Ward Governance Performance Leaderboard',
      subtitle: 'Real-time ranking of 98 Visakhapatnam Wards based on SLA compliance, citizen rating & PostGIS resolution efficiency',
      topPerformers: 'Top Performing Wards',
      searchPlaceholder: 'Search ward number, name or officer...',
      allZones: 'All Zones',
      sortByRank: 'Rank (#1 - #98)',
      sortByPerf: 'Performance Score',
      sortBySla: 'Fastest SLA',
      sortByVolume: 'Complaint Volume',
      rank: 'Rank',
      ward: 'Ward',
      zone: 'Zone',
      officer: 'Officer In-Charge',
      complaints: 'Grievances',
      avgSla: 'Avg SLA Speed',
      score: 'Performance Index'
    },
    TE: {
      title: 'జివిఎంసి వార్డు పాలన పనితీరు లీడర్‌బోర్డ్',
      subtitle: 'SLA నిబంధనలు, పౌరుల రేటింగ్ ఆధారంగా విశాఖపట్నం 98 వార్డుల రియల్ టైమ్ ర్యాంకింగ్',
      topPerformers: 'అగ్రస్థానంలో ఉన్న వార్డులు',
      searchPlaceholder: 'వార్డు సంఖ్య లేదా పేరు శోధించండి...',
      allZones: 'అన్ని జోన్లు',
      sortByRank: 'ర్యాంక్ బట్టి',
      sortByPerf: 'పనితీరు స్కోరు',
      sortBySla: 'వేగవంతమైన SLA',
      sortByVolume: 'ఫిర్యాదుల సంఖ్య',
      rank: 'ర్యాంక్',
      ward: 'వార్డు',
      zone: 'జోన్',
      officer: 'అధికారి',
      complaints: 'ఫిర్యాదులు',
      avgSla: 'సగటు పరిష్కార సమయం',
      score: 'పనితీరు ఇండెక్స్'
    },
    HI: {
      title: 'जीवीएमसी वार्ड शासन प्रदर्शन लीडरबोर्ड',
      subtitle: 'SLA अनुपालन और नागरिक संतुष्टि के आधार पर विशाखापटनम 98 वार्डों की वास्तविक समय रैंकिंग',
      topPerformers: 'शीर्ष प्रदर्शन करने वाले वार्ड',
      searchPlaceholder: 'वार्ड संख्या या नाम खोजें...',
      allZones: 'सभी ज़ोन',
      sortByRank: 'रैंक के अनुसार',
      sortByPerf: 'प्रदर्शन स्कोर',
      sortBySla: 'तेज समाधान',
      sortByVolume: 'शिकायत मात्रा',
      rank: 'रैंक',
      ward: 'वार्ड',
      zone: 'ज़ोन',
      officer: 'प्रभारी अधिकारी',
      complaints: 'शिकायतें',
      avgSla: 'औसत SLA',
      score: 'प्रदर्शन सूचकांक'
    }
  };
  const t = translations[currentLang] || translations.EN;

  // Extract unique zones
  const zones = Array.from(new Set(wards.map(w => w.zone)));

  // Filter & sort wards
  const filteredWards = wards
    .filter(w => {
      const matchesSearch = 
        w.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        w.number.toString().includes(searchTerm) ||
        w.officerName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesZone = selectedZone === 'ALL' || w.zone === selectedZone;
      return matchesSearch && matchesZone;
    })
    .sort((a, b) => {
      if (sortBy === 'rank') return a.ranking - b.ranking;
      if (sortBy === 'performance') return b.performanceIndex - a.performanceIndex;
      if (sortBy === 'sla') return a.avgResolutionHours - b.avgResolutionHours;
      if (sortBy === 'complaints') return b.complaintCount - a.complaintCount;
      return a.ranking - b.ranking;
    });

  // Top 3 Podiums
  const top1 = wards.find(w => w.ranking === 1) || wards[0];
  const top2 = wards.find(w => w.ranking === 2) || wards[1];
  const top3 = wards.find(w => w.ranking === 3) || wards[2];

  // City Metrics
  const avgCityScore = Math.round(wards.reduce((acc, w) => acc + w.performanceIndex, 0) / (wards.length || 1));
  const avgCitySla = (wards.reduce((acc, w) => acc + w.avgResolutionHours, 0) / (wards.length || 1)).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <span className="bg-amber-500/20 text-amber-300 font-extrabold text-xs px-3 py-1 rounded-full border border-amber-500/30 uppercase tracking-widest flex items-center gap-1.5 inline-flex mb-2">
            <Trophy className="w-3.5 h-3.5 text-amber-400" /> GVMC Official Governance Analytics
          </span>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            {t.title}
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-3xl leading-relaxed">
            {t.subtitle}
          </p>
        </div>

        {/* Quick Stats Widget */}
        <div className="flex items-center space-x-3 bg-slate-900/90 p-4 rounded-2xl border border-amber-500/20 shadow-inner text-xs">
          <div className="text-center px-3 border-r border-slate-800">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">Active Wards</div>
            <div className="text-xl font-black text-amber-400">{wards.length}</div>
          </div>
          <div className="text-center px-3 border-r border-slate-800">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">City Avg Score</div>
            <div className="text-xl font-black text-emerald-400">{avgCityScore}/100</div>
          </div>
          <div className="text-center px-3">
            <div className="text-slate-400 font-semibold text-[10px] uppercase">City Avg SLA</div>
            <div className="text-xl font-black text-cyan-400">{avgCitySla}h</div>
          </div>
        </div>
      </div>

      {/* Top 3 Winner Podium Cards */}
      <div className="space-y-3">
        <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-500" /> {t.topPerformers} (Hall of Fame)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Rank #2 Silver */}
          {top2 && (
            <div className="bg-gradient-to-b from-slate-800 to-slate-900 text-white rounded-2xl p-6 border border-slate-700 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-4 transform md:translate-y-2">
              <div className="absolute top-0 right-0 bg-slate-300 text-slate-950 font-black text-xs px-3 py-1 rounded-bl-xl shadow flex items-center gap-1">
                <Medal className="w-3.5 h-3.5 text-slate-700" /> RANK #2 (Silver)
              </div>
              
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">{top2.zone}</span>
                <h3 className="text-lg font-bold text-white mt-1">Ward {top2.number} - {top2.name}</h3>
                <p className="text-xs text-slate-300 mt-1">Officer: <strong>{top2.officerName}</strong></p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block">Performance</span>
                  <span className="font-extrabold text-slate-200 text-base">{top2.performanceIndex}/100</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Avg Resolution SLA</span>
                  <span className="font-extrabold text-cyan-400 text-base">{top2.avgResolutionHours} hrs</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-3">
                <span>{top2.resolvedCount} Resolved</span>
                <span className="text-emerald-400 font-semibold">94.2% SLA Met</span>
              </div>
            </div>
          )}

          {/* Rank #1 Gold Champion */}
          {top1 && (
            <div className="bg-gradient-to-b from-amber-950 via-slate-900 to-slate-950 text-white rounded-2xl p-6 border-2 border-amber-500/80 shadow-2xl relative overflow-hidden flex flex-col justify-between space-y-4 ring-4 ring-amber-500/20">
              <div className="absolute top-0 right-0 bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs px-4 py-1.5 rounded-bl-xl shadow-lg flex items-center gap-1">
                <Trophy className="w-4 h-4 text-slate-950" /> CHAMPION #1 (Gold)
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">{top1.zone} • Model Ward</span>
                <h3 className="text-xl font-black text-amber-300 mt-1">Ward {top1.number} - {top1.name}</h3>
                <p className="text-xs text-slate-200 mt-1">Officer: <strong>{top1.officerName}</strong></p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-amber-950/40 p-3.5 rounded-xl border border-amber-500/30">
                <div>
                  <span className="text-[10px] text-amber-200/80 block">Performance Score</span>
                  <span className="font-black text-amber-400 text-lg">{top1.performanceIndex}/100</span>
                </div>
                <div>
                  <span className="text-[10px] text-amber-200/80 block">Ultra-Fast SLA</span>
                  <span className="font-black text-emerald-400 text-lg">{top1.avgResolutionHours} hrs</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-300 border-t border-slate-800/80 pt-3">
                <span className="flex items-center gap-1 font-semibold text-amber-300">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /> Top Citizen Rating
                </span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                  98.5% SLA Compliance
                </span>
              </div>
            </div>
          )}

          {/* Rank #3 Bronze */}
          {top3 && (
            <div className="bg-gradient-to-b from-slate-800 to-slate-900 text-white rounded-2xl p-6 border border-slate-700 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-4 transform md:translate-y-2">
              <div className="absolute top-0 right-0 bg-amber-800 text-amber-100 font-black text-xs px-3 py-1 rounded-bl-xl shadow flex items-center gap-1">
                <Medal className="w-3.5 h-3.5 text-amber-300" /> RANK #3 (Bronze)
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">{top3.zone}</span>
                <h3 className="text-lg font-bold text-white mt-1">Ward {top3.number} - {top3.name}</h3>
                <p className="text-xs text-slate-300 mt-1">Officer: <strong>{top3.officerName}</strong></p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block">Performance</span>
                  <span className="font-extrabold text-slate-200 text-base">{top3.performanceIndex}/100</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Avg Resolution SLA</span>
                  <span className="font-extrabold text-cyan-400 text-base">{top3.avgResolutionHours} hrs</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-3">
                <span>{top3.resolvedCount} Resolved</span>
                <span className="text-emerald-400 font-semibold">91.8% SLA Met</span>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
            />
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* Zone Filter */}
            <div className="flex items-center space-x-1 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <select
                value={selectedZone}
                onChange={(e) => setSelectedZone(e.target.value)}
                className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 focus:border-amber-500"
              >
                <option value="ALL">{t.allZones}</option>
                {zones.map(z => (
                  <option key={z} value={z}>{z}</option>
                ))}
              </select>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center space-x-1 text-xs">
              <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 focus:border-amber-500"
              >
                <option value="rank">{t.sortByRank}</option>
                <option value="performance">{t.sortByPerf}</option>
                <option value="sla">{t.sortBySla}</option>
                <option value="complaints">{t.sortByVolume}</option>
              </select>
            </div>
          </div>

        </div>

        {/* Wards Leaderboard Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-900 text-white uppercase font-bold text-[10px]">
              <tr>
                <th className="py-3 px-4">{t.rank}</th>
                <th className="py-3 px-4">{t.ward}</th>
                <th className="py-3 px-4">{t.zone}</th>
                <th className="py-3 px-4">{t.officer}</th>
                <th className="py-3 px-4 text-center">{t.complaints}</th>
                <th className="py-3 px-4 text-center">{t.avgSla}</th>
                <th className="py-3 px-4 text-right">{t.score}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium bg-white">
              {filteredWards.map((w) => (
                <tr 
                  key={w.id} 
                  onClick={() => onSelectWard && onSelectWard(w.id)}
                  className="hover:bg-slate-50 transition cursor-pointer"
                >
                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs ${
                      w.ranking === 1 ? 'bg-amber-100 text-amber-900 border border-amber-300 font-black' :
                      w.ranking === 2 ? 'bg-slate-200 text-slate-900 font-bold' :
                      w.ranking === 3 ? 'bg-amber-900/10 text-amber-900 font-bold' : 'text-slate-500 bg-slate-100'
                    }`}>
                      #{w.ranking}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    Ward {w.number} - {w.name}
                  </td>

                  <td className="py-3.5 px-4 text-slate-500 font-medium">{w.zone}</td>

                  <td className="py-3.5 px-4 font-semibold text-slate-800">
                    {w.officerName}
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    <span className="font-bold text-slate-900">{w.complaintCount}</span>
                    <span className="text-[10px] text-slate-400 block">{w.resolvedCount} Resolved</span>
                  </td>

                  <td className="py-3.5 px-4 text-center">
                    <span className="font-bold text-blue-700">{w.avgResolutionHours} hrs</span>
                  </td>

                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${
                            w.performanceIndex >= 85 ? 'bg-emerald-500' : 
                            w.performanceIndex >= 75 ? 'bg-blue-500' : 'bg-amber-500'
                          }`}
                          style={{ width: `${w.performanceIndex}%` }}
                        ></div>
                      </div>
                      <span className="font-black text-slate-900 w-12">{w.performanceIndex}/100</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
