import React, { useState, useEffect, useRef } from 'react';
import { Ward, Complaint, Worker } from '../types';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  InfoWindow, 
  useMap,
  useAdvancedMarkerRef
} from '@vis.gl/react-google-maps';
import { 
  MapPin, 
  Layers, 
  Flame, 
  User, 
  X, 
  Building2,
  CheckCircle2,
  AlertTriangle,
  Key,
  ExternalLink,
  ShieldCheck,
  Compass,
  Sparkles,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Navigation,
  Globe,
  Radio
} from 'lucide-react';

interface MapViewProps {
  wards: Ward[];
  complaints: Complaint[];
  workers: Worker[];
}

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

// Projection helper for Visakhapatnam bounding box
const VIZAG_BOUNDS = {
  minLat: 17.65,
  maxLat: 17.82,
  minLng: 83.15,
  maxLng: 83.38
};

function gpsToPercent(lat: number, lng: number) {
  const x = ((lng - VIZAG_BOUNDS.minLng) / (VIZAG_BOUNDS.maxLng - VIZAG_BOUNDS.minLng)) * 100;
  const y = ((VIZAG_BOUNDS.maxLat - lat) / (VIZAG_BOUNDS.maxLat - VIZAG_BOUNDS.minLat)) * 100;
  return { 
    x: Math.max(5, Math.min(95, x)), 
    y: Math.max(5, Math.min(95, y)) 
  };
}

// Sub-component to render Google Maps Polygons for GVMC Wards
function WardPolygonsGoogle({ wards, showHeatmap }: { wards: Ward[]; showHeatmap: boolean }) {
  const map = useMap();

  useEffect(() => {
    if (!map || typeof google === 'undefined' || !google.maps) return;

    const polygonInstances: google.maps.Polygon[] = [];

    wards.forEach(ward => {
      if (!ward.boundary || ward.boundary.length === 0) return;

      const paths = ward.boundary.map(coord => ({ lat: coord[0], lng: coord[1] }));
      const isHighGrievance = ward.complaintCount > 25;

      const polygon = new google.maps.Polygon({
        paths,
        strokeColor: '#0284c7',
        strokeOpacity: 0.85,
        strokeWeight: 2,
        fillColor: showHeatmap ? (isHighGrievance ? '#ef4444' : '#3b82f6') : '#0284c7',
        fillOpacity: showHeatmap ? (isHighGrievance ? 0.35 : 0.2) : 0.12,
        map
      });

      polygonInstances.push(polygon);
    });

    return () => {
      polygonInstances.forEach(p => p.setMap(null));
    };
  }, [map, wards, showHeatmap]);

  return null;
}

// Marker with InfoWindow wrapper for Google Maps
function ComplaintMarkerGoogle({ 
  complaint, 
  isSelected, 
  onSelect, 
  getCategoryColor 
}: { 
  key?: string;
  complaint: Complaint; 
  isSelected: boolean; 
  onSelect: (c: Complaint) => void;
  getCategoryColor: (cat: string) => string;
}) {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const isP1 = complaint.priority === 'P1_CRITICAL';
  const color = getCategoryColor(complaint.category);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: complaint.lat, lng: complaint.lng }}
        onClick={() => onSelect(complaint)}
        title={`${complaint.title} (${complaint.wardName})`}
      >
        <div className="relative group cursor-pointer flex items-center justify-center">
          {isP1 && (
            <span className="absolute -inset-2 rounded-full bg-rose-500 opacity-75 animate-ping" />
          )}

          <div 
            className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-xl transition-transform hover:scale-125 border-2 ${
              isSelected ? 'ring-4 ring-cyan-400 scale-125 border-white' : 'border-slate-900'
            }`}
            style={{ backgroundColor: color }}
          >
            <MapPin className="w-4 h-4 text-white" />
          </div>

          <div className="absolute top-9 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition pointer-events-none z-30">
            #{complaint.id} • {complaint.wardName}
          </div>
        </div>
      </AdvancedMarker>

      {isSelected && (
        <InfoWindow
          anchor={marker}
          onCloseClick={() => onSelect(null as any)}
        >
          <div className="p-1 max-w-xs text-slate-900 space-y-2">
            <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-1">
              <span className="text-[10px] font-black uppercase text-cyan-700 bg-cyan-50 px-1.5 py-0.5 rounded border border-cyan-200">
                #{complaint.id}
              </span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                complaint.priority === 'P1_CRITICAL' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
              }`}>
                {complaint.priority}
              </span>
            </div>
            
            <h4 className="font-extrabold text-xs text-slate-900 leading-snug">
              {complaint.title}
            </h4>
            
            <p className="text-[11px] text-slate-600 line-clamp-2">
              {complaint.description}
            </p>

            <div className="text-[10px] text-slate-500 space-y-0.5 bg-slate-50 p-2 rounded-lg border border-slate-200">
              <div>📍 <strong>Ward:</strong> {complaint.wardName}</div>
              <div>🏢 <strong>Landmark:</strong> {complaint.landmark}</div>
              <div>⚡ <strong>Status:</strong> <span className="font-bold text-emerald-700">{complaint.status}</span></div>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
}

export const MapView: React.FC<MapViewProps> = ({
  wards = [],
  complaints = [],
  workers = []
}) => {
  const [mapMode, setMapMode] = useState<'GOOGLE' | 'OFFLINE'>(hasValidKey ? 'GOOGLE' : 'OFFLINE');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [selectedWard, setSelectedWard] = useState<Ward | null>(null);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showWorkers, setShowWorkers] = useState(true);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('ALL');

  // Offline Zoom & Pan state
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panPos, setPanPos] = useState({ x: 0, y: 0 });

  const filteredComplaints = complaints.filter(c => {
    if (selectedCategoryFilter !== 'ALL' && c.category !== selectedCategoryFilter) return false;
    return true;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Water Leakage & Supply': return '#0284c7';
      case 'Potholes & Roads': return '#d97706';
      case 'Garbage & Sanitation': return '#059669';
      case 'Street Light & Power': return '#7c3aed';
      case 'Drainage Overflow': return '#dc2626';
      default: return '#4f46e5';
    }
  };

  const defaultCenter = { lat: 17.7231, lng: 83.3012 };

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.3, 2.5));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.3, 0.8));
  const handleResetMap = () => {
    setZoomLevel(1);
    setPanPos({ x: 0, y: 0 });
    setSelectedComplaint(null);
    setSelectedWard(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Map Header & Controls */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-cyan-950 text-cyan-400 font-bold text-[10px] px-2.5 py-0.5 rounded-full border border-cyan-800 flex items-center gap-1">
              <Compass className="w-3 h-3 text-cyan-400" /> Visakhapatnam Smart City Geographic Engine
            </span>
            <span className="text-slate-400 text-xs">GVMC Ward & GPS Monitor</span>
          </div>
          <h2 className="text-xl font-extrabold mt-1 flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" /> 
            {mapMode === 'GOOGLE' ? 'GVMC Interactive Google Ward Map' : 'GVMC High-Precision Offline GIS Vector Map'}
          </h2>
        </div>

        {/* Layer Toggles, Mode Switcher & Category Filter */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
          
          {/* Map Engine Mode Selector */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center space-x-1">
            <button
              onClick={() => setMapMode('OFFLINE')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                mapMode === 'OFFLINE' 
                  ? 'bg-cyan-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Offline Vector Map</span>
            </button>

            <button
              onClick={() => {
                if (!hasValidKey) {
                  alert('Google Maps API key is not yet provided. Add GOOGLE_MAPS_PLATFORM_KEY to environment variables to enable Google Maps tiles.');
                  return;
                }
                setMapMode('GOOGLE');
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                mapMode === 'GOOGLE' 
                  ? 'bg-indigo-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Google Maps API</span>
            </button>
          </div>

          <button
            onClick={() => setShowHeatmap(!showHeatmap)}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center space-x-1.5 cursor-pointer ${
              showHeatmap 
                ? 'bg-rose-600 text-white shadow-lg ring-2 ring-rose-400' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Flame className="w-4 h-4 text-amber-300" />
            <span>Heatmap Overlay</span>
          </button>

          <button
            onClick={() => setShowWorkers(!showWorkers)}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center space-x-1.5 cursor-pointer ${
              showWorkers 
                ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-400' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <User className="w-4 h-4 text-emerald-200" />
            <span>Field Worker GPS</span>
          </button>

          <select
            value={selectedCategoryFilter}
            onChange={(e) => setSelectedCategoryFilter(e.target.value)}
            className="bg-slate-800 text-white font-medium px-3 py-1.5 rounded-xl border border-slate-700 focus:outline-none cursor-pointer text-xs"
          >
            <option value="ALL">All Grievance Categories</option>
            <option value="Water Leakage & Supply">Water Supply & Leaks</option>
            <option value="Potholes & Roads">Potholes & Roads</option>
            <option value="Garbage & Sanitation">Garbage & Sanitation</option>
            <option value="Street Light & Power">Street Lights & Power</option>
            <option value="Drainage Overflow">Drainage Overflow</option>
          </select>
        </div>
      </div>

      {/* Map View Display */}
      {mapMode === 'OFFLINE' ? (
        /* OFFLINE VECTOR / RASTER MAP WITH EXACT LAT/LNG COORDINATES */
        <div className="relative rounded-3xl border border-slate-800 bg-slate-950 shadow-2xl overflow-hidden h-[640px] select-none">
          
          {/* Controls Bar (Zoom, Reset) */}
          <div className="absolute top-4 left-4 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 p-1.5 rounded-2xl flex flex-col gap-1.5 shadow-xl">
            <button
              onClick={handleZoomIn}
              title="Zoom In"
              className="p-2 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl transition cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleZoomOut}
              title="Zoom Out"
              className="p-2 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl transition cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetMap}
              title="Reset View"
              className="p-2 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Top Status Indicator */}
          <div className="absolute top-4 right-4 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-3.5 py-1.5 rounded-2xl flex items-center gap-2 shadow-xl text-xs text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold text-white">Offline GIS Vector Engine Active</span>
            <span className="text-[10px] text-cyan-400 font-mono">Zoom: {(zoomLevel * 100).toFixed(0)}%</span>
          </div>

          {/* Interactive Zoomable / Transformable Canvas Container */}
          <div 
            className="w-full h-full relative transition-transform duration-300 ease-out"
            style={{
              transform: `scale(${zoomLevel}) translate(${panPos.x}px, ${panPos.y}px)`,
              transformOrigin: 'center center'
            }}
          >
            {/* SVG Background Layer - Coastline, Water, Hills, Roads */}
            <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="oceanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0f172a" />
                  <stop offset="50%" stopColor="#0284c7" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#0369a1" stopOpacity="0.8" />
                </linearGradient>

                <linearGradient id="hillGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#064e3b" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#022c22" stopOpacity="0.1" />
                </linearGradient>

                <filter id="glow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              {/* Bay of Bengal Ocean Shoreline (Right/East side of Visakhapatnam) */}
              <path
                d="M 750,0 Q 720,150 740,300 T 780,500 T 820,640 L 1000,640 L 1000,0 Z"
                fill="url(#oceanGrad)"
              />

              {/* Ocean Waves Accent Lines */}
              <path d="M 780,100 Q 820,120 860,100" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="4 4" fill="none" opacity="0.6" />
              <path d="M 800,280 Q 840,300 880,280" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="4 4" fill="none" opacity="0.6" />
              <path d="M 830,480 Q 870,500 910,480" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="4 4" fill="none" opacity="0.6" />

              {/* Kailasagiri & Simhachalam Reserve Hills Vector Contours */}
              <path
                d="M 50,40 Q 150,20 280,80 T 450,60 L 400,180 L 100,160 Z"
                fill="url(#hillGrad)"
                stroke="#059669"
                strokeWidth="1"
                strokeDasharray="3 3"
              />

              {/* Major Arterial Roads / Highways (NH16 & Beach Road) */}
              {/* NH16 Arterial Trunk */}
              <path
                d="M 100,600 C 250,450 350,300 650,50"
                stroke="#cbd5e1"
                strokeWidth="4"
                fill="none"
                opacity="0.25"
              />
              <path
                d="M 100,600 C 250,450 350,300 650,50"
                stroke="#38bdf8"
                strokeWidth="1.5"
                fill="none"
                opacity="0.8"
              />

              {/* RK Beach Road Line along Coast */}
              <path
                d="M 730,160 C 740,280 770,420 810,600"
                stroke="#f59e0b"
                strokeWidth="2"
                fill="none"
                opacity="0.8"
              />

              {/* Render Ward Boundary Polygons dynamically */}
              {wards.map((ward) => {
                if (!ward.boundary || ward.boundary.length === 0) return null;
                const pointsSvg = ward.boundary.map(coord => {
                  const pt = gpsToPercent(coord[0], coord[1]);
                  return `${pt.x * 10} ${pt.y * 6.4}`; // Scale percent to 1000x640 viewBox
                }).join(' ');

                const isSelected = selectedWard?.id === ward.id;
                const isHighGrievance = ward.complaintCount > 25;

                return (
                  <g key={ward.id} onClick={() => setSelectedWard(ward)} className="cursor-pointer group">
                    <polygon
                      points={pointsSvg}
                      fill={showHeatmap ? (isHighGrievance ? '#ef4444' : '#3b82f6') : (isSelected ? '#0284c7' : '#0f172a')}
                      fillOpacity={showHeatmap ? 0.35 : (isSelected ? 0.4 : 0.15)}
                      stroke={isSelected ? '#38bdf8' : '#0284c7'}
                      strokeWidth={isSelected ? 3 : 1.5}
                      strokeDasharray={isSelected ? 'none' : '4 4'}
                      className="transition-all hover:fill-cyan-500/30"
                    />
                  </g>
                );
              })}

              {/* Geographic Labels */}
              <text x="860" y="300" fill="#38bdf8" fontSize="12" fontWeight="bold" opacity="0.6">BAY OF BENGAL</text>
              <text x="700" y="380" fill="#f59e0b" fontSize="10" fontWeight="bold" opacity="0.8">RK BEACH ROAD</text>
              <text x="200" y="90" fill="#10b981" fontSize="10" fontWeight="bold" opacity="0.7">KAILASAGIRI HILL RANGE</text>
            </svg>

            {/* Heatmap Area Glow Circles if Heatmap is enabled */}
            {showHeatmap && filteredComplaints.map((complaint) => {
              const pt = gpsToPercent(complaint.lat, complaint.lng);
              return (
                <div
                  key={`heat-${complaint.id}`}
                  className="absolute rounded-full pointer-events-none -translate-x-1/2 -translate-y-1/2 animate-pulse"
                  style={{
                    left: `${pt.x}%`,
                    top: `${pt.y}%`,
                    width: '80px',
                    height: '80px',
                    background: 'radial-gradient(circle, rgba(239, 68, 68, 0.5) 0%, rgba(245, 158, 11, 0.2) 60%, transparent 100%)'
                  }}
                />
              );
            })}

            {/* Field Worker GPS Markers */}
            {showWorkers && workers.map((worker) => {
              const pt = gpsToPercent(worker.lat, worker.lng);
              return (
                <div
                  key={`worker-${worker.id}`}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-10 group cursor-pointer"
                  style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                >
                  <div className="relative">
                    <span className="absolute -inset-1 rounded-full bg-emerald-500 opacity-75 animate-ping" />
                    <div className="bg-emerald-600 text-white p-1.5 rounded-full shadow-xl border-2 border-slate-900 flex items-center justify-center hover:scale-125 transition">
                      <User className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-bold px-2 py-1 rounded-lg shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition z-30 pointer-events-none border border-slate-700">
                    👷 {worker.name} ({worker.category})
                  </div>
                </div>
              );
            })}

            {/* Complaint Pins with Exact GPS Coordinates */}
            {filteredComplaints.map((complaint) => {
              const pt = gpsToPercent(complaint.lat, complaint.lng);
              const isSelected = selectedComplaint?.id === complaint.id;
              const isP1 = complaint.priority === 'P1_CRITICAL';
              const color = getCategoryColor(complaint.category);

              return (
                <div
                  key={complaint.id}
                  onClick={() => setSelectedComplaint(complaint)}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 cursor-pointer group"
                  style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                >
                  <div className="relative flex items-center justify-center">
                    {isP1 && (
                      <span className="absolute -inset-2 rounded-full bg-rose-500 opacity-75 animate-ping" />
                    )}

                    <div 
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-2xl transition-all hover:scale-125 border-2 ${
                        isSelected ? 'ring-4 ring-cyan-400 scale-125 border-white' : 'border-slate-900'
                      }`}
                      style={{ backgroundColor: color }}
                    >
                      <MapPin className="w-4 h-4 text-white" />
                    </div>

                    <div className="absolute top-9 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition pointer-events-none z-30 border border-slate-700">
                      #{complaint.id} • {complaint.wardName}
                    </div>
                  </div>
                </div>
              );
            })}

          </div>

          {/* Floating Map Legend Card */}
          <div className="absolute bottom-5 left-5 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 text-xs text-slate-200 space-y-2 shadow-2xl z-20 max-w-xs">
            <div className="font-extrabold text-white text-xs flex items-center gap-1.5 border-b border-slate-700/80 pb-1">
              <ShieldCheck className="w-4 h-4 text-cyan-400" /> Visakhapatnam Ward Map Legend
            </div>

            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] font-medium">
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-cyan-600 inline-block shadow-xs"></span>
                <span>Water Supply</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-600 inline-block shadow-xs"></span>
                <span>Potholes & Roads</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block shadow-xs"></span>
                <span>Sanitation</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-purple-600 inline-block shadow-xs"></span>
                <span>Street Lights</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-600 inline-block shadow-xs"></span>
                <span>Drainage Overflow</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500 border border-white inline-block shadow-xs"></span>
                <span>Field Worker GPS</span>
              </div>
            </div>
          </div>

          {/* Selected Grievance Details Drawer */}
          {selectedComplaint && (
            <div className="absolute top-5 right-5 w-80 bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-2xl p-5 shadow-2xl text-slate-100 space-y-3 z-30 animate-in fade-in slide-in-from-right-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-mono text-xs font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  #{selectedComplaint.id}
                </span>
                <button
                  onClick={() => setSelectedComplaint(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase text-cyan-400 tracking-wider block">{selectedComplaint.wardName}</span>
                <h4 className="font-bold text-sm text-white leading-snug">{selectedComplaint.title}</h4>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{selectedComplaint.description}</p>

              {selectedComplaint.imageUrl && (
                <img 
                  src={selectedComplaint.imageUrl} 
                  alt="Grievance" 
                  className="w-full h-32 object-cover rounded-xl border border-slate-800 shadow-md" 
                />
              )}

              <div className="bg-slate-950 p-3 rounded-xl text-xs space-y-1.5 border border-slate-800">
                <div className="text-slate-400">Landmark: <strong className="text-slate-200">{selectedComplaint.landmark}</strong></div>
                <div className="text-slate-400">Exact GPS Coordinates: <strong className="text-cyan-400 font-mono">{selectedComplaint.lat}, {selectedComplaint.lng}</strong></div>
                <div className="text-slate-400">Resolution Status: <strong className="text-emerald-400 font-bold">{selectedComplaint.status}</strong></div>
              </div>
            </div>
          )}

          {/* Selected Ward Info Drawer */}
          {selectedWard && !selectedComplaint && (
            <div className="absolute top-5 right-5 w-80 bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-2xl p-5 shadow-2xl text-slate-100 space-y-3 z-30 animate-in fade-in slide-in-from-right-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-black text-cyan-400 bg-cyan-950 px-2.5 py-0.5 rounded border border-cyan-800">
                  WARD #{selectedWard.id}
                </span>
                <button
                  onClick={() => setSelectedWard(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <h4 className="font-extrabold text-base text-white">{selectedWard.name}</h4>
                <p className="text-xs text-slate-400">{selectedWard.zone} • In-Charge Officer: <strong className="text-slate-200">{selectedWard.officerName}</strong></p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">Total Complaints</span>
                  <span className="text-lg font-black text-cyan-400">{selectedWard.complaintCount}</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">SLA Resolution Rate</span>
                  <span className="text-lg font-black text-emerald-400">{selectedWard.slaRate}%</span>
                </div>
              </div>
            </div>
          )}

        </div>
      ) : (
        /* GOOGLE MAPS API RENDERING MODE */
        <div className="relative rounded-3xl border border-slate-800 shadow-2xl overflow-hidden h-[640px]">
          <APIProvider apiKey={API_KEY} version="weekly">
            <Map
              defaultCenter={defaultCenter}
              defaultZoom={12}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
              style={{ width: '100%', height: '100%' }}
              gestureHandling="greedy"
              disableDefaultUI={false}
            >
              {/* Polygon boundaries for GVMC Wards */}
              <WardPolygonsGoogle wards={wards} showHeatmap={showHeatmap} />

              {/* Complaint Markers */}
              {filteredComplaints.map((complaint) => (
                <ComplaintMarkerGoogle
                  key={complaint.id}
                  complaint={complaint}
                  isSelected={selectedComplaint?.id === complaint.id}
                  onSelect={(c) => setSelectedComplaint(c)}
                  getCategoryColor={getCategoryColor}
                />
              ))}

              {/* Field Worker GPS Markers */}
              {showWorkers && workers.map((worker) => (
                <AdvancedMarker
                  key={worker.id}
                  position={{ lat: worker.lat, lng: worker.lng }}
                  title={`Field Worker: ${worker.name} (${worker.category})`}
                >
                  <div className="bg-emerald-600 text-white p-1.5 rounded-full shadow-lg border-2 border-white flex items-center justify-center hover:scale-125 transition cursor-pointer">
                    <User className="w-4 h-4 text-white" />
                  </div>
                </AdvancedMarker>
              ))}

            </Map>
          </APIProvider>

          {/* Floating Map Legend Card */}
          <div className="absolute bottom-5 left-5 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700 text-xs text-slate-200 space-y-2 shadow-2xl z-10 max-w-xs">
            <div className="font-extrabold text-white text-xs flex items-center gap-1.5 border-b border-slate-700/80 pb-1">
              <ShieldCheck className="w-4 h-4 text-cyan-400" /> Visakhapatnam Ward Map Legend
            </div>

            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] font-medium">
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-cyan-600 inline-block shadow-xs"></span>
                <span>Water Supply</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-600 inline-block shadow-xs"></span>
                <span>Potholes & Roads</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block shadow-xs"></span>
                <span>Sanitation</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-purple-600 inline-block shadow-xs"></span>
                <span>Street Lights</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-600 inline-block shadow-xs"></span>
                <span>Drainage Overflow</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500 border border-white inline-block shadow-xs"></span>
                <span>Field Worker GPS</span>
              </div>
            </div>
          </div>

          {/* Selected Grievance Details Drawer */}
          {selectedComplaint && (
            <div className="absolute top-5 right-5 w-80 bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-2xl p-5 shadow-2xl text-slate-100 space-y-3 z-20">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-mono text-xs font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                  #{selectedComplaint.id}
                </span>
                <button
                  onClick={() => setSelectedComplaint(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase text-cyan-400 tracking-wider block">{selectedComplaint.wardName}</span>
                <h4 className="font-bold text-sm text-white leading-snug">{selectedComplaint.title}</h4>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{selectedComplaint.description}</p>

              {selectedComplaint.imageUrl && (
                <img 
                  src={selectedComplaint.imageUrl} 
                  alt="Grievance" 
                  className="w-full h-32 object-cover rounded-xl border border-slate-800 shadow-md" 
                />
              )}

              <div className="bg-slate-950 p-3 rounded-xl text-xs space-y-1.5 border border-slate-800">
                <div className="text-slate-400">Landmark: <strong className="text-slate-200">{selectedComplaint.landmark}</strong></div>
                <div className="text-slate-400">Coordinates: <strong className="text-cyan-400 font-mono">{selectedComplaint.lat}, {selectedComplaint.lng}</strong></div>
                <div className="text-slate-400">Status: <strong className="text-emerald-400 font-bold">{selectedComplaint.status}</strong></div>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
