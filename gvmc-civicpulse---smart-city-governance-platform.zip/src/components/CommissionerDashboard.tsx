import React, { useState } from 'react';
import { Ward, Complaint } from '../types';
import { 
  Building2, 
  Sparkles, 
  Trophy, 
  ShieldAlert, 
  CheckCircle, 
  Clock, 
  TrendingUp, 
  FileText, 
  AlertTriangle,
  Award,
  Search,
  Filter,
  MapPin,
  CheckCheck
} from 'lucide-react';

interface CommissionerDashboardProps {
  wards: Ward[];
  complaints: Complaint[];
  onApproveComplaint: (id: string) => Promise<void>;
}

export const CommissionerDashboard: React.FC<CommissionerDashboardProps> = ({
  wards,
  complaints,
  onApproveComplaint
}) => {
  const [weeklyReport, setWeeklyReport] = useState<string | null>(null);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [zoneFilter, setZoneFilter] = useState('ALL');

  const [queueFilter, setQueueFilter] = useState<'ALL_PENDING' | 'RAISED' | 'P1' | 'WORKER_COMPLETED' | 'ALL'>('ALL_PENDING');

  const safeComplaints = Array.isArray(complaints) ? complaints : [];
  const safeWards = Array.isArray(wards) ? wards : [];

  const totalComplaints = safeComplaints.length;
  const resolvedComplaints = safeComplaints.filter(c => c.status === 'CITIZEN_VERIFIED' || c.status === 'COMMISSIONER_APPROVED').length;
  const p1Criticals = safeComplaints.filter(c => c.priority === 'P1_CRITICAL' && c.status !== 'COMMISSIONER_APPROVED');
  
  // Executive Queue for Commissioner Sanction and Review
  const commissionerQueue = [...safeComplaints]
    .filter(c => {
      if (queueFilter === 'RAISED') return c.status === 'RAISED';
      if (queueFilter === 'P1') return c.priority === 'P1_CRITICAL';
      if (queueFilter === 'WORKER_COMPLETED') return c.status === 'WORKER_COMPLETED';
      if (queueFilter === 'ALL') return true;
      // ALL_PENDING default
      return c.status !== 'COMMISSIONER_APPROVED' && c.status !== 'CITIZEN_VERIFIED';
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // All citywide filtered complaints
  const filteredAllComplaints = [...safeComplaints]
    .filter(c => {
      if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
      if (zoneFilter !== 'ALL' && c.zoneName !== zoneFilter) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        return (
          (c.title || '').toLowerCase().includes(q) ||
          (c.description || '').toLowerCase().includes(q) ||
          (c.wardName || '').toLowerCase().includes(q) ||
          (c.id || '').toLowerCase().includes(q) ||
          (c.category || '').toLowerCase().includes(q) ||
          (c.citizenName || '').toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleGenerateWeeklyReport = async () => {
    setGeneratingReport(true);
    try {
      const res = await fetch('/api/ai/weekly-report', { method: 'POST' });
      const data = await res.json();
      setWeeklyReport(data.report);
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingReport(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Command Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 shadow-2xl border border-indigo-900/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <span className="bg-amber-500/20 text-amber-300 font-bold text-xs px-3 py-1 rounded-full border border-amber-500/30 uppercase tracking-wider">
            GVMC Executive Command Center
          </span>
          <h2 className="text-2xl sm:text-3xl font-black mt-2 tracking-tight">
            Municipal Commissioner Governance Desk
          </h2>
          <p className="text-slate-300 text-xs mt-1">
            Real-time Smart City Operations • Visakhapatnam Municipal Corporation (98 Wards)
          </p>
        </div>

        <button
          onClick={handleGenerateWeeklyReport}
          disabled={generatingReport}
          className="px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-xl transition flex items-center space-x-2"
        >
          <Sparkles className="w-4 h-4 text-slate-950 animate-pulse" />
          <span>{generatingReport ? 'Compiling Audit Report...' : 'Generate AI Weekly Audit Report'}</span>
        </button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Citywide Grievance Volume</span>
          <div className="text-2xl font-black text-slate-900">{totalComplaints}</div>
          <span className="text-[10px] text-slate-400">98 Wards Aggregated</span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">SLA Resolution Rate</span>
          <div className="text-2xl font-black text-emerald-600">89.2%</div>
          <span className="text-[10px] text-emerald-700 font-semibold">GVMC Benchmark: &gt;85%</span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">City Avg Resolution SLA</span>
          <div className="text-2xl font-black text-blue-600">14.8 hrs</div>
          <span className="text-[10px] text-slate-400">Target SLA: 24 hrs</span>
        </div>

        <div className="bg-rose-50 rounded-2xl p-5 border border-rose-200 shadow-sm">
          <span className="text-xs font-bold text-rose-700 uppercase tracking-wider block mb-1 flex items-center gap-1">
            <ShieldAlert className="w-4 h-4 text-rose-600" /> Active P1 Critical Alerts
          </span>
          <div className="text-2xl font-black text-rose-700">{p1Criticals.length}</div>
          <span className="text-[10px] text-rose-600 font-bold">Priority Escalations</span>
        </div>
      </div>

      {/* Weekly AI Audit Report Display */}
      {weeklyReport && (
        <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 sm:p-8 border border-amber-500/40 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-base text-amber-400 flex items-center gap-2">
              <FileText className="w-5 h-5 text-amber-400" />
              GVMC Smart City Weekly Audit & Governance Report
            </h3>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2.5 py-1 rounded-full font-mono font-bold border border-amber-500/30">
              Gemini 3.6 Flash
            </span>
          </div>
          <div className="text-xs space-y-3 font-sans text-slate-200 leading-relaxed whitespace-pre-line bg-slate-950/60 p-5 rounded-xl border border-slate-800">
            {weeklyReport}
          </div>
        </div>
      )}

      {/* Commissioner Approval & Escalation Queue */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" /> Executive Approval & Action Desk
            </h3>
            <p className="text-xs text-slate-500">Sanction queue for newly raised, P1 critical, and field-completed grievances</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setQueueFilter('ALL_PENDING')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                queueFilter === 'ALL_PENDING' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pending Sanction ({safeComplaints.filter(c => c.status !== 'COMMISSIONER_APPROVED' && c.status !== 'CITIZEN_VERIFIED').length})
            </button>
            <button
              onClick={() => setQueueFilter('RAISED')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                queueFilter === 'RAISED' ? 'bg-amber-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Newly Raised ({safeComplaints.filter(c => c.status === 'RAISED').length})
            </button>
            <button
              onClick={() => setQueueFilter('P1')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                queueFilter === 'P1' ? 'bg-rose-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              P1 Critical ({safeComplaints.filter(c => c.priority === 'P1_CRITICAL').length})
            </button>
            <button
              onClick={() => setQueueFilter('WORKER_COMPLETED')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                queueFilter === 'WORKER_COMPLETED' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Field Completed ({safeComplaints.filter(c => c.status === 'WORKER_COMPLETED').length})
            </button>
            <button
              onClick={() => setQueueFilter('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                queueFilter === 'ALL' ? 'bg-blue-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({totalComplaints})
            </button>
          </div>
        </div>

        {commissionerQueue.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
            No pending P1 escalations requiring immediate commissioner sanction at this moment.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {commissionerQueue.map((c) => (
              <div key={c.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">#{c.id}</span>
                  <span className="text-slate-600 font-semibold">{c.wardName}</span>
                  <span className={`font-bold text-[10px] px-2 py-0.5 rounded-full text-white ${
                    c.priority === 'P1_CRITICAL' ? 'bg-rose-600' : 'bg-amber-600'
                  }`}>{c.priority}</span>
                </div>

                <h4 className="font-bold text-slate-900 text-xs">{c.title}</h4>
                <p className="text-[11px] text-slate-600 leading-snug">{c.description}</p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                  <span className="text-slate-500 text-[11px]">Status: <strong className="text-slate-800">{c.status}</strong></span>
                  <button
                    onClick={() => onApproveComplaint(c.id)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow transition flex items-center gap-1"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    Approve Sanction
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Live Citywide Grievance Feed Across All 98 Wards */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" /> Citywide Live Grievance Operations Feed (All 98 Wards)
            </h3>
            <p className="text-xs text-slate-500">Real-time status tracking for every registered grievance across GVMC</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search complaint ID or ward..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-blue-200"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 bg-slate-50"
            >
              <option value="ALL">All Statuses</option>
              <option value="RAISED">RAISED (New)</option>
              <option value="ASSIGNED">ASSIGNED</option>
              <option value="IN_PROGRESS">IN PROGRESS</option>
              <option value="WORKER_COMPLETED">WORKER COMPLETED</option>
              <option value="CITIZEN_VERIFIED">CITIZEN VERIFIED</option>
              <option value="COMMISSIONER_APPROVED">COMMISSIONER APPROVED</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] border-b">
              <tr>
                <th className="py-3 px-3">Grievance ID</th>
                <th className="py-3 px-3">Ward & Zone</th>
                <th className="py-3 px-3">Title & Category</th>
                <th className="py-3 px-3">Citizen Contact</th>
                <th className="py-3 px-3 text-center">Priority</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredAllComplaints.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 text-xs">
                    No complaints matching the selected filter criteria.
                  </td>
                </tr>
              ) : (
                filteredAllComplaints.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-3 font-mono font-bold text-blue-700">
                      #{c.id}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-900">{c.wardName}</div>
                      <div className="text-[10px] text-slate-500">{c.zoneName}</div>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <div className="font-bold text-slate-900 truncate">{c.title}</div>
                      <div className="text-[10px] text-slate-500">{c.category} • {c.landmark}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-800">{c.citizenName}</div>
                      <div className="text-[10px] text-slate-500">{c.citizenPhone}</div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        c.priority === 'P1_CRITICAL' ? 'bg-rose-100 text-rose-700' :
                        c.priority === 'P2_HIGH' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {c.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                        c.status === 'RAISED' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                        c.status === 'ASSIGNED' ? 'bg-blue-50 text-blue-800 border-blue-200' :
                        c.status === 'COMMISSIONER_APPROVED' || c.status === 'CITIZEN_VERIFIED' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                        'bg-purple-50 text-purple-800 border-purple-200'
                      }`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {c.status !== 'COMMISSIONER_APPROVED' && c.status !== 'CITIZEN_VERIFIED' ? (
                        <button
                          onClick={() => onApproveComplaint(c.id)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded transition inline-flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" /> Approve
                        </button>
                      ) : (
                        <span className="text-[10px] font-bold text-emerald-600 flex items-center justify-end gap-1">
                          <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> Sanctioned
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Ward Leaderboard & Performance Ranking Table */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" /> Ward Governance Performance Index Leaderboard
            </h3>
            <p className="text-xs text-slate-500">Ranking of all GVMC Wards based on SLA compliance and citizen satisfaction</p>
          </div>
          <span className="text-xs font-bold text-slate-600">PostGIS Analytics Engine</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] border-b">
              <tr>
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Ward Name</th>
                <th className="py-3 px-4">Zone</th>
                <th className="py-3 px-4">Officer In-Charge</th>
                <th className="py-3 px-4 text-center">Grievances</th>
                <th className="py-3 px-4 text-center">Avg SLA</th>
                <th className="py-3 px-4 text-right">Performance Index</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {wards.map((w) => (
                <tr key={w.id} className="hover:bg-slate-50 transition">
                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs ${
                      w.ranking === 1 ? 'bg-amber-100 text-amber-800 border border-amber-300 font-black' :
                      w.ranking === 2 ? 'bg-slate-200 text-slate-800' :
                      w.ranking === 3 ? 'bg-amber-900/10 text-amber-900' : 'text-slate-500'
                    }`}>
                      #{w.ranking}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    Ward {w.number} - {w.name}
                  </td>
                  <td className="py-3.5 px-4 text-slate-500">{w.zone}</td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800">{w.officerName}</td>
                  <td className="py-3.5 px-4 text-center font-bold">{w.complaintCount}</td>
                  <td className="py-3.5 px-4 text-center">{w.avgResolutionHours} hrs</td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <div className="w-20 bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${w.performanceIndex >= 85 ? 'bg-emerald-500' : w.performanceIndex >= 75 ? 'bg-blue-500' : 'bg-amber-500'}`}
                          style={{ width: `${w.performanceIndex}%` }}
                        ></div>
                      </div>
                      <span className="font-bold text-slate-900 w-12">{w.performanceIndex}/100</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
