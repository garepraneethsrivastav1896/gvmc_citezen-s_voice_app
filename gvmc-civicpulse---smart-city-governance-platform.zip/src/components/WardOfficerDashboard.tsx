import React, { useState } from 'react';
import { Complaint, Ward, Worker, PriorityLevel } from '../types';
import { 
  Building2, 
  MapPin, 
  Sparkles, 
  UserCheck, 
  AlertOctagon, 
  Clock, 
  CheckCircle, 
  Phone, 
  Navigation, 
  Search, 
  Filter, 
  Zap,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

interface WardOfficerDashboardProps {
  wards: Ward[];
  complaints: Complaint[];
  workers: Worker[];
  onUpdateComplaint: (id: string, updates: any) => Promise<void>;
  selectedWardId: number;
  onWardSelect: (wardId: number) => void;
}

export const WardOfficerDashboard: React.FC<WardOfficerDashboardProps> = ({
  wards,
  complaints,
  workers,
  onUpdateComplaint,
  selectedWardId,
  onWardSelect
}) => {
  const [selectedComplaintForDispatch, setSelectedComplaintForDispatch] = useState<Complaint | null>(null);
  const [nearestWorkers, setNearestWorkers] = useState<Worker[]>([]);
  const [loadingWorkers, setLoadingWorkers] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [generatingAiSummary, setGeneratingAiSummary] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');

  const safeWards = Array.isArray(wards) ? wards : [];
  const safeComplaints = Array.isArray(complaints) ? complaints : [];
  const selectedWard = safeWards.find(w => w.id === selectedWardId || w.number === selectedWardId) || safeWards[0] || { id: 14, number: 14, name: 'Waltair Uplands', zone: 'Zone 2 (Central)', officerName: 'Officer', officerPhone: '+91 94901 23014', complaintCount: 0, resolvedCount: 0, pendingCount: 0, boundary: [] };
  const wardComplaints = safeComplaints.filter(c => c.wardId === selectedWard.id || c.wardId === selectedWard.number || c.wardName === selectedWard.name);

  // Filter complaints & sort newest first
  const filteredComplaints = [...wardComplaints]
    .filter(c => {
      if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
      if (priorityFilter !== 'ALL' && c.priority !== priorityFilter) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const p1Count = wardComplaints.filter(c => c.priority === 'P1_CRITICAL' && c.status !== 'CITIZEN_VERIFIED').length;

  const handleGenerateAiSummary = async () => {
    setGeneratingAiSummary(true);
    try {
      const res = await fetch('/api/ai/summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wardId: selectedWardId, role: 'WARD_OFFICER' })
      });
      const data = await res.json();
      setAiSummary(data.summary);
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingAiSummary(false);
    }
  };

  const handleOpenDispatchModal = async (complaint: Complaint) => {
    setSelectedComplaintForDispatch(complaint);
    setLoadingWorkers(true);
    try {
      const res = await fetch(`/api/workers/nearest?lat=${complaint.lat}&lng=${complaint.lng}&category=${encodeURIComponent(complaint.category)}`);
      const data = await res.json();
      setNearestWorkers(data);
    } catch (err) {
      console.error(err);
      setNearestWorkers(workers);
    } finally {
      setLoadingWorkers(false);
    }
  };

  const handleAssignWorker = async (workerId: string) => {
    if (!selectedComplaintForDispatch) return;
    await onUpdateComplaint(selectedComplaintForDispatch.id, {
      assignedWorkerId: workerId,
      status: 'ASSIGNED',
      officerNotes: `Dispatched via PostGIS spatial allocation engine.`
    });
    setSelectedComplaintForDispatch(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center space-x-2 mb-1">
            <span className="bg-blue-600/30 text-blue-400 font-bold text-[10px] px-2.5 py-0.5 rounded-full border border-blue-500/30 uppercase tracking-wide">
              Ward Management Cockpit
            </span>
            <span className="text-slate-400 text-xs">PostGIS Nearest Worker Dispatch</span>
          </div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Building2 className="w-6 h-6 text-blue-400" />
            Ward {selectedWard.number}: {selectedWard.name}
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Zone Officer: <strong className="text-slate-200">{selectedWard.officerName}</strong> ({selectedWard.officerContact})
          </p>
        </div>

        {/* Ward Switcher Dropdown */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-slate-800 p-1.5 rounded-xl border border-slate-700 flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-300 pl-2">Switch Ward:</span>
            <select
              value={selectedWardId}
              onChange={(e) => onWardSelect(Number(e.target.value))}
              className="bg-slate-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {wards.map(w => (
                <option key={w.id} value={w.id}>
                  Ward {w.number} - {w.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleGenerateAiSummary}
            disabled={generatingAiSummary}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center space-x-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
            <span>{generatingAiSummary ? 'Generating AI Briefing...' : 'Generate AI Briefing'}</span>
          </button>
        </div>
      </div>

      {/* AI Summary Box */}
      {aiSummary && (
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-blue-950 text-slate-100 rounded-2xl p-6 border border-indigo-800/60 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-indigo-800/50 pb-3">
            <h3 className="font-bold text-sm text-indigo-300 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              Gemini AI Executive Ward Action Plan
            </h3>
            <span className="text-[10px] bg-indigo-900 text-indigo-200 px-2.5 py-0.5 rounded-full font-bold">
              Gemini 3.6 Flash
            </span>
          </div>
          <div className="text-xs space-y-2 whitespace-pre-line text-slate-200 font-sans leading-relaxed">
            {aiSummary}
          </div>
        </div>
      )}

      {/* Key Ward Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Total Grievances</span>
          <div className="text-2xl font-black text-slate-900">{wardComplaints.length}</div>
          <span className="text-[10px] text-slate-400">Ward {selectedWard.number} Jurisdiction</span>
        </div>

        <div className={`rounded-2xl p-5 border shadow-sm ${p1Count > 0 ? 'bg-rose-50 border-rose-300' : 'bg-white border-slate-200'}`}>
          <span className="text-xs font-bold text-rose-700 uppercase tracking-wider block mb-1 flex items-center gap-1">
            <ShieldAlert className="w-4 h-4 text-rose-600" /> P1 Critical Issues
          </span>
          <div className="text-2xl font-black text-rose-700">{p1Count}</div>
          <span className="text-[10px] text-rose-600 font-semibold">
            {p1Count > 0 ? 'Immediate Action Required' : 'All Clear'}
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Avg Resolution Time</span>
          <div className="text-2xl font-black text-slate-900">{selectedWard.avgResolutionHours} hrs</div>
          <span className="text-[10px] text-emerald-600 font-semibold">Target SLA: 24 hrs</span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">Ward Governance Rank</span>
          <div className="text-2xl font-black text-blue-600">#{selectedWard.ranking} <span className="text-xs font-normal text-slate-500">of 98</span></div>
          <span className="text-[10px] text-slate-400">Score: {selectedWard.performanceIndex} / 100</span>
        </div>
      </div>

      {/* Filter Controls & Grievance Queue */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">Ward Grievance Dispatch Queue</h3>
            <p className="text-xs text-slate-500">Manage, reassign, and monitor field technician activities</p>
          </div>

          {/* Filter Controls */}
          <div className="flex items-center space-x-3 text-xs">
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-300 font-medium text-slate-700 bg-slate-50"
            >
              <option value="ALL">All Priorities</option>
              <option value="P1_CRITICAL">P1 Critical</option>
              <option value="P2_HIGH">P2 High</option>
              <option value="P3_MEDIUM">P3 Medium</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-slate-300 font-medium text-slate-700 bg-slate-50"
            >
              <option value="ALL">All Statuses</option>
              <option value="RAISED">Raised (Unassigned)</option>
              <option value="ASSIGNED">Assigned</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="WORKER_COMPLETED">Worker Completed</option>
            </select>
          </div>
        </div>

        {/* Complaints Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredComplaints.map((c) => {
            const isP1 = c.priority === 'P1_CRITICAL';

            return (
              <div
                key={c.id}
                className={`rounded-2xl p-5 border transition shadow-sm hover:shadow-md ${
                  isP1 ? 'border-2 border-rose-500 bg-rose-50/20' : 'border-slate-200 bg-white'
                }`}
              >
                {/* Header Row */}
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    #{c.id}
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    isP1 ? 'bg-rose-600 text-white animate-pulse' :
                    c.priority === 'P2_HIGH' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {c.priority}
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 text-sm mb-1">{c.title}</h4>
                <p className="text-xs text-slate-600 line-clamp-2 mb-3">{c.description}</p>

                {/* Location Landmark & Photo */}
                <div className="flex items-center space-x-3 text-xs text-slate-500 bg-slate-50 p-2 rounded-lg mb-3">
                  {c.imageUrl && (
                    <img src={c.imageUrl} alt="Grievance" className="w-12 h-10 object-cover rounded border" />
                  )}
                  <div className="truncate">
                    <span className="font-semibold text-slate-800 block truncate">{c.landmark}</span>
                    <span className="text-[10px] text-slate-400">Category: {c.category}</span>
                  </div>
                </div>

                {/* Assignment & Action Button */}
                <div className="border-t border-slate-100 pt-3 flex items-center justify-between text-xs">
                  <div>
                    {c.assignedWorkerName ? (
                      <span className="text-slate-700 font-semibold text-[11px]">
                        Assigned: <strong className="text-blue-700">{c.assignedWorkerName}</strong>
                      </span>
                    ) : (
                      <span className="text-rose-600 font-bold text-[11px] flex items-center gap-1">
                        <AlertOctagon className="w-3.5 h-3.5" /> Unassigned
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => handleOpenDispatchModal(c)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition shadow flex items-center space-x-1"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>{c.assignedWorkerName ? 'Reassign Tech' : 'Dispatch Tech'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* PostGIS Spatial Dispatch Modal */}
      {selectedComplaintForDispatch && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">PostGIS Nearest Worker Allocation</span>
                <h3 className="font-bold text-slate-900 text-base">
                  Dispatch Field Technician for #{selectedComplaintForDispatch.id}
                </h3>
              </div>
              <button
                onClick={() => setSelectedComplaintForDispatch(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl text-xs space-y-1">
              <div className="font-bold text-slate-900">{selectedComplaintForDispatch.title}</div>
              <div className="text-slate-500">Location: {selectedComplaintForDispatch.landmark}</div>
              <div className="text-slate-500">Category Required: <strong className="text-blue-700">{selectedComplaintForDispatch.category}</strong></div>
            </div>

            {loadingWorkers ? (
              <div className="py-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                Calculating PostGIS Spatial Distance...
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {nearestWorkers.map((w) => (
                  <div
                    key={w.id}
                    className="p-3 rounded-xl border border-slate-200 hover:border-blue-500 bg-white flex items-center justify-between text-xs transition"
                  >
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-1.5">
                        {w.name}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          w.status === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {w.status}
                        </span>
                      </div>
                      <div className="text-slate-500 text-[11px] mt-0.5">
                        Category: {w.category} | Rating: ★ {w.efficiencyRating}
                      </div>
                      {w.distanceKm !== undefined && (
                        <div className="text-blue-600 font-bold text-[11px] mt-0.5 flex items-center gap-1">
                          <Navigation className="w-3 h-3 inline" /> PostGIS Spatial Distance: {w.distanceKm} km away
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => handleAssignWorker(w.id)}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow transition"
                    >
                      Dispatch Now
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
