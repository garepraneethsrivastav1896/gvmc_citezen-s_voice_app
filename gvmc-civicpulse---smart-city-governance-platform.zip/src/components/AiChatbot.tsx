import React, { useState } from 'react';
import { LanguageCode } from '../types';
import { Sparkles, MessageSquare, Send, X, Bot, User } from 'lucide-react';

interface AiChatbotProps {
  currentLang: LanguageCode;
}

export const AiChatbot: React.FC<AiChatbotProps> = ({ currentLang }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    {
      sender: 'bot',
      text: currentLang === 'TE' 
        ? 'నమస్కారం! నేను జివిఎంసి మిత్ర - విశాఖపట్నం స్మార్ట్ సిటీ AI అసిస్టెంట్. మీకు ఎలా సహాయపడగలను?' 
        : currentLang === 'HI'
          ? 'नमस्ते! मैं जीवीएमसी मित्र - विशाखापटनम स्मार्ट सिटी AI सहायक हूँ। मैं आपकी क्या मदद कर सकता हूँ?'
          : 'Namaste! I am GVMC Mitra, your 24/7 AI Smart City Governance Assistant for Visakhapatnam. How can I help you today?'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);

  const quickPrompts = [
    'How to report water leak in Ward 14?',
    'వైజాగ్ నీటి ఫిర్యాదు నమోదు ఎలా?',
    'What is target SLA for P1 Critical complaints?',
    'Who is the Ward Officer for Waltair Uplands?'
  ];

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg = text.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    if (!textToSend) setInputText('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg, language: currentLang })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { sender: 'bot', text: data.reply || 'GVMC Mitra service is online.' }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { sender: 'bot', text: 'Connection issue. GVMC Mitra is re-establishing socket...' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white p-4 rounded-full shadow-2xl transition transform hover:scale-105 flex items-center space-x-2 border-2 border-cyan-400"
        >
          <Sparkles className="w-6 h-6 text-cyan-200 animate-spin" />
          <span className="font-bold text-xs pr-1">GVMC Mitra AI</span>
        </button>
      ) : (
        <div className="bg-slate-900 border border-slate-700 rounded-2xl w-80 sm:w-96 h-[500px] shadow-2xl flex flex-col text-slate-100 overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-4 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center space-x-2.5">
              <div className="bg-cyan-500/20 p-2 rounded-xl border border-cyan-400/40">
                <Bot className="w-5 h-5 text-cyan-300" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                  GVMC Mitra <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                </h3>
                <span className="text-[10px] text-cyan-300 font-medium">Smart City AI Assistant</span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 leading-snug ${
                    m.sender === 'user'
                      ? 'bg-blue-600 text-white font-medium rounded-br-none'
                      : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-800 text-slate-400 text-xs px-3 py-2 rounded-2xl rounded-bl-none border border-slate-700 flex items-center gap-2">
                  <div className="w-3 h-3 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
                  GVMC Mitra thinking...
                </div>
              </div>
            )}
          </div>

          {/* Quick Prompts Chips */}
          <div className="p-2 bg-slate-950 border-t border-slate-800 flex flex-wrap gap-1">
            {quickPrompts.slice(0, 2).map((qp, i) => (
              <button
                key={i}
                onClick={() => handleSend(qp)}
                className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded-md transition truncate max-w-[180px]"
              >
                {qp}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center space-x-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask GVMC Mitra in English, తెలుగు, or हिन्दी..."
              className="flex-1 bg-slate-800 text-white text-xs px-3 py-2 rounded-xl border border-slate-700 focus:outline-none focus:border-blue-500"
            />
            <button
              onClick={() => handleSend()}
              disabled={loading || !inputText.trim()}
              className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow transition disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
