import React, { useState } from 'react';
import { UserRole, Ward, Worker, LanguageCode } from '../types';
import { 
  User, 
  ShieldCheck, 
  LogOut, 
  Building2, 
  Phone, 
  MapPin, 
  KeyRound, 
  Bell, 
  Settings, 
  CheckCircle2, 
  Award, 
  Clock, 
  Activity, 
  HardHat, 
  Crown, 
  Sliders, 
  Lock, 
  Smartphone, 
  Sparkles,
  X
} from 'lucide-react';

interface UserProfileDashboardProps {
  currentRole: UserRole;
  selectedWardId: number;
  selectedWorkerId: string;
  wards: Ward[];
  workers: Worker[];
  currentLang: LanguageCode;
  onSignOut: () => void;
  onClose: () => void;
}

export const UserProfileDashboard: React.FC<UserProfileDashboardProps> = ({
  currentRole,
  selectedWardId,
  selectedWorkerId,
  wards = [],
  workers = [],
  currentLang,
  onSignOut,
  onClose
}) => {
  const currentWard = wards.find(w => w.id === selectedWardId) || wards[0] || {
    id: 14,
    number: 14,
    name: 'Waltair Uplands',
    zone: 'East Zone',
    officerName: 'M. V. Ramana'
  };

  const currentWorker = workers.find(w => w.id === selectedWorkerId) || workers[0] || {
    id: 'W-101',
    name: 'K. Srinivas',
    category: 'Potholes & Roads',
    phone: '+91 98480 11001',
    status: 'ON_JOB',
    efficiencyRating: 4.8
  };

  // Editable Profile Form States
  const [citizenName, setCitizenName] = useState('Visakha Resident (Guest)');
  const [citizenPhone, setCitizenPhone] = useState('+91 98765 43210');
  const [preferredZone, setPreferredZone] = useState('East Zone');
  const [smsNotifs, setSmsNotifs] = useState(true);

  const [officerDutyStatus, setOfficerDutyStatus] = useState<'ON_DUTY' | 'OFF_DUTY'>('ON_DUTY');
  const [autoAssignEnabled, setAutoAssignEnabled] = useState(true);

  const [workerDutyStatus, setWorkerDutyStatus] = useState<'AVAILABLE' | 'ON_JOB' | 'OFF_DUTY'>('ON_JOB');

  const [savedSuccessMsg, setSavedSuccessMsg] = useState<string | null>(null);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccessMsg('Profile settings updated successfully! ✓');
    setTimeout(() => setSavedSuccessMsg(null), 3000);
  };

  const getRoleHeader = () => {
    switch (currentRole) {
      case 'CITIZEN':
        return {
          title: 'Guest Resident Account',
          badge: 'Verified Citizen ID',
          bg: 'bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900',
          icon: <User className="w-8 h-8 text-emerald-400" />
        };
      case 'WARD_OFFICER':
        return {
          title: `Ward #${currentWard.id} Officer (${currentWard.officerName})`,
          badge: `Ward Admin - ${currentWard.name}`,
          bg: 'bg-gradient-to-r from-indigo-900 via-slate-950 to-slate-900',
          icon: <Building2 className="w-8 h-8 text-indigo-400" />
        };
      case 'COMMISSIONER':
        return {
          title: 'GVMC Municipal Commissioner HQ',
          badge: 'Executive Central Command',
          bg: 'bg-gradient-to-r from-amber-900 via-slate-950 to-slate-900',
          icon: <Crown className="w-8 h-8 text-amber-400" />
        };
      case 'FIELD_WORKER':
        return {
          title: `Technician ${currentWorker.name} (${currentWorker.category})`,
          badge: `Mobile Crew ID: ${currentWorker.id}`,
          bg: 'bg-gradient-to-r from-cyan-900 via-slate-950 to-slate-900',
          icon: <HardHat className="w-8 h-8 text-cyan-400" />
        };
    }
  };

  const header = getRoleHeader();

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-8">
        
        {/* Banner Header */}
        <div className={`${header.bg} text-white p-6 sm:p-8 relative`}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white p-2 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/10 backdrop-blur rounded-2xl border border-white/20">
              {header.icon}
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-white/10 px-2.5 py-0.5 rounded-md border border-white/20">
                {header.badge}
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
                {header.title}
              </h2>
              <p className="text-xs text-slate-300 mt-1 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Active Session • Visakhapatnam Smart City Gateway
              </p>
            </div>
          </div>
        </div>

        {/* Profile Control Body */}
        <div className="p-6 space-y-6">

          {savedSuccessMsg && (
            <div className="bg-emerald-50 text-emerald-800 border border-emerald-300 p-3 rounded-2xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{savedSuccessMsg}</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-5">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2">
              <Settings className="w-4 h-4 text-cyan-600" /> Control Account Preferences & Info
            </h3>

            {/* Role Specific Settings */}
            {currentRole === 'CITIZEN' && (
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Resident Name / Alias
                    </label>
                    <input
                      type="text"
                      value={citizenName}
                      onChange={(e) => setCitizenName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Registered Mobile Number
                    </label>
                    <input
                      type="text"
                      value={citizenPhone}
                      onChange={(e) => setCitizenPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-semibold text-slate-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Default Preferred Administrative Zone
                    </label>
                    <select
                      value={preferredZone}
                      onChange={(e) => setPreferredZone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                    >
                      <option value="East Zone">East Zone (Beach Road, Waltair)</option>
                      <option value="West Zone">West Zone (Gajuwaka, Gopalapatnam)</option>
                      <option value="North Zone">North Zone (Madhurawada, Bheemili)</option>
                      <option value="South Zone">South Zone (One Town, Harbour)</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-3 pt-6">
                    <input
                      type="checkbox"
                      id="smsCheck"
                      checked={smsNotifs}
                      onChange={(e) => setSmsNotifs(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                    />
                    <label htmlFor="smsCheck" className="font-semibold text-slate-700">
                      Receive Real-time SMS OTP & SLA Resolution Alerts
                    </label>
                  </div>
                </div>
              </div>
            )}

            {currentRole === 'WARD_OFFICER' && (
              <div className="space-y-4 text-xs">
                <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-900">Ward Officer Duty Status</span>
                    <button
                      type="button"
                      onClick={() => setOfficerDutyStatus(s => s === 'ON_DUTY' ? 'OFF_DUTY' : 'ON_DUTY')}
                      className={`px-3 py-1 rounded-full font-black text-[11px] transition cursor-pointer ${
                        officerDutyStatus === 'ON_DUTY' 
                          ? 'bg-emerald-600 text-white' 
                          : 'bg-slate-300 text-slate-700'
                      }`}
                    >
                      {officerDutyStatus === 'ON_DUTY' ? '● ON DUTY ACTIVE' : '○ OFF DUTY'}
                    </button>
                  </div>
                  <p className="text-[11px] text-indigo-700">
                    Active Ward #{currentWard.id} ({currentWard.name}). Officer in-charge: <strong>{currentWard.officerName}</strong>.
                  </p>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <span className="font-bold text-slate-800 block">PostGIS Auto-Worker Dispatch Engine</span>
                    <span className="text-[11px] text-slate-500">Automatically assign nearest technician within 200 meters</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={autoAssignEnabled}
                    onChange={(e) => setAutoAssignEnabled(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded"
                  />
                </div>
              </div>
            )}

            {currentRole === 'COMMISSIONER' && (
              <div className="space-y-4 text-xs">
                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-900">HQ High-Distress Emergency Shield</span>
                    <span className="bg-amber-600 text-slate-950 font-black px-2 py-0.5 rounded text-[10px]">
                      P1 EMERGENCY LEVEL ACTIVE
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800">
                    Monitors citywide grievances exceeding 24 hours SLA threshold across all 98 administrative wards.
                  </p>
                </div>
              </div>
            )}

            {currentRole === 'FIELD_WORKER' && (
              <div className="space-y-4 text-xs">
                <div className="bg-cyan-50 p-4 rounded-2xl border border-cyan-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-950">Technician Availability Status</span>
                    <select
                      value={workerDutyStatus}
                      onChange={(e) => setWorkerDutyStatus(e.target.value as any)}
                      className="px-3 py-1 rounded-xl bg-white border border-cyan-300 font-bold text-cyan-900 text-xs"
                    >
                      <option value="AVAILABLE">AVAILABLE FOR DISPATCH</option>
                      <option value="ON_JOB">ON JOB AT SITE</option>
                      <option value="OFF_DUTY">OFF DUTY</option>
                    </select>
                  </div>
                  <p className="text-[11px] text-cyan-800">
                    Category: <strong>{currentWorker.category}</strong> | Phone: <strong>{currentWorker.phone}</strong> | Efficiency Rating: <strong>{currentWorker.efficiencyRating} ⭐</strong>
                  </p>
                </div>
              </div>
            )}

            <div className="pt-2 flex items-center justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Save Profile Preferences</span>
              </button>
            </div>
          </form>

          {/* Account Security & Sign Out Section */}
          <div className="border-t border-slate-200 pt-5 space-y-3">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Session & Account Control
            </h4>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-slate-900 block">
                  Sign Out of Profile
                </span>
                <span className="text-[11px] text-slate-500">
                  End your current {header.badge} session and return to the home gateway.
                </span>
              </div>

              <button
                type="button"
                onClick={onSignOut}
                className="w-full sm:w-auto px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out Account</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
