import React from 'react';
import { UserRole } from '../types';
import { LogOut, ShieldAlert, ArrowRight, X } from 'lucide-react';

interface SignOutConfirmModalProps {
  currentRole: UserRole;
  onConfirmSignOut: () => void;
  onCancel: () => void;
}

export const SignOutConfirmModal: React.FC<SignOutConfirmModalProps> = ({
  currentRole,
  onConfirmSignOut,
  onCancel
}) => {
  const roleName = {
    CITIZEN: 'Resident Citizen (Guest)',
    WARD_OFFICER: 'Ward Administrative Officer',
    COMMISSIONER: 'Commissioner Command HQ',
    FIELD_WORKER: 'Field Technician Crew'
  }[currentRole];

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto animate-in fade-in zoom-in-95">
      <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 space-y-5">
        
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-3">
            <div className="bg-rose-100 p-2.5 rounded-2xl text-rose-600">
              <LogOut className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 tracking-tight">
                Sign Out & Return Home?
              </h3>
              <p className="text-xs text-slate-500">
                Confirm session exit
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-2">
          <p className="text-slate-700 font-medium">
            You are currently logged in as <strong className="text-slate-900 font-bold">{roleName}</strong>.
          </p>
          <p className="text-slate-500">
            Returning to the Home Gateway will sign out your active account session. Would you like to proceed?
          </p>
        </div>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            Stay Signed In
          </button>
          
          <button
            onClick={onConfirmSignOut}
            className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Yes, Sign Out & Go Home</span>
          </button>
        </div>

      </div>
    </div>
  );
};
