import React, { useState } from 'react';
import { UserRole, LanguageCode, Ward, Worker } from '../types';
import { 
  Building2, 
  UserCheck, 
  ShieldCheck, 
  Crown, 
  HardHat, 
  MapPin, 
  Sparkles, 
  ArrowRight, 
  Clock, 
  ShieldAlert, 
  BarChart3, 
  Map, 
  Trophy, 
  CheckCircle2, 
  Lock, 
  KeyRound, 
  Smartphone, 
  HelpCircle,
  Activity,
  Award
} from 'lucide-react';

interface HomePageProps {
  wards: Ward[];
  workers: Worker[];
  currentLang: LanguageCode;
  onSelectRole: (role: UserRole, wardId?: number, workerId?: string) => void;
  onNavigateTab: (tab: 'portal' | 'officer' | 'commissioner' | 'map' | 'analytics' | 'leaderboard') => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  wards,
  workers,
  currentLang,
  onSelectRole,
  onNavigateTab
}) => {
  // Ward Officer Login State
  const [selectedWardId, setSelectedWardId] = useState<number>(14);
  const [officerUsername, setOfficerUsername] = useState('officer_ward14');
  const [officerPass, setOfficerPass] = useState('gvmc123');
  const [officerLoginError, setOfficerLoginError] = useState<string | null>(null);

  // Commissioner Login State
  const [commUsername, setCommUsername] = useState('commissioner_hq');
  const [commPass, setCommPass] = useState('gvmc123');
  const [commLoginError, setCommLoginError] = useState<string | null>(null);

  // Field Tech Login State
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>(workers[0]?.id || 'W-101');
  const [workerUsername, setWorkerUsername] = useState('worker_w101');
  const [workerPass, setWorkerPass] = useState('1234');
  const [workerLoginError, setWorkerLoginError] = useState<string | null>(null);

  const t = {
    EN: {
      subtitle: 'Official Smart City Grievance & Ward Intelligence System',
      guestPortalTitle: 'Resident / Citizen Portal',
      guestPortalBadge: 'No Login Required • Guest Access',
      guestPortalDesc: 'Lodge civic grievances instantly with photo geotagging, SMS OTP verification, and real-time SLA tracking.',
      guestPortalBtn: 'Instant Guest Citizen Access',
      
      officerTitle: 'Ward Administrative Officer',
      officerBadge: 'Ward Officer Auth',
      officerDesc: 'Manage ward-level tickets, assign nearest field technicians via spatial engine, and resolve SLAs.',
      
      commTitle: 'Commissioner & HQ Command',
      commBadge: 'Commissioner Auth',
      commDesc: 'City-wide executive dashboard, real-time SLA compliance, high-distress escalation, and performance audits.',
      
      workerTitle: 'Field Technician Portal',
      workerBadge: 'Field Tech Auth',
      workerDesc: 'On-field crew task manager, before/after photo evidence upload, and work order sign-offs.',
      
      loginBtn: 'Authenticate & Access',
      selectWard: 'Select Administrative Ward:',
      selectWorker: 'Select Technician Profile:',
      usernameLabel: 'Username:',
      passwordLabel: 'Password:'
    },
    TE: {
      subtitle: 'అధికారిక స్మార్ట్ సిటీ ప్రజా సమస్యల పరిష్కార వేదిక',
      guestPortalTitle: 'పౌర సేవల పోర్టల్',
      guestPortalBadge: 'లాగిన్ అవసరం లేదు • నేరుగా ప్రవేశం',
      guestPortalDesc: 'జియోట్యాగింగ్ ఫోటో, SMS OTP మరియు SLA ట్రాకింగ్‌తో మీ సమస్యను తక్షణమే నమోదు చేయండి.',
      guestPortalBtn: 'పౌరుల సేవల్లోకి వెళ్ళండి',
      
      officerTitle: 'వార్డు పరిపాలనాధికారి',
      officerBadge: 'వార్డు ఆఫీసర్ లాగిన్',
      officerDesc: 'వార్డు సమస్యల నిర్వహణ, ఫీల్డ్ వర్కర్ల కేటాయింపు మరియు SLA పర్యవేక్షణ.',
      
      commTitle: 'కమిషనర్ కమాండ్ సెంటర్',
      commBadge: 'మున్సిపల్ ప్రధాన కార్యాలయం',
      commDesc: 'విశాఖపట్నం వ్యాప్తంగా SLA ట్రాకింగ్, అత్యవసర సమస్యల సమీక్ష మరియు పనితీరు ఆడిట్.',
      
      workerTitle: 'ఫీల్డ్ టెక్నీషియన్ పోర్టల్',
      workerBadge: 'సిబ్బంది లాగిన్',
      workerDesc: 'ఫీల్డ్ పనుల స్వీకరణ, వర్క్ ఆర్డర్ ఫోటోలు మరియు పూర్తి వివరాల సమర్పణ.',
      
      loginBtn: 'లాగిన్ అవ్వండి',
      selectWard: 'మీ వార్డును ఎంచుకోండి:',
      selectWorker: 'సిబ్బంది ప్రొఫైల్ ఎంచుకోండి:',
      usernameLabel: 'యూజర్ నేమ్:',
      passwordLabel: 'పాస్‌వర్డ్:'
    },
    HI: {
      subtitle: 'आधिकारिक स्मार्ट सिटी शिकायत एवं वार्ड इंटेलिजेंस सिस्टम',
      guestPortalTitle: 'नागरिक सेवा पोर्टल',
      guestPortalBadge: 'बिना लॉगिन • सीधा प्रवेश',
      guestPortalDesc: 'फोटो जियोटैगिंग, एसएमएस ओटीपी और वास्तविक समय एसएलए ट्रैकिंग के साथ शिकायत दर्ज करें।',
      guestPortalBtn: 'नागरिक पोर्टल में प्रवेश करें',
      
      officerTitle: 'वार्ड प्रशासनिक अधिकारी',
      officerBadge: 'वार्ड अधिकारी लॉगिन',
      officerDesc: 'वार्ड स्तर के टिकट, तकनीशियन आवंटन और एसएलए अनुपालन संभालें।',
      
      commTitle: 'आयुक्त कमांड सेंटर',
      commBadge: 'मुख्यालय प्रवेश',
      commDesc: 'शहर व्यापी एसएलए निगरानी, उच्च संकट समीक्षा और प्रदर्शन ऑडिट।',
      
      workerTitle: 'फील्ड तकनीशियन पोर्टल',
      workerBadge: 'कर्मचारी लॉगिन',
      workerDesc: 'फील्ड कार्य असाइनमेंट, काम से पहले और बाद की फोटो अपलोड।',
      
      loginBtn: 'लॉगिन करें',
      selectWard: 'वार्ड चुनें:',
      selectWorker: 'कर्मचारी चुनें:',
      usernameLabel: 'उपयोगकर्ता नाम:',
      passwordLabel: 'पासवर्ड:'
    }
  }[currentLang];

  const handleOfficerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!officerUsername.trim()) {
      setOfficerLoginError('Please enter Ward Officer username');
      return;
    }
    if (!officerPass || officerPass.length < 3) {
      setOfficerLoginError('Please enter Ward Officer password');
      return;
    }
    setOfficerLoginError(null);
    onSelectRole('WARD_OFFICER', selectedWardId);
  };

  const handleCommLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commUsername.trim()) {
      setCommLoginError('Please enter Commissioner username');
      return;
    }
    if (!commPass || commPass.length < 3) {
      setCommLoginError('Please enter Commissioner password');
      return;
    }
    setCommLoginError(null);
    onSelectRole('COMMISSIONER');
  };

  const handleWorkerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workerUsername.trim()) {
      setWorkerLoginError('Please enter Field Technician username');
      return;
    }
    if (!workerPass || workerPass.length < 3) {
      setWorkerLoginError('Please enter Field Technician password');
      return;
    }
    setWorkerLoginError(null);
    const matchedWorker = workers.find(w => w.id === selectedWorkerId);
    onSelectRole('FIELD_WORKER', matchedWorker?.wardId || 14, selectedWorkerId);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Welcome Banner */}
      <section className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-2xl relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-4xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500/20 to-blue-600/20 border border-cyan-400/40 px-3.5 py-1.5 rounded-full text-xs font-bold text-cyan-300">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <span>Greater Visakhapatnam Municipal Corporation (GVMC)</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight">
            CivicPulse <span className="text-cyan-400 font-light">Smart Governance</span> Gateway
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl font-medium leading-relaxed">
            {t.subtitle}. Powered by <strong className="text-white">PostgreSQL 17 PostGIS Spatial Engine</strong> and <strong className="text-cyan-300">Gemini 3.6 Flash Anti-Fake AI Shield</strong> for pin-point precise civic service delivery.
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-xs">
            <div className="bg-slate-900/80 backdrop-blur p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block font-semibold text-[11px]">Total Wards</span>
              <span className="text-lg font-black text-white">98 Administrative Wards</span>
            </div>
            <div className="bg-slate-900/80 backdrop-blur p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block font-semibold text-[11px]">Avg Resolution Time</span>
              <span className="text-lg font-black text-emerald-400">18.4 Hours</span>
            </div>
            <div className="bg-slate-900/80 backdrop-blur p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block font-semibold text-[11px]">Anti-Fake Accuracy</span>
              <span className="text-lg font-black text-cyan-300">99.8% Pinpoint</span>
            </div>
            <div className="bg-slate-900/80 backdrop-blur p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-400 block font-semibold text-[11px]">Active SLA Compliance</span>
              <span className="text-lg font-black text-amber-300">94.2% On-Time</span>
            </div>
          </div>
        </div>
      </section>

      {/* Role Selection & Gateway Options */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-blue-600" /> Select User Portal & Authenticate
            </h2>
            <p className="text-xs text-slate-500">
              Citizens require no login (Guest Access). Officials and technicians log in with role credentials.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* CARD 1: CITIZEN GUEST PORTAL (NO LOGIN REQUIRED) */}
          <div className="bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 text-white rounded-3xl p-6 border border-blue-700/50 shadow-xl flex flex-col justify-between space-y-6 relative overflow-hidden group hover:border-blue-500 transition-all">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="bg-blue-600/30 p-3 rounded-2xl border border-blue-400/40">
                  <UserCheck className="w-7 h-7 text-cyan-300" />
                </div>
                <span className="text-[11px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  {t.guestPortalBadge}
                </span>
              </div>

              <div>
                <h3 className="text-2xl font-black text-white tracking-tight">{t.guestPortalTitle}</h3>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {t.guestPortalDesc}
                </p>
              </div>

              {/* Key Highlights */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  <span className="text-slate-200">Gemini 3.6 AI Shield</span>
                </div>
                <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="text-slate-200">SMS OTP Verified</span>
                </div>
                <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span className="text-slate-200">PostGIS 200m Spatial</span>
                </div>
                <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span className="text-slate-200">Live 24/7 SLA Tracking</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onSelectRole('CITIZEN')}
              className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm rounded-2xl shadow-lg transition transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{t.guestPortalBtn}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          {/* CARD 2: WARD ADMINISTRATIVE OFFICER LOGIN */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xl flex flex-col justify-between space-y-6 hover:border-slate-300 transition-all">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-700">
                  <Building2 className="w-7 h-7" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider bg-indigo-100 text-indigo-800 border border-indigo-200 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-indigo-600" />
                  {t.officerBadge}
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">{t.officerTitle}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {t.officerDesc}
                </p>
              </div>

              <form onSubmit={handleOfficerLogin} className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.selectWard}
                  </label>
                  <select
                    value={selectedWardId}
                    onChange={(e) => {
                      const idNum = Number(e.target.value);
                      setSelectedWardId(idNum);
                      const matchedWard = wards.find(w => w.id === idNum);
                      if (matchedWard) {
                        setOfficerUsername(`officer_ward${matchedWard.number}`);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 bg-white"
                  >
                    {wards.map((w) => (
                      <option key={w.id} value={w.id}>
                        Ward #{w.number} - {w.name} ({w.zone} Zone) - Officer: {w.officerName}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.usernameLabel}
                  </label>
                  <input
                    type="text"
                    value={officerUsername}
                    onChange={(e) => setOfficerUsername(e.target.value)}
                    placeholder="Enter Username (e.g. officer_ward14)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.passwordLabel}
                  </label>
                  <input
                    type="password"
                    value={officerPass}
                    onChange={(e) => setOfficerPass(e.target.value)}
                    placeholder="Enter Password (demo: gvmc123)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-semibold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 bg-white"
                  />
                </div>

                {officerLoginError && (
                  <p className="text-xs text-rose-600 font-bold">{officerLoginError}</p>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Login as Ward Officer →</span>
                </button>
              </form>
            </div>
          </div>

          {/* CARD 3: COMMISSIONER & CENTRAL COMMAND */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xl flex flex-col justify-between space-y-6 hover:border-slate-300 transition-all">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="bg-amber-100 p-3 rounded-2xl text-amber-700">
                  <Crown className="w-7 h-7" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-700" />
                  {t.commBadge}
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">{t.commTitle}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {t.commDesc}
                </p>
              </div>

              <form onSubmit={handleCommLogin} className="space-y-3 bg-amber-50/50 p-4 rounded-2xl border border-amber-200/80">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.usernameLabel}
                  </label>
                  <input
                    type="text"
                    value={commUsername}
                    onChange={(e) => setCommUsername(e.target.value)}
                    placeholder="Enter Username (e.g. commissioner_hq)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-amber-500 focus:ring-2 focus:ring-amber-200 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.passwordLabel}
                  </label>
                  <input
                    type="password"
                    value={commPass}
                    onChange={(e) => setCommPass(e.target.value)}
                    placeholder="Enter Password (demo: gvmc123)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-semibold focus:border-amber-500 focus:ring-2 focus:ring-amber-200 bg-white"
                  />
                </div>

                {commLoginError && (
                  <p className="text-xs text-rose-600 font-bold">{commLoginError}</p>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Crown className="w-4 h-4" />
                  <span>Login to Commissioner Headquarters →</span>
                </button>
              </form>
            </div>
          </div>

          {/* CARD 4: FIELD TECHNICIAN PORTAL */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xl flex flex-col justify-between space-y-6 hover:border-slate-300 transition-all">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="bg-emerald-100 p-3 rounded-2xl text-emerald-700">
                  <HardHat className="w-7 h-7" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-full flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                  {t.workerBadge}
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">{t.workerTitle}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {t.workerDesc}
                </p>
              </div>

              <form onSubmit={handleWorkerLogin} className="space-y-3 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200/80">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.selectWorker}
                  </label>
                  <select
                    value={selectedWorkerId}
                    onChange={(e) => {
                      const wId = e.target.value;
                      setSelectedWorkerId(wId);
                      const matchedWorker = workers.find(w => w.id === wId);
                      if (matchedWorker) {
                        setWorkerUsername(`worker_${matchedWorker.id.toLowerCase().replace('-', '')}`);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 bg-white"
                  >
                    {workers.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.category}) - Ward #{w.wardId} ({w.wardName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.usernameLabel}
                  </label>
                  <input
                    type="text"
                    value={workerUsername}
                    onChange={(e) => setWorkerUsername(e.target.value)}
                    placeholder="Enter Username (e.g. worker_w101)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    {t.passwordLabel}
                  </label>
                  <input
                    type="password"
                    value={workerPass}
                    onChange={(e) => setWorkerPass(e.target.value)}
                    placeholder="Enter Password (demo: 1234)"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-semibold focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 bg-white"
                  />
                </div>

                {workerLoginError && (
                  <p className="text-xs text-rose-600 font-bold">{workerLoginError}</p>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <HardHat className="w-4 h-4" />
                  <span>Login as Field Tech Crew →</span>
                </button>
              </form>
            </div>
          </div>

        </div>
      </section>

      {/* Quick Navigation Cards (PostGIS Map, Analytics, Leaderboard) */}
      <section className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 space-y-4">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" /> Visakhapatnam Smart City Public Modules
        </h3>
        <p className="text-xs text-slate-400">
          Explore interactive spatial maps, ward performance analytics, and citywide ward ranking leaderboards.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigateTab('map')}
            className="p-4 bg-slate-800/80 hover:bg-slate-800 rounded-2xl border border-slate-700/80 text-left transition space-y-2 group cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <Map className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition" />
              <span className="text-[10px] font-bold text-slate-400 uppercase">PostGIS Spatial</span>
            </div>
            <h4 className="text-sm font-bold text-white">Interactive Ward Map</h4>
            <p className="text-xs text-slate-400">View real-time GIS heatmaps, live technician locations, and ward boundaries.</p>
          </button>

          <button
            onClick={() => onNavigateTab('analytics')}
            className="p-4 bg-slate-800/80 hover:bg-slate-800 rounded-2xl border border-slate-700/80 text-left transition space-y-2 group cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <BarChart3 className="w-6 h-6 text-purple-400 group-hover:scale-110 transition" />
              <span className="text-[10px] font-bold text-slate-400 uppercase">SLA Intelligence</span>
            </div>
            <h4 className="text-sm font-bold text-white">Performance Analytics</h4>
            <p className="text-xs text-slate-400">Resolution SLA trends, category distributions, and AI efficiency metrics.</p>
          </button>

          <button
            onClick={() => onNavigateTab('leaderboard')}
            className="p-4 bg-slate-800/80 hover:bg-slate-800 rounded-2xl border border-slate-700/80 text-left transition space-y-2 group cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <Trophy className="w-6 h-6 text-amber-400 group-hover:scale-110 transition" />
              <span className="text-[10px] font-bold text-amber-400 uppercase">City Rankings</span>
            </div>
            <h4 className="text-sm font-bold text-white">Ward Swachh Leaderboard</h4>
            <p className="text-xs text-slate-400">See top-performing wards in Visakhapatnam based on resolution speed and citizen ratings.</p>
          </button>
        </div>
      </section>
    </div>
  );
};
