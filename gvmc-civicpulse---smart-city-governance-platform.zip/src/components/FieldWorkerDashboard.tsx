import React, { useState } from 'react';
import { Complaint, Worker, PriorityLevel, CategoryType } from '../types';
import { 
  HardHat, 
  MapPin, 
  Phone, 
  Clock, 
  CheckCircle2, 
  Upload, 
  Camera, 
  Sparkles, 
  AlertTriangle, 
  Search, 
  Filter, 
  UserCheck, 
  Check, 
  RefreshCw, 
  ShieldCheck, 
  ArrowRight, 
  Image as ImageIcon,
  FileText,
  Star,
  Activity
} from 'lucide-react';

interface FieldWorkerDashboardProps {
  workers: Worker[];
  complaints: Complaint[];
  onUpdateComplaint: (id: string, updates: any) => Promise<void>;
  selectedWorkerId?: string;
  onSelectWorker?: (workerId: string) => void;
}

export const FieldWorkerDashboard: React.FC<FieldWorkerDashboardProps> = ({
  workers = [],
  complaints = [],
  onUpdateComplaint,
  selectedWorkerId,
  onSelectWorker
}) => {
  const safeWorkers = Array.isArray(workers) ? workers : [];
  const safeComplaints = Array.isArray(complaints) ? complaints : [];

  // Active Worker Selection
  const [activeWorkerId, setActiveWorkerId] = useState<string>(
    selectedWorkerId || safeWorkers[0]?.id || 'W-101'
  );

  const activeWorker = safeWorkers.find(w => w.id === activeWorkerId) || safeWorkers[0] || {
    id: 'W-101',
    name: 'K. Srinivas',
    category: 'Potholes & Roads' as CategoryType,
    phone: '+91 98480 11001',
    wardId: 14,
    wardName: 'Waltair Uplands',
    lat: 17.721,
    lng: 83.315,
    activeComplaints: 2,
    status: 'ON_JOB' as const,
    efficiencyRating: 4.8
  };

  // Filters & Search
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected Complaint for Work Completion Photo Upload
  const [activeTaskModal, setActiveTaskModal] = useState<Complaint | null>(null);
  const [afterImagePreview, setAfterImagePreview] = useState<string>('');
  const [workNotes, setWorkNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Match complaints assigned to this worker OR in worker's ward/category if not explicitly assigned
  const workerTasks = safeComplaints.filter(c => {
    const matchesWorker = c.assignedWorkerId === activeWorker.id || c.assignedWorkerName === activeWorker.name;
    const matchesWardCategory = Number(c.wardId) === Number(activeWorker.wardId) && c.category === activeWorker.category;
    return matchesWorker || matchesWardCategory;
  });

  const filteredTasks = [...workerTasks]
    .filter(c => {
      if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchId = (c.id || '').toLowerCase().includes(q);
        const matchTitle = (c.title || '').toLowerCase().includes(q);
        const matchLoc = (c.landmark || '').toLowerCase().includes(q);
        return matchId || matchTitle || matchLoc;
      }
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const pendingCount = workerTasks.filter(c => c.status === 'ASSIGNED' || c.status === 'IN_PROGRESS' || c.status === 'RAISED').length;
  const completedCount = workerTasks.filter(c => c.status === 'WORKER_COMPLETED' || c.status === 'CITIZEN_VERIFIED').length;

  const handleWorkerChange = (id: string) => {
    setActiveWorkerId(id);
    if (onSelectWorker) onSelectWorker(id);
  };

  const handleOpenUploadModal = (complaint: Complaint) => {
    setActiveTaskModal(complaint);
    setAfterImagePreview(complaint.afterImageUrl || 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b2?auto=format&fit=crop&w=800&q=80');
    setWorkNotes(complaint.officerNotes || 'Work completed on site. Asphalt patched and compacted to official GVMC standards.');
    setUploadError(null);
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      setUploadError('Image size exceeds 8MB. Please select a smaller photo.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setAfterImagePreview(reader.result as string);
      setUploadError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleMarkInProgress = async (complaint: Complaint) => {
    try {
      await onUpdateComplaint(complaint.id, {
        status: 'IN_PROGRESS',
        assignedWorkerId: activeWorker.id,
        assignedWorkerName: activeWorker.name,
        assignedWorkerPhone: activeWorker.phone,
        officerNotes: `Technician ${activeWorker.name} arrived on site and started resolution.`
      });
      setSuccessMsg(`Task #${complaint.id} status updated to IN PROGRESS ✓`);
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmitCompletedWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTaskModal) return;
    if (!afterImagePreview) {
      setUploadError('Please upload or select a proof of work photo before submitting.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onUpdateComplaint(activeTaskModal.id, {
        status: 'WORKER_COMPLETED',
        afterImageUrl: afterImagePreview,
        officerNotes: `[FIELD WORK PROOF SUBMITTED by ${activeWorker.name}]: ${workNotes}`,
        assignedWorkerId: activeWorker.id,
        assignedWorkerName: activeWorker.name,
        assignedWorkerPhone: activeWorker.phone
      });

      setSuccessMsg(`Proof of work submitted for Task #${activeTaskModal.id}! Sent to Ward Officer for verification.`);
      setActiveTaskModal(null);
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (err) {
      setUploadError('Failed to update task. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner & Worker Profile Identity */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          
          <div className="flex items-start gap-4">
            <div className="bg-cyan-500/20 p-3.5 rounded-2xl border border-cyan-400/40 text-cyan-300">
              <HardHat className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider bg-cyan-900/60 px-2.5 py-0.5 rounded border border-cyan-700/60 font-mono">
                  Field Tech Mobile ID: {activeWorker.id}
                </span>
                <span className="text-xs font-extrabold text-emerald-300 bg-emerald-900/60 px-2.5 py-0.5 rounded-full border border-emerald-700/60 flex items-center gap-1">
                  <Activity className="w-3 h-3 text-emerald-400" /> ON-FIELD ACTIVE
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1">
                {activeWorker.name} <span className="text-slate-400 font-normal text-lg">({activeWorker.category})</span>
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 mt-2">
                <span className="flex items-center gap-1 font-semibold">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" /> Ward #{activeWorker.wardId} - {activeWorker.wardName}
                </span>
                <span className="flex items-center gap-1 font-mono text-cyan-200">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" /> {activeWorker.phone}
                </span>
                <span className="flex items-center gap-1 text-amber-300 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" /> {activeWorker.efficiencyRating} / 5.0 Rating
                </span>
              </div>
            </div>
          </div>

          {/* Worker Profile Switcher */}
          <div className="bg-slate-800/90 backdrop-blur p-3.5 rounded-2xl border border-slate-700/80 w-full md:w-72 space-y-2">
            <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              Switch Technician Profile
            </label>
            <select
              value={activeWorkerId}
              onChange={(e) => handleWorkerChange(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-semibold focus:border-cyan-400 focus:outline-none"
            >
              {safeWorkers.map(w => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.category}) - Ward #{w.wardId}
                </option>
              ))}
            </select>
          </div>

        </div>

        {/* Task Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 mt-6 border-t border-slate-800 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-semibold">Total Assigned Tasks</span>
            <span className="text-xl font-black text-white">{workerTasks.length} Work Orders</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-slate-400 block font-semibold">Pending / In Progress</span>
            <span className="text-xl font-black text-amber-400">{pendingCount} Active</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800 col-span-2 sm:col-span-1">
            <span className="text-slate-400 block font-semibold">Completed & Proof Uploaded</span>
            <span className="text-xl font-black text-emerald-400">{completedCount} Verified</span>
          </div>
        </div>
      </div>

      {/* Alert Notification Message */}
      {successMsg && (
        <div className="bg-emerald-900/90 text-emerald-100 border border-emerald-600 p-4 rounded-2xl text-xs font-bold flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-300" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-300 hover:text-white">✕</button>
        </div>
      )}

      {/* Task Filter & Search Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search task ID, title, or landmark..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs font-medium focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 bg-slate-50"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 whitespace-nowrap">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>
          {['ALL', 'ASSIGNED', 'IN_PROGRESS', 'WORKER_COMPLETED'].map(status => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                statusFilter === status 
                  ? 'bg-slate-900 text-white shadow-sm' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {status === 'ALL' ? 'All Assigned Tasks' :
               status === 'ASSIGNED' ? 'New Assigned' :
               status === 'IN_PROGRESS' ? 'In Progress' : 'Completed Proof'}
            </button>
          ))}
        </div>
      </div>

      {/* Assigned Complaints Feed */}
      <div className="space-y-4">
        {filteredTasks.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
            <div className="bg-slate-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto text-slate-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">No Assigned Tasks Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              There are currently no work orders matching this filter for {activeWorker.name}.
            </p>
          </div>
        ) : (
          filteredTasks.map(task => {
            const isCompleted = task.status === 'WORKER_COMPLETED' || task.status === 'CITIZEN_VERIFIED';
            const isInProgress = task.status === 'IN_PROGRESS';

            return (
              <div 
                key={task.id}
                className={`bg-white rounded-3xl border transition shadow-sm hover:shadow-md p-5 space-y-4 ${
                  task.priority === 'P1_CRITICAL' ? 'border-rose-300' :
                  isInProgress ? 'border-amber-300 bg-amber-50/20' :
                  isCompleted ? 'border-emerald-300 bg-emerald-50/10' : 'border-slate-200'
                }`}
              >
                {/* Header Info */}
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-black text-slate-900 bg-slate-100 border border-slate-300 px-2.5 py-0.5 rounded">
                        #{task.id}
                      </span>
                      <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                        task.priority === 'P1_CRITICAL' ? 'bg-rose-100 text-rose-800 border-rose-300' :
                        task.priority === 'P2_HIGH' ? 'bg-amber-100 text-amber-800 border-amber-300' : 'bg-blue-100 text-blue-800 border-blue-300'
                      }`}>
                        {task.priority}
                      </span>
                      <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                        {task.category}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900">{task.title}</h3>
                  </div>

                  {/* Status Badge */}
                  <div>
                    <span className={`text-xs font-extrabold px-3 py-1 rounded-full border flex items-center gap-1.5 ${
                      isCompleted ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
                      isInProgress ? 'bg-amber-100 text-amber-800 border-amber-300' :
                      'bg-blue-100 text-blue-800 border-blue-300'
                    }`}>
                      {isCompleted ? <ShieldCheck className="w-4 h-4 text-emerald-600" /> :
                       isInProgress ? <Clock className="w-4 h-4 text-amber-600 animate-spin" /> :
                       <HardHat className="w-4 h-4 text-blue-600" />}
                      <span>{task.status.replace('_', ' ')}</span>
                    </span>
                  </div>
                </div>

                {/* Task Details & Location Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="space-y-2 md:col-span-2">
                    <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-2xl border border-slate-200">
                      <strong>Citizen Description:</strong> {task.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-slate-600">
                      <span className="flex items-center gap-1 font-semibold">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" /> {task.landmark} (Ward #{task.wardId})
                      </span>
                      <span className="flex items-center gap-1 font-semibold text-slate-700">
                        <UserCheck className="w-3.5 h-3.5 text-blue-600" /> Citizen: {task.citizenName} ({task.citizenPhone})
                      </span>
                    </div>
                  </div>

                  {/* SLA & Time Info */}
                  <div className="bg-slate-900 text-white p-3.5 rounded-2xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>SLA Timer Target:</span>
                      <span className="font-bold text-amber-400">{task.slaHours} Hours</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-300">Remaining:</span>
                      <span className={`text-sm font-black font-mono ${task.hoursRemaining < 6 ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`}>
                        {task.hoursRemaining} Hours
                      </span>
                    </div>
                    <a
                      href={`tel:${task.citizenPhone}`}
                      className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold rounded-xl border border-slate-700 text-center flex items-center justify-center gap-1 transition"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call Citizen</span>
                    </a>
                  </div>
                </div>

                {/* Before vs After Photos Display */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {/* Before Photo */}
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <ImageIcon className="w-3.5 h-3.5 text-slate-400" /> Reported Problem Photo (Before)
                    </span>
                    <div className="relative h-40 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
                      <img 
                        src={task.imageUrl || task.beforeImageUrl || 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80'} 
                        alt="Before" 
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-2 left-2 bg-slate-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded backdrop-blur">
                        Reported Image
                      </span>
                    </div>
                  </div>

                  {/* After Photo (Proof of Resolution) */}
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Work Resolution Proof (After)
                    </span>
                    {task.afterImageUrl ? (
                      <div className="relative h-40 rounded-2xl overflow-hidden border border-emerald-300 bg-slate-100">
                        <img 
                          src={task.afterImageUrl} 
                          alt="After" 
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-2 left-2 bg-emerald-950/90 text-emerald-300 text-[10px] font-extrabold px-2 py-0.5 rounded backdrop-blur border border-emerald-700">
                          Proof Uploaded ✓
                        </span>
                      </div>
                    ) : (
                      <div className="h-40 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 flex flex-col items-center justify-center p-4 text-center text-slate-400 space-y-1">
                        <Camera className="w-6 h-6 text-slate-300" />
                        <span className="text-xs font-semibold">No Resolution Proof Uploaded Yet</span>
                        <span className="text-[10px] text-slate-400">Click button below to upload after-work photo</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Worker Action Buttons */}
                <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  {task.status === 'ASSIGNED' && (
                    <button
                      onClick={() => handleMarkInProgress(task)}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Clock className="w-4 h-4" />
                      <span>Start Work / Mark In Progress</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenUploadModal(task)}
                    className="px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{task.afterImageUrl ? 'Re-upload Completed Work Proof' : 'Upload Completed Work Proof Photo'}</span>
                  </button>
                </div>

              </div>
            );
          })
        )}
      </div>

      {/* UPLOAD WORK PROOF MODAL */}
      {activeTaskModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl p-6 space-y-5 animate-in fade-in zoom-in-95">
            
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-xs font-mono font-bold text-cyan-700 bg-cyan-100 px-2 py-0.5 rounded">
                  #{activeTaskModal.id}
                </span>
                <h3 className="text-lg font-black text-slate-900 tracking-tight mt-1">
                  Upload Resolution Proof (After Work)
                </h3>
              </div>
              <button
                onClick={() => setActiveTaskModal(null)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitCompletedWork} className="space-y-4">
              
              {/* Photo Upload Area */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Upload Site Resolution Photo *
                </label>
                
                <div className="border-2 border-dashed border-cyan-300 rounded-2xl p-4 bg-cyan-50/50 hover:bg-cyan-50 transition text-center space-y-3">
                  {afterImagePreview ? (
                    <div className="relative h-48 rounded-xl overflow-hidden border border-cyan-400">
                      <img 
                        src={afterImagePreview} 
                        alt="Resolution Proof" 
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-2 right-2 bg-emerald-600 text-white text-[10px] font-bold px-2 py-1 rounded shadow">
                        Proof Image Staged ✓
                      </span>
                    </div>
                  ) : (
                    <div className="py-6 space-y-2">
                      <Camera className="w-10 h-10 text-cyan-600 mx-auto" />
                      <p className="text-xs font-bold text-slate-700">Click to select or take completed work photo</p>
                      <p className="text-[10px] text-slate-400">Supports JPG, PNG, WEBP geotagged photos</p>
                    </div>
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="block w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-cyan-600 file:text-white hover:file:bg-cyan-700 cursor-pointer"
                  />
                </div>
              </div>

              {/* Work Resolution Description Notes */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Technician Work Completion Notes *
                </label>
                <textarea
                  value={workNotes}
                  onChange={(e) => setWorkNotes(e.target.value)}
                  rows={3}
                  placeholder="e.g. Cleared drainage blockage, repaired asphalt patch with roller, tested streetlight lighting..."
                  required
                  className="w-full p-3 rounded-xl border border-slate-300 text-xs font-medium focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100"
                />
              </div>

              {uploadError && (
                <p className="text-xs text-rose-600 font-bold bg-rose-50 p-2.5 rounded-xl border border-rose-200">
                  {uploadError}
                </p>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setActiveTaskModal(null)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isSubmitting ? 'Submitting Work Proof...' : 'Submit Work Completion Proof →'}</span>
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
