import React, { useState } from 'react';
import { UserRole, LanguageCode, NotificationItem } from '../types';
import { 
  Building2, 
  MapPin, 
  ShieldCheck, 
  Bell, 
  Globe, 
  User, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  X,
  Home,
  LogOut
} from 'lucide-react';

interface NavbarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  currentLang: LanguageCode;
  onLangChange: (lang: LanguageCode) => void;
  notifications: NotificationItem[];
  activeTab: 'home' | 'portal' | 'officer' | 'commissioner' | 'worker' | 'map' | 'analytics' | 'leaderboard';
  onTabChange: (tab: 'home' | 'portal' | 'officer' | 'commissioner' | 'worker' | 'map' | 'analytics' | 'leaderboard') => void;
  onOpenProfile: () => void;
  onRequestHome: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onRoleChange,
  currentLang,
  onLangChange,
  notifications,
  activeTab,
  onTabChange,
  onOpenProfile,
  onRequestHome
}) => {
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const roleLabels: Record<UserRole, { label: string; icon: string; bg: string }> = {
    CITIZEN: { label: 'Guest Citizen', icon: '📱', bg: 'bg-emerald-950/80 border-emerald-700/60 text-emerald-300' },
    WARD_OFFICER: { label: 'Ward Officer', icon: '🏢', bg: 'bg-indigo-950/80 border-indigo-700/60 text-indigo-300' },
    COMMISSIONER: { label: 'Commissioner HQ', icon: '👑', bg: 'bg-amber-950/80 border-amber-700/60 text-amber-300' },
    FIELD_WORKER: { label: 'Field Technician', icon: '🛠️', bg: 'bg-cyan-950/80 border-cyan-700/60 text-cyan-300' }
  };

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-50 shadow-md">
      {/* Top Banner / Gov Emblem */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-4">
        
        {/* Brand Logo & Smart City Title (Clicking logo requests home sign out confirm) */}
        <button 
          onClick={onRequestHome}
          className="flex items-center space-x-3 text-left hover:opacity-90 transition cursor-pointer"
        >
          <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-2 rounded-xl text-white shadow-lg flex items-center justify-center">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/50">
                GVMC Official Gateway
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline flex items-center gap-1">
                <MapPin className="w-3 h-3 text-red-400 inline" /> Visakhapatnam Smart City
              </span>
            </div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              CivicPulse <span className="text-xs font-normal text-slate-400 hidden md:inline">| PostGIS & Gemini AI Grievance Engine</span>
            </h1>
          </div>
        </button>

        {/* Secured Navigation Tabs */}
        <nav className="flex items-center space-x-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60 text-xs font-medium overflow-x-auto">
          <button
            onClick={onRequestHome}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 font-bold ${
              activeTab === 'home' 
                ? 'bg-cyan-600 text-white shadow' 
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>Home Gateway</span>
          </button>
          
          {/* Active Authenticated Role Portal Tab */}
          {currentRole === 'CITIZEN' && (
            <button
              onClick={() => onTabChange('portal')}
              className={`px-3 py-1.5 rounded-lg transition-all font-bold ${
                activeTab === 'portal' 
                  ? 'bg-emerald-600 text-white shadow' 
                  : 'text-emerald-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              📱 Citizen Portal
            </button>
          )}

          {currentRole === 'WARD_OFFICER' && (
            <button
              onClick={() => onTabChange('officer')}
              className={`px-3 py-1.5 rounded-lg transition-all font-bold ${
                activeTab === 'officer' 
                  ? 'bg-indigo-600 text-white shadow' 
                  : 'text-indigo-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              🏢 Ward Officer Portal
            </button>
          )}

          {currentRole === 'COMMISSIONER' && (
            <button
              onClick={() => onTabChange('commissioner')}
              className={`px-3 py-1.5 rounded-lg transition-all font-bold ${
                activeTab === 'commissioner' 
                  ? 'bg-amber-600 text-white shadow' 
                  : 'text-amber-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              👑 Commissioner HQ
            </button>
          )}

          {currentRole === 'FIELD_WORKER' && (
            <button
              onClick={() => onTabChange('worker')}
              className={`px-3 py-1.5 rounded-lg transition-all font-bold ${
                activeTab === 'worker' 
                  ? 'bg-cyan-600 text-white shadow' 
                  : 'text-cyan-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              🛠️ Field Worker Portal
            </button>
          )}

          {/* Public Modules */}
          <button
            onClick={() => onTabChange('map')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'map' 
                ? 'bg-blue-600 text-white shadow' 
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            🗺️ Ward Map
          </button>

          <button
            onClick={() => onTabChange('analytics')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'analytics' 
                ? 'bg-blue-600 text-white shadow' 
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            📊 Analytics
          </button>

          <button
            onClick={() => onTabChange('leaderboard')}
            className={`px-3 py-1.5 rounded-lg transition-all font-bold ${
              activeTab === 'leaderboard' 
                ? 'bg-amber-500 text-slate-950 shadow-lg ring-2 ring-amber-400/50' 
                : 'text-amber-300 hover:text-white hover:bg-amber-950/40 border border-amber-500/30'
            }`}
          >
            🏆 Leaderboard
          </button>
        </nav>

        {/* Right Controls: Active Session Badge, Language Selector, Notifications */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          
          {/* Active Session Profile Control Button */}
          <button
            onClick={onOpenProfile}
            title="Open Account Profile Dashboard"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition shadow-xs hover:opacity-90 cursor-pointer ${roleLabels[currentRole].bg}`}
          >
            <User className="w-3.5 h-3.5 text-cyan-300" />
            <span className="hidden sm:inline">{roleLabels[currentRole].label} Profile</span>
            <span className="sm:hidden">Profile</span>
          </button>
          
          <button
            onClick={onRequestHome}
            title="Sign Out / Switch Account"
            className="hidden lg:flex items-center gap-1 p-2 rounded-xl bg-slate-800 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-800 text-slate-300 hover:text-rose-300 text-xs font-bold transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit</span>
          </button>
          
          {/* Language Switcher */}
          <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-1" />
            <button
              onClick={() => onLangChange('EN')}
              className={`px-2 py-1 text-xs rounded-md font-semibold transition ${
                currentLang === 'EN' ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onLangChange('TE')}
              className={`px-2 py-1 text-xs rounded-md font-semibold transition ${
                currentLang === 'TE' ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              తెలుగు
            </button>
            <button
              onClick={() => onLangChange('HI')}
              className={`px-2 py-1 text-xs rounded-md font-semibold transition ${
                currentLang === 'HI' ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              हिन्दी
            </button>
          </div>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifDrawer(!showNotifDrawer)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white relative border border-slate-700 transition"
              title="Notifications Queue"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown Drawer */}
            {showNotifDrawer && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 p-4 text-slate-200">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-cyan-400" /> Real-time FCM Notification Queue
                  </h3>
                  <button 
                    onClick={() => setShowNotifDrawer(false)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto">
                  {notifications.map((n) => (
                    <div 
                      key={n.id} 
                      className={`p-2.5 rounded-lg text-xs border ${
                        n.type === 'ALERT' 
                          ? 'bg-rose-950/40 border-rose-800/60 text-rose-200' 
                          : n.type === 'SUCCESS' 
                            ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
                            : 'bg-slate-800/60 border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between font-semibold mb-1">
                        <span className="flex items-center gap-1">
                          {n.type === 'ALERT' ? <AlertTriangle className="w-3.5 h-3.5 text-rose-400" /> : <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                          {n.title}
                        </span>
                        <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                      </div>
                      <p className="text-[11px] leading-snug">{n.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* System Online Badge */}
          <div className="hidden lg:flex items-center space-x-1.5 text-[11px] bg-slate-800 px-2.5 py-1 rounded-full border border-slate-700 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="font-medium text-slate-300">PostGIS + AI Active</span>
          </div>

        </div>
      </div>
    </header>
  );
};
