import React, { useState, useEffect } from 'react';
import { Complaint, Ward, Worker, NotificationItem, UserRole, LanguageCode } from './types';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { CitizenPortal } from './components/CitizenPortal';
import { WardOfficerDashboard } from './components/WardOfficerDashboard';
import { CommissionerDashboard } from './components/CommissionerDashboard';
import { FieldWorkerDashboard } from './components/FieldWorkerDashboard';
import { UserProfileDashboard } from './components/UserProfileDashboard';
import { SignOutConfirmModal } from './components/SignOutConfirmModal';
import { MapView } from './components/MapView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { LeaderboardView } from './components/LeaderboardView';
import { AiChatbot } from './components/AiChatbot';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [wards, setWards] = useState<Ward[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  
  const [currentRole, setCurrentRole] = useState<UserRole>('CITIZEN');
  const [activeTab, setActiveTab] = useState<'home' | 'portal' | 'officer' | 'commissioner' | 'worker' | 'map' | 'analytics' | 'leaderboard'>('home');
  const [currentLang, setCurrentLang] = useState<LanguageCode>('EN');
  const [selectedWardId, setSelectedWardId] = useState<number>(14);
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>('W-101');

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showSignOutModal, setShowSignOutModal] = useState(false);

  const [loading, setLoading] = useState(true);

  const handleRequestHome = () => {
    if (activeTab === 'home') {
      setActiveTab('home');
      return;
    }
    // Ask user to sign out when clicking home from an active role session
    setShowSignOutModal(true);
  };

  const handleConfirmSignOut = () => {
    setShowSignOutModal(false);
    setShowProfileModal(false);
    setCurrentRole('CITIZEN');
    setActiveTab('home');
  };

  // Role Redirection Handler from Home Page
  const handleSelectRole = (role: UserRole, wardId?: number, workerId?: string) => {
    setCurrentRole(role);
    if (wardId) setSelectedWardId(wardId);
    if (workerId) setSelectedWorkerId(workerId);

    if (role === 'CITIZEN') {
      setActiveTab('portal');
    } else if (role === 'WARD_OFFICER') {
      setActiveTab('officer');
    } else if (role === 'COMMISSIONER') {
      setActiveTab('commissioner');
    } else if (role === 'FIELD_WORKER') {
      setActiveTab('worker');
    }
  };

  // Fetch initial data from REST API endpoints
  const fetchAllData = async () => {
    try {
      const [compRes, wardRes, workRes, notifRes] = await Promise.all([
        fetch('/api/complaints'),
        fetch('/api/wards'),
        fetch('/api/workers'),
        fetch('/api/notifications')
      ]);

      const [compData, wardData, workData, notifData] = await Promise.all([
        compRes.json(),
        wardRes.json(),
        workRes.json(),
        notifRes.json()
      ]);

      if (Array.isArray(compData)) setComplaints(compData);
      if (Array.isArray(wardData)) setWards(wardData);
      if (Array.isArray(workData)) setWorkers(workData);
      if (Array.isArray(notifData)) setNotifications(notifData);
    } catch (err) {
      console.error('Data Fetch Error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Submit New Complaint
  const handleSubmitComplaint = async (newComplaintData: any) => {
    const res = await fetch('/api/complaints', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newComplaintData)
    });
    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.error || `Server returned error (${res.status})`);
    }
    const createdComplaint = await res.json();
    if (createdComplaint?.wardId) {
      setSelectedWardId(Number(createdComplaint.wardId));
    }
    await fetchAllData();
  };

  // Update Complaint Status / Assignment
  const handleUpdateComplaint = async (id: string, updates: any) => {
    try {
      const res = await fetch(`/api/complaints/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        await fetchAllData();
      }
    } catch (err) {
      console.error('Update Complaint Error:', err);
    }
  };

  // Citizen Verify Complaint
  const handleVerifyComplaint = async (id: string, feedback: { rating: number; comment: string; isSatisfied: boolean }) => {
    await handleUpdateComplaint(id, { citizenFeedback: feedback });
  };

  // Commissioner Approve Complaint
  const handleApproveComplaint = async (id: string) => {
    await handleUpdateComplaint(id, { status: 'COMMISSIONER_APPROVED' });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 border-4 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
        <div className="text-center">
          <h2 className="text-lg font-black tracking-wide">GVMC CivicPulse Smart City Portal</h2>
          <p className="text-xs text-slate-400 mt-1">Initializing PostGIS Spatial Engine & Gemini 3.6 Flash AI...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-100 font-sans text-slate-900 flex flex-col selection:bg-cyan-500 selection:text-white">
        {/* Navigation Header */}
        <Navbar
          currentRole={currentRole}
          onRoleChange={setCurrentRole}
          currentLang={currentLang}
          onLangChange={setCurrentLang}
          notifications={notifications}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onOpenProfile={() => setShowProfileModal(true)}
          onRequestHome={handleRequestHome}
        />

        {/* Main Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'home' && (
            <HomePage
              wards={wards}
              workers={workers}
              currentLang={currentLang}
              onSelectRole={handleSelectRole}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'portal' && (
            <CitizenPortal
              complaints={complaints}
              wards={wards}
              onSubmitComplaint={handleSubmitComplaint}
              onVerifyComplaint={handleVerifyComplaint}
              currentLang={currentLang}
              onViewLeaderboard={() => setActiveTab('leaderboard')}
            />
          )}

          {activeTab === 'officer' && (
            <WardOfficerDashboard
              wards={wards}
              complaints={complaints}
              workers={workers}
              onUpdateComplaint={handleUpdateComplaint}
              selectedWardId={selectedWardId}
              onWardSelect={setSelectedWardId}
            />
          )}

          {activeTab === 'commissioner' && (
            <CommissionerDashboard
              wards={wards}
              complaints={complaints}
              onApproveComplaint={handleApproveComplaint}
            />
          )}

          {activeTab === 'worker' && (
            <FieldWorkerDashboard
              workers={workers}
              complaints={complaints}
              onUpdateComplaint={handleUpdateComplaint}
              selectedWorkerId={selectedWorkerId}
              onSelectWorker={setSelectedWorkerId}
            />
          )}

          {activeTab === 'map' && (
            <MapView
              wards={wards}
              complaints={complaints}
              workers={workers}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsDashboard />
          )}

          {activeTab === 'leaderboard' && (
            <LeaderboardView
              wards={wards}
              currentLang={currentLang}
              onSelectWard={(wardId) => {
                setSelectedWardId(wardId);
                setActiveTab('officer');
              }}
            />
          )}
        </main>

        {/* Floating 24/7 AI Smart City Assistant */}
        <AiChatbot currentLang={currentLang} />

        {/* User Account Profile Dashboard Modal */}
        {showProfileModal && (
          <UserProfileDashboard
            currentRole={currentRole}
            selectedWardId={selectedWardId}
            selectedWorkerId={selectedWorkerId}
            wards={wards}
            workers={workers}
            currentLang={currentLang}
            onSignOut={handleConfirmSignOut}
            onClose={() => setShowProfileModal(false)}
          />
        )}

        {/* Sign Out Confirmation Modal when returning Home */}
        {showSignOutModal && (
          <SignOutConfirmModal
            currentRole={currentRole}
            onConfirmSignOut={handleConfirmSignOut}
            onCancel={() => setShowSignOutModal(false)}
          />
        )}

        {/* Footer */}
        <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 py-6 px-4 mt-12 text-center space-y-2">
          <div className="flex flex-wrap justify-center items-center gap-4 text-slate-300 font-semibold">
            <span>Greater Visakhapatnam Municipal Corporation (GVMC)</span>
            <span>•</span>
            <span>PostgreSQL 17 + PostGIS Spatial Engine</span>
            <span>•</span>
            <span>Gemini 3.6 Flash AI</span>
            <span>•</span>
            <span>Visakhapatnam Smart City Initiative</span>
          </div>
          <p className="text-slate-500 text-[11px]">
            © 2026 GVMC. All rights reserved. Powered by AI Studio Build Architecture.
          </p>
        </footer>
      </div>
    </ErrorBoundary>
  );
}
